"""
ASML TWINSCAN XT 400F — ER Event Log Parser
============================================
지정된 폴더(기본값: ./asml-log) 안의 모든 .log 파일을 파싱하여
uid / datetime / event_name / event_code / signal /
start_code / end_code / process_time / origin_message /
is_motion_related / remark 컬럼을 갖는 레코드를 생성합니다.

사용법:
    python asml_log_parser.py                        # 기본: CSV + JSON 출력
    python asml_log_parser.py --out csv              # CSV 만 출력
    python asml_log_parser.py --out json             # JSON 만 출력
    python asml_log_parser.py --log-dir /path/logs   # 로그 디렉터리 지정
    python asml_log_parser.py --pattern "*.log"     # 파일명 글롭 패턴 지정
    python asml_log_parser.py --stats                # 통계 요약 출력
"""

import re
import json
import csv
import sys
import os
import argparse
import statistics
from datetime import datetime
from pathlib import Path
from collections import defaultdict, Counter


# ──────────────────────────────────────────────────────────────
# 1. 로그 레코드 파싱 정규식
# ──────────────────────────────────────────────────────────────
#  형식:
#  MM/DD/YYYY HH:MM:SS.ffff  Machine:ID  (Rel:버전, LOMW[빌드], 소스파일)
#  SYSTEM EVENT: 코드  심각도  메시지
LOG_RE = re.compile(
    r'^(\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2}\.\d+)'   # 그룹1: 타임스탬프
    r'\s+Machine:(\w+)'                                  # 그룹2: 머신 ID
    r'\s+\(Rel:([\w.]+),\s*LOMW\[(\d+)\],\s*([\w./]+)\)'  # 그룹3~5: 릴리즈/빌드/소스
    r'\s+SYSTEM EVENT:\s+(\S+)'                          # 그룹6: 이벤트 코드
    r'\s+(\w+)'                                          # 그룹7: 심각도
    r'\s+(.*?)$'                                         # 그룹8: 메시지
)

# wafer number / lot id 추출용 정규식 (process_time context_key 계산에 사용)
WAFER_LOT_RE = re.compile(r'wafer number (\d+), lot id (\d+)', re.IGNORECASE)


# ──────────────────────────────────────────────────────────────
# 2. 이벤트 메타 정의
# ──────────────────────────────────────────────────────────────
#  튜플 구조: (event_name, signal, start_code, end_code, is_motion_related)
#
#  signal 종류:
#    START  - 동작 시작 이벤트
#    END    - 동작 종료 이벤트 (START와 쌍을 이루어 process_time 계산)
#    POINT  - 단독 발생 이벤트 (시작/종료 구분 없음)
#
#  is_motion_related:
#    True  - 스테이지 / 웨이퍼 / 척 등 물리적 모션 수반
#    False - 소프트웨어 상태, 로트 관리, 에러 핸들링 등
# ──────────────────────────────────────────────────────────────
EVENT_META: dict[str, tuple] = {

    # ── 시스템 기동 ──────────────────────────────────────────
    "SY-0001": ("System Startup",          "START",  "SY-0001", "SY-0002", False),
    "SY-0002": ("System Startup",          "END",    "SY-0001", "SY-0002", False),
    "BD-0010": ("Board Init",              "START",  "BD-0010", "BD-0011", False),
    "BD-0011": ("Board Init",              "END",    "BD-0010", "BD-0011", False),

    # ── 스테이지 초기화 / 보정 ───────────────────────────────
    "WP-0010": ("Stage Homing",            "START",  "WP-0010", "WP-0011", True),
    "WP-0011": ("Stage Homing",            "END",    "WP-0010", "WP-0011", True),
    "WP-0200": ("TIS Scan",               "START",  "WP-0200", "WP-0201", True),
    "WP-0201": ("TIS Scan",               "END",    "WP-0200", "WP-0201", True),

    # ── Immersion Head 초기화 ────────────────────────────────
    "IH-0010": ("IH Init",                "START",  "IH-0010", "IH-0011", False),
    "IH-0011": ("IH Init",                "END",    "IH-0010", "IH-0011", False),

    # ── IDLE ─────────────────────────────────────────────────
    "SY-1000": ("IDLE",                   "START",  "SY-1000", "SY-1001", False),
    "SY-1001": ("IDLE",                   "END",    "SY-1000", "SY-1001", False),

    # ── FOUP Pod ─────────────────────────────────────────────
    # POINT: 시스템 레벨, wafer/lot 정보 없음
    "WH-0100": ("Pod Placed",             "POINT",  "WH-0100", "",        False),
    "WH-0101": ("FOUP Door Open",         "START",  "WH-0101", "WH-0102", False),
    "WH-0102": ("FOUP Door Open",         "END",    "WH-0101", "WH-0102", False),
    "WH-0110": ("Pod Removed",            "POINT",  "WH-0110", "",        False),

    # ── LOT 관리 ─────────────────────────────────────────────
    "LO-0001": ("Lot Start",              "START",  "LO-0001", "LO-0002", False),
    "LO-0002": ("Lot End",                "END",    "LO-0001", "LO-0002", False),
    "LO-0020": ("Lot Queue Started",      "POINT",  "LO-0020", "",        False),
    "LO-0021": ("Lot Queue Stopped",      "POINT",  "LO-0021", "",        False),

    # ── 레티클 로딩 ──────────────────────────────────────────
    "LO-0061": ("Reticle Load",           "START",  "LO-0061", "LO-0062", False),
    "LO-0062": ("Reticle Load",           "END",    "LO-0061", "LO-0062", False),

    # ── 웨이퍼 핸들링 (모션 수반) ────────────────────────────
    "WH-0200": ("Wafer Load",             "START",  "WH-0200", "WH-0201", True),
    "WH-0201": ("Wafer Load",             "END",    "WH-0200", "WH-0201", True),
    "WH-0210": ("Prealign",              "START",  "WH-0210", "WH-0211", True),
    "WH-0211": ("Prealign",              "END",    "WH-0210", "WH-0211", True),
    "WH-0300": ("Wafer Unload",           "START",  "WH-0300", "WH-0301", True),
    "WH-0301": ("Wafer Unload",           "END",    "WH-0300", "WH-0301", True),

    # ── 트랙 이송 ────────────────────────────────────────────
    "TR-0100": ("Track Transfer",         "START",  "TR-0100", "TR-0101", True),
    "TR-0101": ("Track Transfer",         "END",    "TR-0100", "TR-0101", True),

    # ── Measure Chuck (TWINSCAN 이중 척) ────────────────────
    # ★ LO-8029/802A: wafer/lot 포함 → context_key로 구분
    "LO-8029": ("Measure",               "START",  "LO-8029", "LO-802A", True),
    "LO-802A": ("Measure",               "END",    "LO-8029", "LO-802A", True),
    "FO-0100": ("Focus Map",             "START",  "FO-0100", "FO-0101", True),
    "FO-0101": ("Focus Map",             "END",    "FO-0100", "FO-0101", True),

    # ── Chuck Exchange (TWINSCAN 핵심 HW 이벤트) ─────────────
    # ★ HW 레벨 — wafer/lot 정보 없음, Rel:6.3.0.b 에서 발생
    # ★ 소스파일: LOMWxKS_request.swap / LOMWxKS_get_result_s
    "LO-8025": ("Chuck Exchange",        "START",  "LO-8025", "LO-8026", True),
    "LO-8026": ("Chuck Exchange",        "END",    "LO-8025", "LO-8026", True),

    # ── Expose Chuck — 얼라인먼트 ────────────────────────────
    "AT-0200": ("Alignment",             "START",  "AT-0200", "AT-0201", True),
    "AT-0201": ("Alignment",             "END",    "AT-0200", "AT-0201", True),
    "AT-0210": ("Align Mark Measure",    "START",  "AT-0210", "AT-0211", True),
    "AT-0211": ("Align Mark Measure",    "END",    "AT-0210", "AT-0211", True),

    # ── 노광 (Immersion Exposure) ────────────────────────────
    "LO-0500": ("Exposure",              "START",  "LO-0500", "LO-0501", True),
    "LO-0501": ("Exposure",              "END",    "LO-0500", "LO-0501", True),
    "LO-0510": ("Field Exposure",        "START",  "LO-0510", "LO-0511", True),
    "LO-0511": ("Field Exposure",        "END",    "LO-0510", "LO-0511", True),
    # ★ IH-1527: HW 레벨 Immersion Head cex — wafer/lot 없음
    "IH-1527": ("IH Cex",               "POINT",  "IH-1527", "",        True),

    # ── 경고 이벤트 ──────────────────────────────────────────
    # ★ 모두 HW/시스템 레벨 — wafer/lot 정보 없음
    "WP-0100": ("Stage Deviation Warn",  "POINT",  "WP-0100", "",        True),

    # ── 에러 이벤트 ──────────────────────────────────────────
    "KD-0001": ("Color-diff Error",      "POINT",  "KD-0001", "",        False),
    "KD-0002": ("Color-diff Error",      "POINT",  "KD-0002", "",        False),
    "PG-48B4": ("Queue Rejected Error",  "POINT",  "PG-48B4", "",        False),
    "WP-290D": ("Stage Queue Error",     "START",  "WP-290D", "WP-0400", True),
    "WP-0400": ("Stage Queue Error",     "END",    "WP-290D", "WP-0400", True),
    "ER-0FFF": ("Error Deactivate",      "POINT",  "ER-0FFF", "",        False),

    # ── 유지보수 / 보정 ──────────────────────────────────────
    "SY-2000": ("TIS Calibration",       "START",  "SY-2000", "SY-2001", False),
    "SY-2001": ("TIS Calibration",       "END",    "SY-2000", "SY-2001", False),
    "SY-3000": ("MX Action",             "START",  "SY-3000", "SY-3001", False),
    "SY-3001": ("MX Action",             "END",    "SY-3000", "SY-3001", False),
    "SY-9999": ("Day Summary",           "POINT",  "SY-9999", "",        False),
}

# ──────────────────────────────────────────────────────────────
# 3. 이벤트코드별 비고(Remark) 정의
# ──────────────────────────────────────────────────────────────
REMARK: dict[str, str] = {
    "LO-8025": "HW level — no wafer/lot info; Rel:6.3.0.b; src:LOMWxKS_request.swap",
    "LO-8026": "HW level — no wafer/lot info; Rel:6.3.0.b; src:LOMWxKS_get_result_s",
    "IH-1527": "HW level — no wafer/lot info; immersion fluid cex control",
    "WP-0100": "Stage position deviation within tolerance; auto-deactivated via ER-0FFF",
    "KD-0001": "Periodic color-diff data store failure (HW driver level)",
    "KD-0002": "ColorDiff reference order undetermined (follows KD-0001)",
    "PG-48B4": "Process queue rejected after 3 retries (state: REJECTED-WAIT-UNTIL-IDLE)",
    "WP-290D": "Stage state-machine transition failure; triggers WP-0400",
    "WP-0400": "WPSS Chuck linked error; follows WP-290D",
    "ER-0FFF": "Error handler deactivation signal",
    "FO-0101": "Focus map RMS value (nm) included in message",
    "AT-0211": "Alignment residual (nm) and mark count included in message",
    "SY-9999": "Daily operation statistics summary record",
    "WH-0100": "System level — no wafer/lot info (FOUP detection)",
    "WH-0110": "System level — no wafer/lot info (FOUP removal)",
}


# ──────────────────────────────────────────────────────────────
# 4. 타임스탬프 파싱 헬퍼
# ──────────────────────────────────────────────────────────────
def parse_timestamp(ts_str: str) -> datetime:
    """
    'MM/DD/YYYY HH:MM:SS.ffff' 형식의 타임스탬프를 datetime 객체로 변환.
    밀리초/마이크로초 자릿수가 4자리일 경우 6자리로 패딩.
    """
    # 소수점 이하를 6자리(마이크로초)로 표준화
    parts = ts_str.split('.')
    if len(parts) == 2:
        frac = parts[1].ljust(6, '0')[:6]
        ts_str = f"{parts[0]}.{frac}"
    return datetime.strptime(ts_str, "%m/%d/%Y %H:%M:%S.%f")


def format_timestamp(dt: datetime) -> str:
    """datetime → 'YYYY-MM-DD HH:MM:SS.fff' ISO 형식 문자열"""
    return dt.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]  # 마이크로초 → 밀리초


# ──────────────────────────────────────────────────────────────
# 5. context_key 생성
# ──────────────────────────────────────────────────────────────
def make_context_key(message: str) -> str:
    """
    동시 진행될 수 있는 동일 이벤트를 구분하기 위한 context key.

    - 메시지에 'wafer number N, lot id M' 이 포함된 경우
      → "w{N}_l{M}" 반환  (예: "w5_l101")
      → wafer/lot 단위로 START→END 페어를 정확히 매칭

    - 포함되지 않은 경우(HW 레벨 이벤트 등)
      → "" (빈 문자열) 반환
      → 동일 타입 이벤트 중 가장 최근 START와 매칭
    """
    m = WAFER_LOT_RE.search(message)
    if m:
        return f"w{m.group(1)}_l{m.group(2)}"
    return ""


# ──────────────────────────────────────────────────────────────
# 6. 단일 로그 라인 파싱
# ──────────────────────────────────────────────────────────────
def parse_line(line: str, file_index: int) -> dict | None:
    """
    로그 한 줄을 파싱하여 레코드 딕셔너리 반환.
    인식되지 않는 이벤트 코드는 None 반환.

    반환 딕셔너리 필드:
        ts_raw       : 원본 타임스탬프 문자열
        ts_dt        : datetime 객체 (process_time 계산용)
        machine      : 머신 ID
        rel          : 릴리즈 버전
        build        : LOMW 빌드 번호
        src_file     : 소스 파일명
        event_code   : 이벤트 코드 (예: LO-8025)
        severity     : DEFAULT / WARNING / ERROR / EVENT
        origin_msg   : 원본 메시지
        -- 이하 EVENT_META 에서 채워짐 --
        event_name   : 이벤트 이름
        signal       : START / END / POINT
        start_code   : 시작 코드
        end_code     : 종료 코드 (없으면 "—")
        is_motion    : "Y" / "N"
        remark       : 비고
        file_index   : 소속 로그 파일 번호 (1~10)
    """
    m = LOG_RE.match(line.strip())
    if not m:
        return None

    ts_raw, machine, rel, build, src_file, code, severity, msg = m.groups()

    # 등록된 이벤트 코드만 처리
    meta = EVENT_META.get(code)
    if meta is None:
        return None

    ev_name, signal, s_code, e_code, is_motion = meta

    try:
        ts_dt = parse_timestamp(ts_raw)
    except ValueError:
        return None

    return {
        # 파싱 원본 필드
        "ts_raw":      ts_raw,
        "ts_dt":       ts_dt,
        "machine":     machine,
        "rel":         rel,
        "build":       int(build),
        "src_file":    src_file,
        "severity":    severity,
        "origin_msg":  msg,
        # 이벤트 메타 필드
        "event_code":  code,
        "event_name":  ev_name,
        "signal":      signal,
        "start_code":  s_code,
        "end_code":    e_code if e_code else "—",
        "is_motion":   "Y" if is_motion else "N",
        "remark":      REMARK.get(code, ""),
        # 파일 추적
        "file_index":  file_index,
        # process_time 은 2차 패스에서 채워짐
        "process_time": None,
    }


# ──────────────────────────────────────────────────────────────
# 7. 전체 로그 파싱 (1차 패스)
# ──────────────────────────────────────────────────────────────
def parse_all_logs(log_dir: str, pattern: str = "*.log") -> list[dict]:
    """
    log_dir 내에서 pattern(글롭)에 매칭되는 모든 로그 파일을
    파일명 오름차순으로 파싱하여 레코드 리스트 반환.

    추가로, 다음 두 케이스를 분리하여 카운트·보고합니다:
      - malformed : LOG_RE 정규식과 매칭되지 않는 비어있지 않은 라인
      - unknown   : 형식은 맞지만 EVENT_META 에 등록되지 않은 이벤트 코드
                    → 새 이벤트 코드 발견 시 EVENT_META 보강을 위한 신호

    Args:
        log_dir : 로그 파일이 위치한 디렉터리 경로
        pattern : 파일명 글롭 패턴 (예: "*.log", "ER_event_log-*.log")

    Returns:
        레코드 딕셔너리의 리스트 (uid 미부여 상태)
    """
    records = []
    log_path = Path(log_dir)

    if not log_path.is_dir():
        print(f"  [ERROR] 로그 디렉터리를 찾을 수 없습니다: {log_path}", file=sys.stderr)
        return records

    files = sorted(log_path.glob(pattern))
    if not files:
        print(f"  [WARN] '{log_path}' 에서 패턴 '{pattern}' 에 매칭되는 파일이 없습니다.",
              file=sys.stderr)
        return records

    # 전체 누적 카운터
    unknown_codes: Counter = Counter()         # 미등록 이벤트 코드 → 발생 횟수
    unknown_examples: dict[str, str] = {}      # 코드별 첫 발견 메시지 샘플
    malformed_total = 0                        # LOG_RE 매칭 실패 라인 합계

    for file_num, filepath in enumerate(files, start=1):
        line_count = 0
        parsed_count = 0
        file_unknown = 0
        file_malformed = 0

        with open(filepath, encoding="utf-8", errors="replace") as f:
            for line in f:
                line_count += 1
                stripped = line.strip()
                if not stripped:
                    continue  # 빈 줄은 카운트 제외

                m = LOG_RE.match(stripped)
                if not m:
                    file_malformed += 1
                    continue

                code = m.group(6)
                if code not in EVENT_META:
                    unknown_codes[code] += 1
                    file_unknown += 1
                    # 첫 발견 샘플(컨텍스트 추정용) 1건만 저장
                    unknown_examples.setdefault(code, stripped[:160])
                    continue

                rec = parse_line(line, file_index=file_num)
                if rec:
                    rec["src_log"] = filepath.name
                    records.append(rec)
                    parsed_count += 1

        malformed_total += file_malformed

        # 파일별 한 줄 보고 (이슈가 있을 때만 부가 정보 표시)
        extra = ""
        if file_unknown or file_malformed:
            extra = f"  [unknown={file_unknown}, malformed={file_malformed}]"
        print(f"  [{file_num:02d}] {filepath.name}: "
              f"{line_count:,} 줄 → {parsed_count:,} 레코드 파싱{extra}")

    # ── 미등록 이벤트 코드 요약 ────────────────────────────────
    if unknown_codes:
        total_unknown = sum(unknown_codes.values())
        print(f"\n  [INFO] 미등록 이벤트 코드 {total_unknown:,}건 "
              f"({len(unknown_codes)}종) 감지 — EVENT_META 보강 검토 필요:")
        print(f"    {'Code':<10} {'Count':>8}  Sample")
        print("    " + "-" * 90)
        for code, cnt in unknown_codes.most_common():
            sample = unknown_examples.get(code, "")
            print(f"    {code:<10} {cnt:>8,}  {sample}")

    # ── 형식 불일치(malformed) 요약 ────────────────────────────
    if malformed_total:
        print(f"\n  [INFO] LOG_RE 매칭 실패 라인 {malformed_total:,}건 "
              f"(연속 메시지/주석/포맷 변경 가능성)")

    return records


# ──────────────────────────────────────────────────────────────
# 8. Process Time 계산 (2차 패스)
# ──────────────────────────────────────────────────────────────
def calc_process_time(records: list[dict]) -> list[dict]:
    """
    레코드 리스트를 순서대로 스캔하면서 START→END 페어를 매칭하여
    process_time(초) 을 계산합니다.

    매칭 키:
        (start_code, context_key)
        - start_code   : 시작 이벤트 코드
        - context_key  : wafer/lot 정보 (있으면 "w{N}_l{M}", 없으면 "")

    wafer/lot 정보가 없는 HW 레벨 이벤트(Chuck Exchange, IH cex 등)는
    context_key="" 로 동일하게 처리되므로, 동시에 2개 이상의 동일
    이벤트가 pending 되는 경우 가장 최근 START와 매칭됩니다.

    Args:
        records : parse_all_logs() 결과 리스트

    Returns:
        process_time 필드가 채워진 동일 리스트 (in-place 수정 후 반환)
    """
    # pending: (start_code, context_key) → (ts_dt, record_index)
    # 동일 키의 START가 중복될 경우 최신 것으로 덮어씁니다.
    pending: dict[tuple, tuple] = {}

    for idx, rec in enumerate(records):
        signal     = rec["signal"]
        start_code = rec["start_code"]
        ctx_key    = make_context_key(rec["origin_msg"])
        lookup_key = (start_code, ctx_key)

        if signal == "START":
            # pending 에 (타임스탬프, 인덱스) 저장
            pending[lookup_key] = (rec["ts_dt"], idx)

        elif signal == "END":
            if lookup_key in pending:
                start_dt, _ = pending.pop(lookup_key)
                delta = (rec["ts_dt"] - start_dt).total_seconds()
                # 음수 방지 (타임스탬프 순서 역전 케이스)
                rec["process_time"] = round(delta, 3) if delta >= 0 else None

    return records


# ──────────────────────────────────────────────────────────────
# 9. UID 부여 및 출력 레코드 정규화
# ──────────────────────────────────────────────────────────────
def assign_uid(records: list[dict]) -> list[dict]:
    """레코드 순서대로 1부터 uid 를 부여합니다."""
    for i, rec in enumerate(records, start=1):
        rec["uid"] = i
    return records


def to_output_record(rec: dict) -> dict:
    """
    내부 레코드 딕셔너리를 출력용 컬럼 순서 딕셔너리로 변환.
    ts_dt, ts_raw, machine, rel, build, src_file, severity,
    file_index 등 내부 처리용 필드는 제거합니다.
    """
    return {
        "uid":           rec["uid"],
        "datetime":      format_timestamp(rec["ts_dt"]),
        "event_name":    rec["event_name"],
        "event_code":    rec["event_code"],
        "signal":        rec["signal"],
        "start_code":    rec["start_code"],
        "end_code":      rec["end_code"],
        "process_time":  f"{rec['process_time']:.3f}s" if rec["process_time"] is not None else "",
        "origin_message": rec["origin_msg"],
        "is_motion_related": rec["is_motion"],
        "remark":        rec["remark"],
    }


# ──────────────────────────────────────────────────────────────
# 10. 통계 요약 출력
# ──────────────────────────────────────────────────────────────
def print_stats(records: list[dict]) -> None:
    """파싱 결과의 주요 통계를 콘솔에 출력합니다."""
    total = len(records)
    motion_y = sum(1 for r in records if r["is_motion"] == "Y")
    signal_cnt = Counter(r["signal"] for r in records)
    code_cnt   = Counter(r["event_code"] for r in records)

    # process_time 통계 (이벤트명 단위)
    pt_by_name: dict[str, list[float]] = defaultdict(list)
    for r in records:
        if r["process_time"] is not None:
            pt_by_name[r["event_name"]].append(r["process_time"])

    print("\n" + "="*60)
    print(f"  총 레코드 수       : {total:,}")
    print(f"  Motion Related (Y) : {motion_y:,} ({motion_y/total*100:.1f}%)")
    print(f"  Non-Motion    (N)  : {total-motion_y:,} ({(total-motion_y)/total*100:.1f}%)")
    print(f"  START 신호         : {signal_cnt['START']:,}")
    print(f"  END 신호           : {signal_cnt['END']:,}")
    print(f"  POINT 신호         : {signal_cnt['POINT']:,}")

    print("\n  ── 이벤트 코드 빈도 TOP 15 ──")
    for code, cnt in code_cnt.most_common(15):
        ev_name = EVENT_META[code][0] if code in EVENT_META else "?"
        print(f"    {code:<10}  {ev_name:<28}  {cnt:>6,}회")

    print("\n  ── Process Time 통계 (이벤트명, avg 내림차순) ──")
    print(f"    {'Event Name':<28} {'Count':>6}  {'Min':>8}  {'Max':>8}  {'Avg':>8}  {'StdDev':>8}")
    print("    " + "-"*72)
    for name, vals in sorted(pt_by_name.items(), key=lambda x: -statistics.mean(x[1])):
        avg = statistics.mean(vals)
        std = statistics.stdev(vals) if len(vals) > 1 else 0.0
        print(f"    {name:<28} {len(vals):>6,}  "
              f"{min(vals):>7.3f}s  {max(vals):>7.3f}s  "
              f"{avg:>7.3f}s  {std:>7.3f}s")
    print("="*60)


# ──────────────────────────────────────────────────────────────
# 11. 출력 함수
# ──────────────────────────────────────────────────────────────
FIELDNAMES = [
    "uid", "datetime", "event_name", "event_code", "signal",
    "start_code", "end_code", "process_time",
    "origin_message", "is_motion_related", "remark",
]

def save_csv(out_records: list[dict], filepath: str) -> None:
    """레코드 리스트를 CSV 파일로 저장합니다."""
    with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(out_records)
    sz = os.path.getsize(filepath) / 1024 / 1024
    print(f"  CSV 저장: {filepath}  ({sz:.1f} MB, {len(out_records):,} 행)")


def save_json(out_records: list[dict], filepath: str) -> None:
    """레코드 리스트를 JSON 파일로 저장합니다."""
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(out_records, f, ensure_ascii=False, indent=2)
    sz = os.path.getsize(filepath) / 1024 / 1024
    print(f"  JSON 저장: {filepath}  ({sz:.1f} MB, {len(out_records):,} 건)")


# ──────────────────────────────────────────────────────────────
# 12. 메인 진입점
# ──────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(
        description="ASML ER Event Log Parser — 파싱 + Process Time 계산"
    )
    parser.add_argument(
        "--log-dir", default="asml-log",
        help="로그 파일 디렉터리 경로 (기본값: ./asml-log)"
    )
    parser.add_argument(
        "--pattern", default="*.log",
        help="파일명 글롭 패턴 (기본값: *.log — 폴더 내 모든 .log 파일)"
    )
    parser.add_argument(
        "--out", choices=["csv", "json", "both"], default="both",
        help="출력 형식: csv / json / both (기본값: both)"
    )
    parser.add_argument(
        "--out-dir", default=".",
        help="출력 파일 저장 디렉터리 (기본값: 현재 디렉터리)"
    )
    parser.add_argument(
        "--stats", action="store_true",
        help="파싱 완료 후 통계 요약 출력"
    )
    args = parser.parse_args()

    print(f"\n[1/3] 로그 파싱 중... (디렉터리: {args.log_dir}, 패턴: {args.pattern})")
    records = parse_all_logs(args.log_dir, pattern=args.pattern)
    print(f"  → 총 {len(records):,} 레코드 파싱 완료\n")

    print("[2/3] Process Time 계산 중 (START→END 페어 매칭)...")
    records = calc_process_time(records)
    paired = sum(1 for r in records if r["process_time"] is not None)
    print(f"  → {paired:,} 건 process_time 계산 완료\n")

    print("[3/3] UID 부여 및 출력 레코드 정규화...")
    records = assign_uid(records)
    out_records = [to_output_record(r) for r in records]
    print(f"  → {len(out_records):,} 건 완료\n")

    # 출력 디렉터리 생성
    out_path = Path(args.out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    # 파일 저장
    if args.out in ("csv", "both"):
        save_csv(out_records, str(out_path / "asml_log_parsed.csv"))

    if args.out in ("json", "both"):
        save_json(out_records, str(out_path / "asml_log_parsed.json"))

    # 통계 출력
    if args.stats:
        print_stats(records)

    print("\n완료.")


if __name__ == "__main__":
    main()
