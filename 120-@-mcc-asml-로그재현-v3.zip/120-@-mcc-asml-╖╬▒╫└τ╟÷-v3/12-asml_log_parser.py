"""
ASML TWINSCAN XT 400F — ER Event Log Parser (12: external meta JSON)
=====================================================================
지정된 폴더(기본값: ./asml-log) 안의 모든 .log 파일을 파싱하여
uid / datetime / event_name / event_code / signal /
start_code / end_code / process_time / origin_message /
is_motion_related / remark 컬럼을 갖는 레코드를 생성합니다.

** 11 버전과의 차이 **
이벤트 메타 정의(EVENT_META / REMARK)를 소스에 하드코딩하지 않고
외부 JSON 파일(기본: event_meta.json)에서 로드합니다.
새 이벤트 코드 지원·remark 수정은 JSON 파일만 편집하면 됩니다.

사용법:
    python asml_log_parser.py                        # 기본: CSV + JSON 출력
    python asml_log_parser.py --out csv              # CSV 만 출력
    python asml_log_parser.py --out json             # JSON 만 출력
    python asml_log_parser.py --log-dir /path/logs   # 로그 디렉터리 지정
    python asml_log_parser.py --pattern "*.log"     # 파일명 글롭 패턴 지정
    python asml_log_parser.py --meta path/meta.json  # 메타 JSON 파일 지정
    python asml_log_parser.py --stats                # 통계 요약 출력
"""

import re
import json
import csv
import sys
import os
import argparse
import statistics
from datetime import datetime
from pathlib import Path
from collections import defaultdict, Counter


# ──────────────────────────────────────────────────────────────
# 1. 로그 레코드 파싱 정규식
# ──────────────────────────────────────────────────────────────
#  형식:
#  MM/DD/YYYY HH:MM:SS.ffff  Machine:ID  (Rel:버전, LOMW[빌드], 소스파일)
#  SYSTEM EVENT: 코드  심각도  메시지
LOG_RE = re.compile(
    r'^(\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2}\.\d+)'   # 그룹1: 타임스탬프
    r'\s+Machine:(\w+)'                                  # 그룹2: 머신 ID
    r'\s+\(Rel:([\w.]+),\s*LOMW\[(\d+)\],\s*([\w./]+)\)'  # 그룹3~5: 릴리즈/빌드/소스
    r'\s+SYSTEM EVENT:\s+(\S+)'                          # 그룹6: 이벤트 코드
    r'\s+(\w+)'                                          # 그룹7: 심각도
    r'\s+(.*?)$'                                         # 그룹8: 메시지
)

# wafer number / lot id 추출용 정규식 (process_time context_key 계산에 사용)
WAFER_LOT_RE = re.compile(r'wafer number (\d+), lot id (\d+)', re.IGNORECASE)


# ──────────────────────────────────────────────────────────────
# 2. 이벤트 메타 (외부 JSON 파일에서 로드)
# ──────────────────────────────────────────────────────────────
#  EVENT_META : event_code → (event_name, signal, start_code,
#                              end_code, is_motion_related)
#  REMARK     : event_code → 비고 문자열 (선택)
#
#  JSON 스키마 (event_meta.json):
#    {
#      "events": {
#        "<EVENT_CODE>": {
#          "name":              "Human-readable event name",
#          "signal":            "START | END | POINT",
#          "start_code":        "Paired START code",
#          "end_code":          "Paired END code (empty for POINT)",
#          "is_motion_related": true | false,
#          "remark":            "Optional note"   // 없으면 빈 문자열로 처리
#        },
#        ...
#      }
#    }
#
#  signal 종류:
#    START  - 동작 시작 이벤트
#    END    - 동작 종료 이벤트 (START와 쌍을 이루어 process_time 계산)
#    POINT  - 단독 발생 이벤트 (시작/종료 구분 없음)
#
#  is_motion_related:
#    true  - 스테이지 / 웨이퍼 / 척 등 물리적 모션 수반
#    false - 소프트웨어 상태, 로트 관리, 에러 핸들링 등
# ──────────────────────────────────────────────────────────────
EVENT_META: dict[str, tuple] = {}   # load_event_meta() 호출 시 채워짐
REMARK:     dict[str, str]   = {}   # load_event_meta() 호출 시 채워짐


def load_event_meta(meta_path: str) -> None:
    """
    JSON 파일에서 이벤트 메타 정의를 로드하여 EVENT_META / REMARK
    전역 사전을 인플레이스로 채웁니다.

    Args:
        meta_path : 메타 JSON 파일 경로 (예: "event_meta.json")

    Raises:
        SystemExit : 파일이 없거나, "events" 키가 누락되었거나,
                     필수 필드(name/signal)가 빠진 이벤트가 있을 때.
    """
    path = Path(meta_path)
    if not path.is_file():
        print(f"  [ERROR] 이벤트 메타 JSON 파일을 찾을 수 없습니다: {path}",
              file=sys.stderr)
        sys.exit(1)

    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        print(f"  [ERROR] 메타 JSON 파싱 실패: {path}\n         {e}",
              file=sys.stderr)
        sys.exit(1)

    # "events" 래퍼 허용 + 최상위 dict 직접 허용 (역호환)
    events = data.get("events") if isinstance(data, dict) else None
    if events is None and isinstance(data, dict):
        # _description, _schema 같은 메타 키 제외하고 코드 매핑만 사용
        events = {k: v for k, v in data.items()
                  if not k.startswith("_") and isinstance(v, dict)}
    if not events:
        print(f"  [ERROR] 메타 JSON 에 'events' 항목이 없습니다: {path}",
              file=sys.stderr)
        sys.exit(1)

    em: dict[str, tuple] = {}
    rm: dict[str, str]   = {}
    missing_fields: list[str] = []

    for code, ev in events.items():
        if not isinstance(ev, dict):
            missing_fields.append(f"{code} (object 아님)")
            continue
        try:
            em[code] = (
                ev["name"],
                ev["signal"],
                ev.get("start_code", code),
                ev.get("end_code", ""),
                bool(ev.get("is_motion_related", False)),
            )
        except KeyError as e:
            missing_fields.append(f"{code} (필수 필드 누락: {e.args[0]})")
            continue
        remark = ev.get("remark", "")
        if remark:
            rm[code] = remark

    if missing_fields:
        print(f"  [ERROR] 메타 JSON 형식 오류 — 다음 이벤트 정의 확인 필요:",
              file=sys.stderr)
        for line in missing_fields:
            print(f"           - {line}", file=sys.stderr)
        sys.exit(1)

    # 전역 사전 인플레이스 갱신 (다른 모듈에서 import 한 참조도 그대로 유효)
    EVENT_META.clear()
    EVENT_META.update(em)
    REMARK.clear()
    REMARK.update(rm)

    print(f"  이벤트 메타 로드: {path}  "
          f"(코드 {len(EVENT_META)}개, remark {len(REMARK)}개)")


# ──────────────────────────────────────────────────────────────
# 4. 타임스탬프 파싱 헬퍼
# ──────────────────────────────────────────────────────────────
def parse_timestamp(ts_str: str) -> datetime:
    """
    'MM/DD/YYYY HH:MM:SS.ffff' 형식의 타임스탬프를 datetime 객체로 변환.
    밀리초/마이크로초 자릿수가 4자리일 경우 6자리로 패딩.
    """
    # 소수점 이하를 6자리(마이크로초)로 표준화
    parts = ts_str.split('.')
    if len(parts) == 2:
        frac = parts[1].ljust(6, '0')[:6]
        ts_str = f"{parts[0]}.{frac}"
    return datetime.strptime(ts_str, "%m/%d/%Y %H:%M:%S.%f")


def format_timestamp(dt: datetime) -> str:
    """datetime → 'YYYY-MM-DD HH:MM:SS.fff' ISO 형식 문자열"""
    return dt.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]  # 마이크로초 → 밀리초


# ──────────────────────────────────────────────────────────────
# 5. context_key 생성
# ──────────────────────────────────────────────────────────────
def make_context_key(message: str) -> str:
    """
    동시 진행될 수 있는 동일 이벤트를 구분하기 위한 context key.

    - 메시지에 'wafer number N, lot id M' 이 포함된 경우
      → "w{N}_l{M}" 반환  (예: "w5_l101")
      → wafer/lot 단위로 START→END 페어를 정확히 매칭

    - 포함되지 않은 경우(HW 레벨 이벤트 등)
      → "" (빈 문자열) 반환
      → 동일 타입 이벤트 중 가장 최근 START와 매칭
    """
    m = WAFER_LOT_RE.search(message)
    if m:
        return f"w{m.group(1)}_l{m.group(2)}"
    return ""


# ──────────────────────────────────────────────────────────────
# 6. 단일 로그 라인 파싱
# ──────────────────────────────────────────────────────────────
def parse_line(line: str, file_index: int) -> dict | None:
    """
    로그 한 줄을 파싱하여 레코드 딕셔너리 반환.
    인식되지 않는 이벤트 코드는 None 반환.

    반환 딕셔너리 필드:
        ts_raw       : 원본 타임스탬프 문자열
        ts_dt        : datetime 객체 (process_time 계산용)
        machine      : 머신 ID
        rel          : 릴리즈 버전
        build        : LOMW 빌드 번호
        src_file     : 소스 파일명
        event_code   : 이벤트 코드 (예: LO-8025)
        severity     : DEFAULT / WARNING / ERROR / EVENT
        origin_msg   : 원본 메시지
        -- 이하 EVENT_META 에서 채워짐 --
        event_name   : 이벤트 이름
        signal       : START / END / POINT
        start_code   : 시작 코드
        end_code     : 종료 코드 (없으면 "—")
        is_motion    : "Y" / "N"
        remark       : 비고
        file_index   : 소속 로그 파일 번호 (1~10)
    """
    m = LOG_RE.match(line.strip())
    if not m:
        return None

    ts_raw, machine, rel, build, src_file, code, severity, msg = m.groups()

    # 등록된 이벤트 코드만 처리
    meta = EVENT_META.get(code)
    if meta is None:
        return None

    ev_name, signal, s_code, e_code, is_motion = meta

    try:
        ts_dt = parse_timestamp(ts_raw)
    except ValueError:
        return None

    return {
        # 파싱 원본 필드
        "ts_raw":      ts_raw,
        "ts_dt":       ts_dt,
        "machine":     machine,
        "rel":         rel,
        "build":       int(build),
        "src_file":    src_file,
        "severity":    severity,
        "origin_msg":  msg,
        # 이벤트 메타 필드
        "event_code":  code,
        "event_name":  ev_name,
        "signal":      signal,
        "start_code":  s_code,
        "end_code":    e_code if e_code else "—",
        "is_motion":   "Y" if is_motion else "N",
        "remark":      REMARK.get(code, ""),
        # 파일 추적
        "file_index":  file_index,
        # process_time 은 2차 패스에서 채워짐
        "process_time": None,
    }


# ──────────────────────────────────────────────────────────────
# 7. 전체 로그 파싱 (1차 패스)
# ──────────────────────────────────────────────────────────────
def parse_all_logs(log_dir: str, pattern: str = "*.log") -> list[dict]:
    """
    log_dir 내에서 pattern(글롭)에 매칭되는 모든 로그 파일을
    파일명 오름차순으로 파싱하여 레코드 리스트 반환.

    추가로, 다음 두 케이스를 분리하여 카운트·보고합니다:
      - malformed : LOG_RE 정규식과 매칭되지 않는 비어있지 않은 라인
      - unknown   : 형식은 맞지만 EVENT_META 에 등록되지 않은 이벤트 코드
                    → 새 이벤트 코드 발견 시 EVENT_META 보강을 위한 신호

    Args:
        log_dir : 로그 파일이 위치한 디렉터리 경로
        pattern : 파일명 글롭 패턴 (예: "*.log", "ER_event_log-*.log")

    Returns:
        레코드 딕셔너리의 리스트 (uid 미부여 상태)
    """
    records = []
    log_path = Path(log_dir)

    if not log_path.is_dir():
        print(f"  [ERROR] 로그 디렉터리를 찾을 수 없습니다: {log_path}", file=sys.stderr)
        return records

    files = sorted(log_path.glob(pattern))
    if not files:
        print(f"  [WARN] '{log_path}' 에서 패턴 '{pattern}' 에 매칭되는 파일이 없습니다.",
              file=sys.stderr)
        return records

    # 전체 누적 카운터
    unknown_codes: Counter = Counter()         # 미등록 이벤트 코드 → 발생 횟수
    unknown_examples: dict[str, str] = {}      # 코드별 첫 발견 메시지 샘플
    malformed_total = 0                        # LOG_RE 매칭 실패 라인 합계

    for file_num, filepath in enumerate(files, start=1):
        line_count = 0
        parsed_count = 0
        file_unknown = 0
        file_malformed = 0

        with open(filepath, encoding="utf-8", errors="replace") as f:
            for line in f:
                line_count += 1
                stripped = line.strip()
                if not stripped:
                    continue  # 빈 줄은 카운트 제외

                m = LOG_RE.match(stripped)
                if not m:
                    file_malformed += 1
                    continue

                code = m.group(6)
                if code not in EVENT_META:
                    unknown_codes[code] += 1
                    file_unknown += 1
                    # 첫 발견 샘플(컨텍스트 추정용) 1건만 저장
                    unknown_examples.setdefault(code, stripped[:160])
                    continue

                rec = parse_line(line, file_index=file_num)
                if rec:
                    rec["src_log"] = filepath.name
                    records.append(rec)
                    parsed_count += 1

        malformed_total += file_malformed

        # 파일별 한 줄 보고 (이슈가 있을 때만 부가 정보 표시)
        extra = ""
        if file_unknown or file_malformed:
            extra = f"  [unknown={file_unknown}, malformed={file_malformed}]"
        print(f"  [{file_num:02d}] {filepath.name}: "
              f"{line_count:,} 줄 → {parsed_count:,} 레코드 파싱{extra}")

    # ── 미등록 이벤트 코드 요약 ────────────────────────────────
    if unknown_codes:
        total_unknown = sum(unknown_codes.values())
        print(f"\n  [INFO] 미등록 이벤트 코드 {total_unknown:,}건 "
              f"({len(unknown_codes)}종) 감지 — EVENT_META 보강 검토 필요:")
        print(f"    {'Code':<10} {'Count':>8}  Sample")
        print("    " + "-" * 90)
        for code, cnt in unknown_codes.most_common():
            sample = unknown_examples.get(code, "")
            print(f"    {code:<10} {cnt:>8,}  {sample}")

    # ── 형식 불일치(malformed) 요약 ────────────────────────────
    if malformed_total:
        print(f"\n  [INFO] LOG_RE 매칭 실패 라인 {malformed_total:,}건 "
              f"(연속 메시지/주석/포맷 변경 가능성)")

    return records


# ──────────────────────────────────────────────────────────────
# 8. Process Time 계산 (2차 패스)
# ──────────────────────────────────────────────────────────────
def calc_process_time(records: list[dict]) -> list[dict]:
    """
    레코드 리스트를 순서대로 스캔하면서 START→END 페어를 매칭하여
    process_time(초) 을 계산합니다.

    매칭 키:
        (start_code, context_key)
        - start_code   : 시작 이벤트 코드
        - context_key  : wafer/lot 정보 (있으면 "w{N}_l{M}", 없으면 "")

    wafer/lot 정보가 없는 HW 레벨 이벤트(Chuck Exchange, IH cex 등)는
    context_key="" 로 동일하게 처리되므로, 동시에 2개 이상의 동일
    이벤트가 pending 되는 경우 가장 최근 START와 매칭됩니다.

    Args:
        records : parse_all_logs() 결과 리스트

    Returns:
        process_time 필드가 채워진 동일 리스트 (in-place 수정 후 반환)
    """
    # pending: (start_code, context_key) → (ts_dt, record_index)
    # 동일 키의 START가 중복될 경우 최신 것으로 덮어씁니다.
    pending: dict[tuple, tuple] = {}

    for idx, rec in enumerate(records):
        signal     = rec["signal"]
        start_code = rec["start_code"]
        ctx_key    = make_context_key(rec["origin_msg"])
        lookup_key = (start_code, ctx_key)

        if signal == "START":
            # pending 에 (타임스탬프, 인덱스) 저장
            pending[lookup_key] = (rec["ts_dt"], idx)

        elif signal == "END":
            if lookup_key in pending:
                start_dt, _ = pending.pop(lookup_key)
                delta = (rec["ts_dt"] - start_dt).total_seconds()
                # 음수 방지 (타임스탬프 순서 역전 케이스)
                rec["process_time"] = round(delta, 3) if delta >= 0 else None

    return records


# ──────────────────────────────────────────────────────────────
# 9. UID 부여 및 출력 레코드 정규화
# ──────────────────────────────────────────────────────────────
def assign_uid(records: list[dict]) -> list[dict]:
    """레코드 순서대로 1부터 uid 를 부여합니다."""
    for i, rec in enumerate(records, start=1):
        rec["uid"] = i
    return records


def to_output_record(rec: dict) -> dict:
    """
    내부 레코드 딕셔너리를 출력용 컬럼 순서 딕셔너리로 변환.
    ts_dt, ts_raw, machine, rel, build, src_file, severity,
    file_index 등 내부 처리용 필드는 제거합니다.
    """
    return {
        "uid":           rec["uid"],
        "datetime":      format_timestamp(rec["ts_dt"]),
        "event_name":    rec["event_name"],
        "event_code":    rec["event_code"],
        "signal":        rec["signal"],
        "start_code":    rec["start_code"],
        "end_code":      rec["end_code"],
        "process_time":  f"{rec['process_time']:.3f}s" if rec["process_time"] is not None else "",
        "origin_message": rec["origin_msg"],
        "is_motion_related": rec["is_motion"],
        "remark":        rec["remark"],
    }


# ──────────────────────────────────────────────────────────────
# 10. 통계 요약 출력
# ──────────────────────────────────────────────────────────────
def print_stats(records: list[dict]) -> None:
    """파싱 결과의 주요 통계를 콘솔에 출력합니다."""
    total = len(records)
    motion_y = sum(1 for r in records if r["is_motion"] == "Y")
    signal_cnt = Counter(r["signal"] for r in records)
    code_cnt   = Counter(r["event_code"] for r in records)

    # process_time 통계 (이벤트명 단위)
    pt_by_name: dict[str, list[float]] = defaultdict(list)
    for r in records:
        if r["process_time"] is not None:
            pt_by_name[r["event_name"]].append(r["process_time"])

    print("\n" + "="*60)
    print(f"  총 레코드 수       : {total:,}")
    print(f"  Motion Related (Y) : {motion_y:,} ({motion_y/total*100:.1f}%)")
    print(f"  Non-Motion    (N)  : {total-motion_y:,} ({(total-motion_y)/total*100:.1f}%)")
    print(f"  START 신호         : {signal_cnt['START']:,}")
    print(f"  END 신호           : {signal_cnt['END']:,}")
    print(f"  POINT 신호         : {signal_cnt['POINT']:,}")

    print("\n  ── 이벤트 코드 빈도 TOP 15 ──")
    for code, cnt in code_cnt.most_common(15):
        ev_name = EVENT_META[code][0] if code in EVENT_META else "?"
        print(f"    {code:<10}  {ev_name:<28}  {cnt:>6,}회")

    print("\n  ── Process Time 통계 (이벤트명, avg 내림차순) ──")
    print(f"    {'Event Name':<28} {'Count':>6}  {'Min':>8}  {'Max':>8}  {'Avg':>8}  {'StdDev':>8}")
    print("    " + "-"*72)
    for name, vals in sorted(pt_by_name.items(), key=lambda x: -statistics.mean(x[1])):
        avg = statistics.mean(vals)
        std = statistics.stdev(vals) if len(vals) > 1 else 0.0
        print(f"    {name:<28} {len(vals):>6,}  "
              f"{min(vals):>7.3f}s  {max(vals):>7.3f}s  "
              f"{avg:>7.3f}s  {std:>7.3f}s")
    print("="*60)


# ──────────────────────────────────────────────────────────────
# 11. 출력 함수
# ──────────────────────────────────────────────────────────────
FIELDNAMES = [
    "uid", "datetime", "event_name", "event_code", "signal",
    "start_code", "end_code", "process_time",
    "origin_message", "is_motion_related", "remark",
]

def save_csv(out_records: list[dict], filepath: str) -> None:
    """레코드 리스트를 CSV 파일로 저장합니다."""
    with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(out_records)
    sz = os.path.getsize(filepath) / 1024 / 1024
    print(f"  CSV 저장: {filepath}  ({sz:.1f} MB, {len(out_records):,} 행)")


def save_json(out_records: list[dict], filepath: str) -> None:
    """레코드 리스트를 JSON 파일로 저장합니다."""
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(out_records, f, ensure_ascii=False, indent=2)
    sz = os.path.getsize(filepath) / 1024 / 1024
    print(f"  JSON 저장: {filepath}  ({sz:.1f} MB, {len(out_records):,} 건)")


# ──────────────────────────────────────────────────────────────
# 12. 메인 진입점
# ──────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(
        description="ASML ER Event Log Parser — 파싱 + Process Time 계산"
    )
    parser.add_argument(
        "--log-dir", default="asml-log",
        help="로그 파일 디렉터리 경로 (기본값: ./asml-log)"
    )
    parser.add_argument(
        "--pattern", default="*.log",
        help="파일명 글롭 패턴 (기본값: *.log — 폴더 내 모든 .log 파일)"
    )
    parser.add_argument(
        "--meta", default="event_meta.json",
        help="이벤트 메타 JSON 파일 경로 (기본값: ./event_meta.json)"
    )
    parser.add_argument(
        "--out", choices=["csv", "json", "both"], default="both",
        help="출력 형식: csv / json / both (기본값: both)"
    )
    parser.add_argument(
        "--out-dir", default=".",
        help="출력 파일 저장 디렉터리 (기본값: 현재 디렉터리)"
    )
    parser.add_argument(
        "--stats", action="store_true",
        help="파싱 완료 후 통계 요약 출력"
    )
    args = parser.parse_args()

    print(f"\n[0/3] 이벤트 메타 로드 중...")
    load_event_meta(args.meta)

    print(f"\n[1/3] 로그 파싱 중... (디렉터리: {args.log_dir}, 패턴: {args.pattern})")
    records = parse_all_logs(args.log_dir, pattern=args.pattern)
    print(f"  → 총 {len(records):,} 레코드 파싱 완료\n")

    print("[2/3] Process Time 계산 중 (START→END 페어 매칭)...")
    records = calc_process_time(records)
    paired = sum(1 for r in records if r["process_time"] is not None)
    print(f"  → {paired:,} 건 process_time 계산 완료\n")

    print("[3/3] UID 부여 및 출력 레코드 정규화...")
    records = assign_uid(records)
    out_records = [to_output_record(r) for r in records]
    print(f"  → {len(out_records):,} 건 완료\n")

    # 출력 디렉터리 생성
    out_path = Path(args.out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    # 파일 저장
    if args.out in ("csv", "both"):
        save_csv(out_records, str(out_path / "asml_log_parsed.csv"))

    if args.out in ("json", "both"):
        save_json(out_records, str(out_path / "asml_log_parsed.json"))

    # 통계 출력
    if args.stats:
        print_stats(records)

    print("\n완료.")


if __name__ == "__main__":
    main()
