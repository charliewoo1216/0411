"""
Step 3 — Verification (Motion Pairing).
이벤트분석_v2.md 의 후보를 구체 모션으로 정의. 4종 페어링 패턴 분류.
"""
from __future__ import annotations

import re

import streamlit as st

from utils import file_manager
from utils.debug_logger import log_event
from utils.llm_client import build_client_from_session


SYSTEM_PAIRING = (
    "당신은 제조 장비 모션 이벤트 페어링 설계자입니다. "
    "이벤트 분석 결과를 근거로 '어떤 이벤트끼리 하나의 모션을 이루는가'를 정의합니다. "
    "응답은 요청된 형식의 마크다운 문서만 출력합니다."
)

# motion_notes.json 자동 생성용 — v2 확정 시 1회 호출
NOTES_SYSTEM = (
    "당신은 JSON 생성기입니다. 주어진 문서의 내용을 근거로 "
    "각 motion_type 에 대한 한글 1줄 설명을 JSON 객체로만 출력합니다. "
    "설명/주석/markdown 펜스 없이 **순수 JSON 객체** 만 출력하세요."
)
NOTES_PROMPT = """아래 문서를 바탕으로 **파서의 motion_type 이름별 한글 1줄 설명 JSON** 을 작성하세요.

[모션_페어링_분석_v2.md]
{doc}

요구사항:
- 키는 아래 motion_type 식별자 중에서 해당 문서에 근거가 있는 것만 포함 (없는 항목은 생략):
  `Transfer`, `Alignment`, `Exposure`, `Stage`, `Scan`, `FocusCheck`,
  `Positioning`, `System`, `Robot`, `WaferLoad`, `WaferUnload`,
  `ChuckLock`, `ChuckRelease`, `PreAlign`, `MarkCheck`, `Field`
- 문서에 더 적합한 motion_type 이름이 있다면 추가해도 됨 (영문 식별자).
- 값은 한글 1줄 (80자 이내), 주요 Start/End 이벤트 코드·중간상태·entity key 를 요약.
- 예: `"Transfer": "웨이퍼 이송 — TR1001→TR1099, 로봇 RB2xxx 수집"`

**JSON 객체만 출력.** 앞뒤에 설명 금지, ```json 펜스 금지."""


_JSON_OBJ_RE = re.compile(r"\{.*\}", re.DOTALL)


def _extract_json_object(text: str) -> dict | None:
    """LLM 응답에서 첫 {…} 블록 추출."""
    import json as _json
    m = _JSON_OBJ_RE.search(text)
    if not m:
        return None
    try:
        obj = _json.loads(m.group(0))
        if isinstance(obj, dict):
            return obj
    except Exception:
        return None
    return None

PROMPT_PAIRING_V1 = """다음 3개 입력을 참고해 **모션_페어링_분석_v1.md** 를 작성하세요.

[원시로그템플릿.md]
{template}

[이벤트분석_v2.md]
{events_v2}

[샘플 로그 (일부)]
{log_sample}
[샘플 로그 끝]

반드시 포함할 내용:
1. **모션 타입 목록** — 마크다운 테이블 (이름 / 패턴 / Start / End / 중간상태 / 엔티티키)
   - 패턴 값: `Simple`, `Group`, `Conditional`, `EntityKey`, `Single`(단일 이벤트)
2. **페어링 조건** — 엔티티 키(Wafer/Seq/Robot 등), 필드값 분기
3. **중첩 모션** — 부모/자식 관계 (예: EXPOSE 안에 SCAN)
4. **중간 상태 처리** — 반복 이벤트(AL101~AL1N9 등)를 attributes로 수집하는 규칙
5. **웨이퍼/장비 1 사이클 전체 시퀀스** — 순서대로 나열
6. **SQLite 저장 필드 목록** — motion_type, wafer_id, severity 등

마크다운만 출력하세요."""

CHAT_SYSTEM = """당신은 모션 페어링 설계자입니다. 엔지니어와 대화하며 모션_페어링_분석_v1.md 를 다듬습니다.

규칙:
- 엔지니어의 의도(중첩, severity 규칙, 제외 이벤트 등)를 정확히 반영하세요.
- **문서 재작성**이 필요할 땐 응답 말미에 ```markdown 펜스로 감싼 완전한 md 를 포함하고,
  본문에 "모션_페어링_분석_v1.md를 업데이트합니다" 문구를 포함하세요.

[원시로그템플릿.md]
{template}

[이벤트분석_v2.md]
{events_v2}

[현재 모션_페어링_분석_v1.md]
{current_md}
"""


_MD_BLOCK_RE = re.compile(r"```(?:markdown|md)?\s*\n(.*?)```", re.DOTALL)


def _extract_md(response: str) -> str | None:
    m = _MD_BLOCK_RE.search(response)
    return m.group(1).strip() if m else None


def _join_sample(lines: list[str], max_lines: int = 2000) -> str:
    return "\n".join(lines[:max_lines])


def _render_header() -> None:
    st.header("03 · Verification")
    st.caption("후보 이벤트를 실제 '모션'으로 구체화. Start/End 쌍, 그룹 시퀀스, 조건 분기, 엔티티 키로 분리 규칙을 정의 후 사용자 확정.")
    st.divider()


def _render_pattern_cards() -> None:
    st.markdown("**▸ 페어링 패턴 4종**")
    cards = [
        ("① Simple Pair", "g", "Start/End 이벤트가 1:1로 매칭. (예: TR1001 → TR1099)"),
        ("② Group Seq",  "p", "헤더 → 바디(반복) → 결과 구조. (예: AL100 → AL10x → AL199)"),
        ("③ Conditional","o", "필드값으로 severity/분기. (예: EX599.Result=NG)"),
        ("④ Entity Key", "b", "Wafer/Robot 등 키로 모션 분리."),
    ]
    cols = st.columns(4)
    for (title, color, desc), col in zip(cards, cols):
        with col:
            with st.container(border=True):
                st.markdown(f"**{title}**")
                st.caption(desc)


def render() -> None:
    _render_header()

    template_md = file_manager.load_md("원시로그템플릿.md")
    events_v2_md = file_manager.load_md("이벤트분석_v2.md")
    if not template_md or not events_v2_md:
        st.warning("⚠ 이전 Step의 출력물이 없습니다. Step 2를 먼저 완료하세요.")
        return

    # 참조 문서 expander
    with st.expander("📄 원시로그템플릿.md", expanded=False):
        st.markdown(template_md)
    with st.expander("📄 이벤트분석_v2.md", expanded=False):
        st.markdown(events_v2_md)

    _render_pattern_cards()
    st.divider()

    # 3-1. 페어링 v1 생성
    _section_pairing_v1(template_md, events_v2_md)

    pairing_v1 = file_manager.load_md("모션_페어링_분석_v1.md")
    if not pairing_v1:
        return

    st.divider()

    # 3-2. 채팅 + v2 확정
    _section_chat_and_confirm(template_md, events_v2_md)


def _section_pairing_v1(template_md: str, events_v2_md: str) -> None:
    st.markdown("**▸ 3-1. 모션_페어링_분석_v1.md**")

    existing = file_manager.load_md("모션_페어링_분석_v1.md")
    sampled = st.session_state.get("sampled_lines", [])

    c1, c2 = st.columns([1, 4])
    with c1:
        clicked = st.button(
            "🔄 재생성" if existing else "▶ 페어링 분석 생성",
            type="primary",
            width="stretch",
            key="btn_pairing_v1",
        )
    with c2:
        if existing:
            st.success("✓ `output/모션_페어링_분석_v1.md` 저장됨.")

    if clicked:
        log_event("step3", "페어링_v1 생성 시작")
        client = build_client_from_session()
        prompt = PROMPT_PAIRING_V1.format(
            template=template_md,
            events_v2=events_v2_md,
            log_sample=_join_sample(sampled, 2000),
        )
        messages = [
            {"role": "system", "content": SYSTEM_PAIRING},
            {"role": "user", "content": prompt},
        ]
        st.markdown("#### 생성 중 (스트리밍)")
        try:
            full = st.write_stream(client.stream_chat(
                messages, temperature=0.2, max_tokens=8000,
                step="step3", purpose="페어링_v1",
            ))
            if isinstance(full, list):
                full = "".join(full)
            file_manager.save_md("모션_페어링_분석_v1.md", full)
            st.session_state["step3_pairing_v1_done"] = True
            log_event("step3", "모션_페어링_분석_v1.md 저장", f"{len(full)} chars")
            st.success("모션_페어링_분석_v1.md 저장 완료.")
            st.rerun()
        except Exception as e:
            log_event("step3", "페어링_v1 생성 실패", str(e))
            st.error(f"LLM 호출 실패: {e}")

    existing = file_manager.load_md("모션_페어링_분석_v1.md")
    if existing:
        with st.expander("📄 모션_페어링_분석_v1.md 보기", expanded=False):
            st.markdown(existing)


def _section_chat_and_confirm(template_md: str, events_v2_md: str) -> None:
    st.markdown("**▸ 3-2. 엔지니어 검증 대화 → v2 확정**")

    history: list[dict] = st.session_state.get("step3_chat_history", [])
    if not history:
        history.append({
            "role": "assistant",
            "content": "페어링 v1 초안이 준비됐습니다. 중첩 구조, severity 규칙, 제외할 이벤트 등을 알려주세요. 필요 시 md 전체를 재작성합니다.",
        })
        st.session_state["step3_chat_history"] = history

    for msg in history:
        role = msg["role"]
        avatar = "🤖" if role == "assistant" else "👤"
        with st.chat_message(role, avatar=avatar):
            st.markdown(msg["content"])

    user_input = st.chat_input("검증 사항 입력... (예: EXPOSE 안에 SCAN 포함 / EX599 NG도 이벤트 기록)")
    if user_input:
        history.append({"role": "user", "content": user_input})
        with st.chat_message("user", avatar="👤"):
            st.markdown(user_input)

        current_md = file_manager.load_md("모션_페어링_분석_v1.md") or ""
        system_msg = CHAT_SYSTEM.format(
            template=template_md, events_v2=events_v2_md, current_md=current_md
        )
        messages = [{"role": "system", "content": system_msg}]
        for m in history:
            messages.append({"role": m["role"], "content": m["content"]})

        log_event("step3", "채팅 턴", user_input[:80])
        client = build_client_from_session()
        with st.chat_message("assistant", avatar="🤖"):
            try:
                full = st.write_stream(client.stream_chat(
                    messages, temperature=0.3, max_tokens=6000,
                    step="step3", purpose="chat",
                ))
                if isinstance(full, list):
                    full = "".join(full)
            except Exception as e:
                full = f"⚠ LLM 호출 실패: {e}"
                log_event("step3", "채팅 실패", str(e))
                st.error(full)

        history.append({"role": "assistant", "content": full})
        st.session_state["step3_chat_history"] = history

        if "모션_페어링_분석_v1.md를 업데이트" in full or "페어링_분석_v1.md를 업데이트" in full:
            new_md = _extract_md(full)
            if new_md:
                file_manager.save_md("모션_페어링_분석_v1.md", new_md)
                st.toast("✓ 모션_페어링_분석_v1.md 자동 업데이트 완료")

        st.rerun()

    st.write("")
    c1, c2 = st.columns([1, 4])
    with c1:
        confirm = st.button(
            "✓ v2 확정 저장",
            type="primary",
            width="stretch",
            key="btn_confirm_v2_step3",
        )
    with c2:
        if st.session_state.get("step3_done"):
            st.success("✓ `모션_페어링_분석_v2.md` 저장됨. Step 4 활성화됨.")

    # motion_notes.json 미리보기 (있을 때만)
    notes_existing = file_manager.load_json("motion_notes.json")
    if notes_existing:
        with st.expander(f"📄 motion_notes.json ({len(notes_existing)} motion_type)", expanded=False):
            import pandas as pd
            df = pd.DataFrame(
                [{"motion_type": k, "한글 설명": v} for k, v in notes_existing.items()]
            )
            st.dataframe(df, width="stretch", hide_index=True)

    if confirm:
        v1 = file_manager.load_md("모션_페어링_분석_v1.md")
        if not v1:
            st.error("모션_페어링_분석_v1.md 가 없습니다.")
            return
        file_manager.save_md("모션_페어링_분석_v2.md", v1)
        st.session_state["step3_done"] = True
        log_event("step3", "v2 확정 저장", f"모션_페어링_분석_v2.md ({len(v1)} chars)")

        # motion_notes.json 자동 생성 (LLM 1회 호출, 실패해도 flow 는 계속)
        with st.spinner("motion_notes.json 생성 중 (한글 설명 추출)..."):
            try:
                client = build_client_from_session()
                messages = [
                    {"role": "system", "content": NOTES_SYSTEM},
                    {"role": "user", "content": NOTES_PROMPT.format(doc=v1)},
                ]
                resp = client.chat(
                    messages, temperature=0.2, max_tokens=2000,
                    step="step3", purpose="motion_notes",
                )
                notes = _extract_json_object(resp)
                if notes:
                    file_manager.save_json("motion_notes.json", notes)
                    log_event("step3", "motion_notes.json 저장", f"{len(notes)} keys")
                    st.success(f"✓ 모션_페어링_분석_v2.md + motion_notes.json ({len(notes)} keys) 저장 완료.")
                else:
                    log_event("step3", "motion_notes 추출 실패", "JSON 파싱 실패")
                    st.warning("✓ v2.md 저장됨. 단 motion_notes.json 자동 생성 실패 (LLM 응답에서 JSON 추출 불가).")
            except Exception as e:
                log_event("step3", "motion_notes 생성 예외", str(e))
                st.warning(f"✓ v2.md 저장됨. motion_notes.json 생성 실패: {e}")
        st.rerun()
