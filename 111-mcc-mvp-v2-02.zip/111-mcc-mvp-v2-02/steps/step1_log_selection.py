"""
Step 1 — Log Selection.
mcc-log-file/ 하위를 재귀 탐색하고 균등 샘플링해서 session_state['sampled_lines']에 저장.
LLM 미사용.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from utils import log_sampler
from utils.debug_logger import log_event


MCC_DIR = "mcc-log-file"


def _render_header() -> None:
    st.header("01 · Log Selection")
    st.caption(
        "mcc-log-file/ 폴더 하위를 재귀 탐색하고, 파일 크기에 비례한 균등 샘플링으로 "
        "LLM 토큰 예산(180k) 안에 맞춘다. · Sampler · No LLM"
    )
    st.divider()


def render() -> None:
    _render_header()

    # 폴더 존재 확인
    mcc_path = Path(MCC_DIR)
    if not mcc_path.exists():
        st.warning(f"📁 `{MCC_DIR}/` 폴더가 없습니다. 원시 로그 파일(.log/.txt/.csv)을 해당 폴더에 추가해주세요.")
        return

    # 파일 스캔
    with st.spinner("로그 파일 스캔 중..."):
        file_infos = log_sampler.scan_log_files(MCC_DIR)

    if not file_infos:
        st.warning(f"📄 `{MCC_DIR}/` 에 로그 파일(.log/.txt/.csv)이 없습니다. 파일을 추가해주세요.")
        return

    # 파일 목록 테이블
    st.subheader("▸ 탐지된 로그 파일")
    df_rows = [
        {
            "파일": info["rel"],
            "크기(MB)": info["size_mb"],
            "총 라인": info["total_lines"],
            "인코딩": info.get("encoding") or "FAIL",
        }
        for info in file_infos
    ]
    df = pd.DataFrame(df_rows)
    st.dataframe(df, width="stretch", hide_index=True)

    total_lines = sum(i["total_lines"] for i in file_infos if i.get("encoding"))
    total_size = sum(i["size_mb"] for i in file_infos)

    # 요약 메트릭
    c1, c2, c3 = st.columns(3)
    c1.metric("파일 수", f"{len(file_infos):,}")
    c2.metric("총 라인 수", f"{total_lines:,}")
    c3.metric("총 크기 (MB)", f"{total_size:,.1f}")

    st.write("")

    # 샘플링 슬라이더
    st.subheader("▸ 샘플링 설정")
    default_target = min(120_000, max(10_000, total_lines))
    target_lines = st.slider(
        "샘플 라인 수 (180k 토큰 안전 마진 기준 120,000 권장)",
        min_value=10_000,
        max_value=200_000,
        value=default_target,
        step=5_000,
    )

    # 샘플링 시작 버튼
    if st.button("▶ 샘플링 시작", type="primary"):
        log_event("step1", "샘플링 시작", f"target={target_lines:,}, files={len(file_infos)}")
        progress = st.progress(0.0, text="샘플링 시작...")
        status = st.empty()

        def _cb(i: int, total: int, name: str) -> None:
            ratio = (i + 1) / max(1, total)
            progress.progress(min(1.0, ratio), text=f"처리 중: {name}")

        sampled = log_sampler.sample_logs(file_infos, target_lines, progress_cb=_cb)
        progress.progress(1.0, text="완료")
        status.empty()

        st.session_state["sampled_lines"] = sampled
        st.session_state["step1_done"] = len(sampled) > 0
        est = log_sampler.estimate_tokens(sampled)
        log_event("step1", "샘플링 완료", f"sampled={len(sampled):,}, est_tokens={est:,}")

    # 결과 표시
    sampled = st.session_state.get("sampled_lines", [])
    if sampled:
        est_tokens = log_sampler.estimate_tokens(sampled)

        st.divider()
        st.subheader("▸ 샘플링 결과")

        c1, c2, c3 = st.columns(3)
        c1.metric("샘플 라인", f"{len(sampled):,}")
        c2.metric("예상 토큰", f"{est_tokens:,}")
        c3.metric("예산 대비", f"{est_tokens / 180_000:.0%}")

        if est_tokens > 180_000:
            st.error("⚠ 예상 토큰이 180k 예산을 초과합니다. 슬라이더를 낮춰주세요.")
        else:
            st.success(f"✓ 샘플 {len(sampled):,}줄 확보. Step 2로 이동하세요.")

        with st.expander("샘플 미리보기 (앞 100줄)"):
            preview = "\n".join(sampled[:100])
            st.code(preview, language="text")
