"""
AI 설정 사이드바 — LLM Base URL / Model / API Key 입력 UI.
session_state['ai_config'] 에 현재 설정을 보관한다.
"""
from __future__ import annotations

import streamlit as st


DEFAULT_CONFIG: dict = {
    "base_url": "http://192.168.0.8:8080/v1",
    "model": "qwen3.5:9b",
    "api_key": "sk_123!",
    # 추론(thinking) 사용 여부. False 면 프롬프트에 `/no_think` 를 주입해
    # Qwen3 계열의 <think>/Thinking Process 생성을 억제한다. (API 파라미터는 미사용)
    "enable_thinking": False,
    # 코드 생성(Step4) 및 클라이언트 기본 응답 최대 토큰. 코드가 잘리면 키운다.
    "max_tokens": 64000,
}




def render_config_sidebar() -> dict:
    """사이드바 상단에 AI Config 섹션을 렌더링하고 현재 설정 dict을 반환한다."""
    if "ai_config" not in st.session_state:
        st.session_state["ai_config"] = DEFAULT_CONFIG.copy()

    cfg = st.session_state["ai_config"]

    with st.sidebar:
        st.markdown(
            """
            <div class="mcc-side-title">⚙ AI CONFIG</div>
            """,
            unsafe_allow_html=True,
        )
        cfg["base_url"] = st.text_input(
            "Base URL",
            value=cfg.get("base_url", DEFAULT_CONFIG["base_url"]),
            key="cfg_base_url",
        )
        cfg["model"] = st.text_input(
            "Model",
            value=cfg.get("model", DEFAULT_CONFIG["model"]),
            key="cfg_model",
        )
        cfg["api_key"] = st.text_input(
            "API Key",
            value=cfg.get("api_key", DEFAULT_CONFIG["api_key"]),
            type="password",
            key="cfg_api_key",
        )
        cfg["enable_thinking"] = st.checkbox(
            "🧠 추론(thinking) 사용",
            value=bool(cfg.get("enable_thinking", DEFAULT_CONFIG["enable_thinking"])),
            key="cfg_enable_thinking",
            help="끄면 프롬프트에 `/no_think` 를 주입해 <think>/Thinking Process 생성을 억제합니다. "
                 "(API 파라미터는 사용하지 않음)",
        )
        cfg["max_tokens"] = int(st.number_input(
            "Max Tokens",
            min_value=1000, max_value=64000, step=1000,
            value=int(cfg.get("max_tokens", DEFAULT_CONFIG["max_tokens"])),
            key="cfg_max_tokens",
            help="코드 생성(Step4) 및 기본 응답 최대 토큰. 코드가 잘리면 키우세요.",
        ))

    st.session_state["ai_config"] = cfg
    return cfg
