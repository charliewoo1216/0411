"""
로그 파일 탐색 + 균등 샘플링 유틸.
- scan_log_files(): .log/.txt/.csv 재귀 탐색, 인코딩 자동 감지, 라인 수 카운트
- sample_logs(): 파일별 비례 배분 + stride 균등 샘플링
- estimate_tokens(): 글자수 / 3.5 로 토큰 추정
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Iterable

# 인코딩 시도 순서 — 한국어 로그 호환
ENCODING_CANDIDATES = ["utf-8", "utf-8-sig", "cp949", "euc-kr", "latin-1"]
LOG_SUFFIXES = {".log", ".txt", ".csv"}


def _detect_encoding(path: Path) -> str | None:
    """여러 인코딩을 시도해서 첫 N바이트를 정상 디코딩하는 인코딩을 반환."""
    try:
        raw = path.read_bytes()[:4096]
    except Exception:
        return None
    for enc in ENCODING_CANDIDATES:
        try:
            raw.decode(enc)
            return enc
        except UnicodeDecodeError:
            continue
    return None


def _count_lines(path: Path, encoding: str) -> int:
    try:
        with path.open("r", encoding=encoding, errors="replace") as f:
            return sum(1 for _ in f)
    except Exception:
        return 0


def scan_log_files(base_dir: str | Path) -> list[dict]:
    """base_dir 하위를 재귀 탐색해 로그 파일 정보 리스트를 반환."""
    base = Path(base_dir)
    if not base.exists():
        return []

    infos: list[dict] = []
    for p in base.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() not in LOG_SUFFIXES:
            continue
        enc = _detect_encoding(p)
        if enc is None:
            # 인코딩 감지 실패 시 스킵 (경고용 레코드만 남김)
            infos.append({
                "path": str(p),
                "rel": str(p.relative_to(base)),
                "size_mb": round(p.stat().st_size / (1024 * 1024), 3),
                "total_lines": 0,
                "encoding": None,
                "error": "encoding_detect_failed",
            })
            continue
        lines = _count_lines(p, enc)
        infos.append({
            "path": str(p),
            "rel": str(p.relative_to(base)),
            "size_mb": round(p.stat().st_size / (1024 * 1024), 3),
            "total_lines": lines,
            "encoding": enc,
        })
    return infos


def _allocate_targets(file_infos: list[dict], target_lines: int) -> dict[str, int]:
    """파일별 라인 수 기반 비례 배분. 반환: {path: allocated}"""
    total = sum(i["total_lines"] for i in file_infos if i.get("encoding"))
    if total <= 0:
        return {}
    alloc: dict[str, int] = {}
    remaining = target_lines
    active = [i for i in file_infos if i.get("encoding") and i["total_lines"] > 0]
    for idx, info in enumerate(active):
        if idx == len(active) - 1:
            alloc[info["path"]] = max(1, remaining)
        else:
            share = int(target_lines * info["total_lines"] / total)
            share = max(1, min(share, info["total_lines"]))
            alloc[info["path"]] = share
            remaining -= share
    return alloc


def sample_logs(
    file_infos: list[dict],
    target_lines: int,
    progress_cb: Callable[[int, int, str], None] | None = None,
) -> list[str]:
    """
    파일별 비례 배분 후 stride 균등 샘플링하여 한 덩어리의 라인 리스트 반환.
    각 라인에는 파일 상대경로 프리픽스가 없다 (원본 그대로).
    progress_cb(current_idx, total, filename) 콜백 지원.
    """
    active = [i for i in file_infos if i.get("encoding") and i["total_lines"] > 0]
    if not active:
        return []

    alloc = _allocate_targets(active, target_lines)
    sampled: list[str] = []
    total_files = len(active)

    for idx, info in enumerate(active):
        if progress_cb is not None:
            progress_cb(idx, total_files, info["rel"])

        target = alloc.get(info["path"], 0)
        if target <= 0:
            continue

        path = Path(info["path"])
        total = info["total_lines"]
        enc = info["encoding"]

        # stride 계산
        stride = max(1, total // max(1, target))

        try:
            with path.open("r", encoding=enc, errors="replace") as f:
                for i, line in enumerate(f):
                    if i % stride == 0:
                        sampled.append(line.rstrip("\n"))
                        if len([x for x in sampled if True]) >= target_lines:
                            break
                    if len(sampled) >= target_lines:
                        break
        except Exception:
            continue

        if len(sampled) >= target_lines:
            break

    if progress_cb is not None:
        progress_cb(total_files, total_files, "완료")

    return sampled[:target_lines]


def estimate_tokens(lines: Iterable[str]) -> int:
    """평균 글자수 / 3.5 로 토큰 수 추정 (한글/영문 혼합 heuristic)."""
    total_chars = sum(len(l) for l in lines)
    return int(total_chars / 3.5)
