"""
Motion Parser MVP v1 — Streamlit 메인 진입점.
사이드바에서 5단계 워크플로우를 라우팅하고, 각 step의 render()를 호출한다.
Streamlit 기본(라이트) 테마를 사용한다.
"""
from __future__ import annotations

import streamlit as st

import ai_config
from utils import file_manager
from utils.debug_logger import log_event
from steps import (
    step1_log_selection,
    step2_ai_analysis,
    step3_verification,
    step4_code_generation,
    step5_volume_test,
)


# ─────────────────────────────────────────────
# 페이지 설정
# ─────────────────────────────────────────────
st.set_page_config(
    page_title="MPX · MVP v1 — Motion Parser",
    layout="wide",
    initial_sidebar_state="expanded",
)



# ─────────────────────────────────────────────
# output 폴더 보장
# ─────────────────────────────────────────────
file_manager.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# 앱 부팅 마커 (세션당 1회)
if not st.session_state.get("_boot_logged"):
    log_event("app", "세션 시작")
    st.session_state["_boot_logged"] = True


# ─────────────────────────────────────────────
# session_state 초기화
# ─────────────────────────────────────────────
def _init_state() -> None:
    defaults = {
        "current_step": 1,
        # step1: 세션 기반. sampled_lines 존재 여부로 판단
        "sampled_lines": [],
        "step1_done": False,
        # step 2~5: 파일 기반
        "step2_done": file_manager.check_step_done(2),
        "step3_done": file_manager.check_step_done(3),
        "step4_done": file_manager.check_step_done(4),
        "step5_done": file_manager.check_step_done(5),
        # 채팅 히스토리
        "step2_chat_history": [],
        "step3_chat_history": [],
        # Step 2 하위 상태
        "step2_template_done": (file_manager.load_md("원시로그템플릿.md") is not None),
        "step2_events_v1_done": (file_manager.load_md("이벤트분석_v1.md") is not None),
        # Step 3 하위 상태
        "step3_pairing_v1_done": (file_manager.load_md("모션_페어링_분석_v1.md") is not None),
        # Step 4 iterations
        "step4_iterations": [],
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v


_init_state()


# ─────────────────────────────────────────────
# 사이드바 — AI Config + Step 라우터
# ─────────────────────────────────────────────
ai_config.render_config_sidebar()

STEP_META = [
    (1, "Log Selection",   "Sampler", "blue"),
    (2, "AI Analysis",     "LLM",     "purple"),
    (3, "Verification",    "HITL",    "orange"),
    (4, "Code Generation", "ReAct",   "green"),
    (5, "Volume Test",     "SQLite",  "pink"),
]


def _is_step_enabled(step_num: int) -> bool:
    if step_num == 1:
        return True
    prev_done_key = f"step{step_num - 1}_done"
    return bool(st.session_state.get(prev_done_key, False))


def _render_sidebar_steps() -> None:
    st.sidebar.markdown("**WORKFLOW**")
    for num, name, badge, _color in STEP_META:
        done = st.session_state.get(f"step{num}_done", False)
        enabled = _is_step_enabled(num)
        active = st.session_state["current_step"] == num

        prefix = "✅" if done else ("▸" if active else "  ")
        label = f"{prefix}  0{num}  {name}    ({badge})"

        if st.sidebar.button(
            label,
            key=f"nav_step_{num}",
            disabled=not enabled,
            width="stretch",
        ):
            st.session_state["current_step"] = num
            log_event("nav", "Step 전환", f"→ step{num} ({name})")
            st.rerun()


_render_sidebar_steps()

# 사이드바 하단 정보
st.sidebar.markdown("**INFO**")
st.sidebar.caption(
    f"samples: {len(st.session_state.get('sampled_lines', []))}  \n"
    f"output: {file_manager.OUTPUT_DIR}"
)


# ─────────────────────────────────────────────
# 메인 라우터
# ─────────────────────────────────────────────
STEP_RENDERERS = {
    1: step1_log_selection.render,
    2: step2_ai_analysis.render,
    3: step3_verification.render,
    4: step4_code_generation.render,
    5: step5_volume_test.render,
}

current = st.session_state["current_step"]
renderer = STEP_RENDERERS.get(current, step1_log_selection.render)
renderer()
