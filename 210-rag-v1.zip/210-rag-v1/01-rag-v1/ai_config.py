"""
LLM Proxy 공통 설정
"""

BASE_URL = "http://192.168.0.8:8080"
API_KEY  = "sk_123!"

CHAT_MODEL      = "qwen3.5:9b"
EMBEDDING_MODEL = "qwen3-embedding:4b"

HEADERS = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json",
}
