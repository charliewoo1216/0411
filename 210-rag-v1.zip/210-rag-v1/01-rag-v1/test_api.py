"""
LLM Proxy API 테스트 스크립트
서버: http://192.168.0.8:8080
"""

import json
import requests

BASE_URL = "http://192.168.0.8:8080"
API_KEY = "sk_123!"
HEADERS = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json",
}


def separator(title: str):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print('='*60)


# ──────────────────────────────────────────────────────────
# 1. 헬스체크
# ──────────────────────────────────────────────────────────
def test_health():
    separator("1. 헬스체크 GET /health")
    resp = requests.get(f"{BASE_URL}/health")
    print(f"Status: {resp.status_code}")
    print(f"Body  : {resp.json()}")
    assert resp.status_code == 200
    assert resp.json().get("status") == "ok"
    print("[PASS]")


# ──────────────────────────────────────────────────────────
# 2. 인증 실패 테스트
# ──────────────────────────────────────────────────────────
def test_auth_failure():
    separator("2. 인증 실패 테스트 (잘못된 API 키)")
    payload = {
        "model": "qwen3.5:9b",
        "messages": [{"role": "user", "content": "test"}],
    }
    resp = requests.post(
        f"{BASE_URL}/v1/chat/completions",
        headers={**HEADERS, "Authorization": "Bearer wrong_key"},
        json=payload,
        stream=True,
    )
    print(f"Status: {resp.status_code}")
    print(f"Body  : {resp.text}")
    assert resp.status_code == 401
    print("[PASS]")


# ──────────────────────────────────────────────────────────
# 3. 스트리밍 채팅 (기본)
# ──────────────────────────────────────────────────────────
def test_chat_streaming_basic():
    separator("3. 스트리밍 채팅 (기본) POST /v1/chat/completions")
    payload = {
        "model": "qwen3.5:9b",
        "messages": [{"role": "user", "content": "안녕하세요. 한 문장으로 자기소개 해줘."}],
        "temperature": 0.7,
        "max_tokens": 256,
    }
    resp = requests.post(
        f"{BASE_URL}/v1/chat/completions",
        headers=HEADERS,
        json=payload,
        stream=True,
    )
    print(f"Status: {resp.status_code}")
    assert resp.status_code == 200

    print("응답 스트림:")
    full_content = ""
    for line in resp.iter_lines():
        if not line:
            continue
        decoded = line.decode("utf-8")
        if not decoded.startswith("data:"):
            continue
        data_str = decoded[len("data:"):].strip()
        if data_str == "[DONE]":
            break
        chunk = json.loads(data_str)
        delta = chunk["choices"][0]["delta"]
        content = delta.get("content", "")
        if content:
            print(content, end="", flush=True)
            full_content += content

    print()
    assert len(full_content) > 0, "응답 content가 비어있음"
    print("[PASS]")


# ──────────────────────────────────────────────────────────
# 4. 시스템 프롬프트 + 멀티턴 대화
# ──────────────────────────────────────────────────────────
def test_chat_multiturn():
    separator("4. 시스템 프롬프트 + 멀티턴 채팅")
    payload = {
        "model": "qwen3.5:9b",
        "messages": [
            {"role": "system", "content": "너는 Python 전문가야. 코드로만 답변해."},
            {"role": "user", "content": "피보나치 함수 만들어줘"},
            {"role": "assistant", "content": "def fib(n): return n if n <= 1 else fib(n-1) + fib(n-2)"},
            {"role": "user", "content": "메모이제이션 적용해줘"},
        ],
        "temperature": 0.3,
        "max_tokens": 512,
    }
    resp = requests.post(
        f"{BASE_URL}/v1/chat/completions",
        headers=HEADERS,
        json=payload,
        stream=True,
    )
    print(f"Status: {resp.status_code}")
    assert resp.status_code == 200

    print("응답 스트림:")
    full_content = ""
    for line in resp.iter_lines():
        if not line:
            continue
        decoded = line.decode("utf-8")
        if not decoded.startswith("data:"):
            continue
        data_str = decoded[len("data:"):].strip()
        if data_str == "[DONE]":
            break
        chunk = json.loads(data_str)
        delta = chunk["choices"][0]["delta"]
        content = delta.get("content", "")
        if content:
            print(content, end="", flush=True)
            full_content += content

    print()
    assert len(full_content) > 0
    print("[PASS]")


# ──────────────────────────────────────────────────────────
# 5. 임베딩 (단일 텍스트)
# ──────────────────────────────────────────────────────────
def test_embedding_single():
    separator("5. 임베딩 (단일 텍스트) POST /v1/embeddings")
    payload = {
        "model": "qwen3-embedding:4b",
        "input": "안녕하세요",
    }
    resp = requests.post(f"{BASE_URL}/v1/embeddings", headers=HEADERS, json=payload)
    print(f"Status: {resp.status_code}")
    assert resp.status_code == 200

    body = resp.json()
    assert body["object"] == "list"
    assert len(body["data"]) == 1

    vec = body["data"][0]["embedding"]
    print(f"벡터 차원: {len(vec)}")
    print(f"앞 5개 값: {vec[:5]}")
    print(f"사용 토큰: {body['usage']}")
    assert len(vec) == 2560, f"예상 차원 2560, 실제 {len(vec)}"
    print("[PASS]")


# ──────────────────────────────────────────────────────────
# 6. 임베딩 (배치)
# ──────────────────────────────────────────────────────────
def test_embedding_batch():
    separator("6. 임베딩 (배치) POST /v1/embeddings")
    texts = ["안녕하세요", "반갑습니다", "오늘 날씨가 좋네요"]
    payload = {
        "model": "qwen3-embedding:4b",
        "input": texts,
    }
    resp = requests.post(f"{BASE_URL}/v1/embeddings", headers=HEADERS, json=payload)
    print(f"Status: {resp.status_code}")
    assert resp.status_code == 200

    body = resp.json()
    assert len(body["data"]) == len(texts)

    for item in body["data"]:
        vec = item["embedding"]
        print(f"  [{item['index']}] 차원: {len(vec)}, 첫 값: {vec[0]:.6f}")
        assert len(vec) == 2560

    print(f"사용 토큰: {body['usage']}")
    print("[PASS]")


# ──────────────────────────────────────────────────────────
# 7. OpenAI SDK 방식 (openai 패키지 필요)
# ──────────────────────────────────────────────────────────
def test_openai_sdk():
    separator("7. OpenAI SDK 방식")
    try:
        from openai import OpenAI
    except ImportError:
        print("[SKIP] openai 패키지 미설치 — pip install openai")
        return

    client = OpenAI(base_url=f"{BASE_URL}/v1", api_key=API_KEY)

    # 스트리밍 채팅
    print("▶ 채팅 스트리밍:")
    stream = client.chat.completions.create(
        model="qwen3.5:9b",
        messages=[
            {"role": "system", "content": "간결하게 한 줄로 답변해."},
            {"role": "user", "content": "Docker란?"},
        ],
        temperature=0.3,
        max_tokens=256,
        stream=True,
    )
    full = ""
    for chunk in stream:
        content = chunk.choices[0].delta.content
        if content:
            print(content, end="", flush=True)
            full += content
    print()
    assert len(full) > 0

    # 임베딩
    print("\n▶ 임베딩:")
    result = client.embeddings.create(
        model="qwen3-embedding:4b",
        input=["안녕하세요", "반갑습니다"],
    )
    for item in result.data:
        print(f"  [{item.index}] 차원: {len(item.embedding)}")
        assert len(item.embedding) == 2560

    print("[PASS]")


# ──────────────────────────────────────────────────────────
# 실행
# ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    tests = [
        test_health,
        test_auth_failure,
        test_chat_streaming_basic,
        test_chat_multiturn,
        test_embedding_single,
        test_embedding_batch,
        test_openai_sdk,
    ]

    passed, failed = 0, 0
    errors = []

    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            failed += 1
            errors.append((test.__name__, e))
            print(f"[FAIL] {e}")

    separator("결과 요약")
    print(f"PASSED: {passed} / FAILED: {failed}")
    for name, err in errors:
        print(f"  - {name}: {err}")
