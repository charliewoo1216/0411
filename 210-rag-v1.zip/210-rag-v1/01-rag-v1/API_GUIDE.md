# LLM Proxy API 가이드

> 서버: `http://<서버IP>:8080`
> 인증: `Authorization: Bearer sk_123!`
> 백엔드: Ollama (qwen3.5:9b, qwen3-embedding:4b) → OpenAI 호환 프록시

---

## 1. 엔드포인트 목록

| 메서드 | 경로 | 인증 | 설명 |
|--------|------|------|------|
| POST | `/v1/chat/completions` | 필요 | 채팅 완성 (스트리밍) |
| POST | `/v1/embeddings` | 필요 | 텍스트 임베딩 |
| GET | `/health` | 불필요 | 서버 상태 확인 |
| GET | `/docs` | 불필요 | FastAPI 자동 생성 Swagger UI |
| GET | `/redoc` | 불필요 | FastAPI 자동 생성 ReDoc |

---

## 2. curl 호출 예시

### 2-1. 헬스체크

```bash
curl http://192.168.0.8:8080/health
```

응답:
```json
{"status": "ok"}
```

### 2-2. 스트리밍 채팅 요청 (기본)

```bash
curl -N http://192.168.0.8:8080/v1/chat/completions \
  -H "Authorization: Bearer sk_123!" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3.5:9b",
    "messages": [
      {"role": "user", "content": "안녕하세요"}
    ]
  }'
```

### 2-3. 시스템 프롬프트 + 멀티턴 대화

```bash
curl -N http://192.168.0.8:8080/v1/chat/completions \
  -H "Authorization: Bearer sk_123!" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3.5:9b",
    "messages": [
      {"role": "system", "content": "너는 Python 전문가야. 코드로만 답변해."},
      {"role": "user", "content": "피보나치 함수 만들어줘"},
      {"role": "assistant", "content": "def fib(n): ..."},
      {"role": "user", "content": "메모이제이션 적용해줘"}
    ],
    "temperature": 0.3,
    "max_tokens": 1024
  }'
```

### 2-4. 파라미터 조절

```bash
curl -N http://192.168.0.8:8080/v1/chat/completions \
  -H "Authorization: Bearer sk_123!" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3.5:9b",
    "messages": [{"role": "user", "content": "짧게 답변: 파이썬이란?"}],
    "temperature": 0.1,
    "max_tokens": 256
  }'
```

### 2-5. 임베딩 요청 (단일 텍스트)

```bash
curl -s http://192.168.0.8:8080/v1/embeddings \
  -H "Authorization: Bearer sk_123!" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3-embedding:4b",
    "input": "안녕하세요"
  }'
```

### 2-6. 임베딩 요청 (배치)

```bash
curl -s http://192.168.0.8:8080/v1/embeddings \
  -H "Authorization: Bearer sk_123!" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3-embedding:4b",
    "input": ["안녕하세요", "반갑습니다", "오늘 날씨가 좋네요"]
  }'
```

응답:
```json
{
  "object": "list",
  "data": [
    {"object": "embedding", "index": 0, "embedding": [0.038, -0.014, ...]},
    {"object": "embedding", "index": 1, "embedding": [...]},
    {"object": "embedding", "index": 2, "embedding": [...]}
  ],
  "model": "qwen3-embedding:4b",
  "usage": {"prompt_tokens": 17, "total_tokens": 17}
}
```

> 벡터 차원: 2560 (qwen3-embedding:4b 기준)

### 2-7. 인증 실패 테스트

```bash
curl -s http://192.168.0.8:8080/v1/chat/completions \
  -H "Authorization: Bearer wrong_key" \
  -H "Content-Type: application/json" \
  -d '{"model":"qwen3.5:9b","messages":[{"role":"user","content":"test"}]}'
```

응답 (HTTP 401):
```json
{"detail": "유효하지 않은 API 키입니다."}
```

---

## 3. 요청 스키마

### POST `/v1/embeddings`

```json
{
  "model": "qwen3-embedding:4b",   // 필수 — Ollama 임베딩 모델명
  "input": "텍스트"                 // 필수 — 문자열 또는 문자열 배열
}
```

| 필드 | 타입 | 설명 |
|------|------|------|
| `model` | string | Ollama 임베딩 모델명 |
| `input` | string \| string[] | 임베딩할 텍스트 (단일 또는 배치) |

### POST `/v1/chat/completions`

```json
{
  "model": "qwen3.5:9b",          // 필수 — Ollama 모델명
  "messages": [                    // 필수 — 대화 메시지 배열
    {
      "role": "system|user|assistant",
      "content": "메시지 내용"
    }
  ],
  "temperature": 0.7,              // 선택 — 0.0~2.0 (코딩: 0.1~0.3 권장)
  "max_tokens": 2048,              // 선택 — 최대 응답 토큰 수
  "stream": true                   // 선택 — 기본값 true (현재 스트리밍만 지원)
}
```

### role 종류

| role | 용도 |
|------|------|
| `system` | 모델 행동 규칙 정의 (첫 메시지로 배치) |
| `user` | 사용자 입력 |
| `assistant` | 모델의 이전 응답 (멀티턴 대화 시) |

---

## 4. 응답 스키마 (SSE 스트리밍)

각 청크는 `data: ` 접두사 + JSON으로 전송됩니다.

```
data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1775364013,"model":"qwen3.5:9b","choices":[{"index":0,"delta":{"role":"assistant","content":"토큰"},"finish_reason":null}]}

data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1775364013,"model":"qwen3.5:9b","choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}

data: [DONE]
```

| 필드 | 설명 |
|------|------|
| `choices[0].delta.content` | 생성된 토큰 (스트리밍 조각) |
| `choices[0].finish_reason` | `null` (진행 중) / `"stop"` (완료) |
| `data: [DONE]` | 스트림 종료 신호 |

> **참고**: qwen3.5는 thinking 모델이므로 응답 초반에 사고 과정(thinking)이 포함됩니다.

---

## 5. Python (OpenAI SDK) 사용법

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://192.168.0.8:8080/v1",
    api_key="sk_123!",
)

# 스트리밍 채팅
stream = client.chat.completions.create(
    model="qwen3.5:9b",
    messages=[
        {"role": "system", "content": "간결하게 답변해."},
        {"role": "user", "content": "Docker란?"},
    ],
    temperature=0.3,
    max_tokens=512,
    stream=True,
)

for chunk in stream:
    content = chunk.choices[0].delta.content
    if content:
        print(content, end="", flush=True)
print()

# 임베딩
result = client.embeddings.create(
    model="qwen3-embedding:4b",
    input=["안녕하세요", "반갑습니다"],
)

for item in result.data:
    print(f"[{item.index}] 차원: {len(item.embedding)}")
```

---

## 6. FastAPI 자동 문서

서버 실행 후 브라우저에서 접속:

| URL | 설명 |
|-----|------|
| `http://192.168.0.8:8080/docs` | Swagger UI — 인터랙티브 API 테스트 |
| `http://192.168.0.8:8080/redoc` | ReDoc — 읽기 전용 API 문서 |

Swagger UI에서 직접 요청을 보낼 수 있습니다:
1. `/docs` 접속
2. 우측 상단 **Authorize** 클릭 → `sk_123!` 입력
3. `/v1/chat/completions` 펼치기 → **Try it out** → 파라미터 수정 → **Execute**

---

## 7. 서비스 관리 명령

### systemd 서비스

```bash
# 상태 확인
sudo systemctl status llm-proxy

# 시작
sudo systemctl start llm-proxy

# 중지
sudo systemctl stop llm-proxy

# 재시작 (코드 수정 후)
sudo systemctl restart llm-proxy

# 로그 실시간 확인
journalctl -u llm-proxy -f

# 로그 최근 50줄
journalctl -u llm-proxy -n 50

# 부팅 시 자동시작 활성화
sudo systemctl enable llm-proxy

# 부팅 시 자동시작 비활성화
sudo systemctl disable llm-proxy
```

### 서비스 파일 수정 시

```bash
# 1. 서비스 파일 수정
vi /home/ubuntu/002-llm-api/llm-proxy.service

# 2. 복사 + 리로드 + 재시작
sudo cp /home/ubuntu/002-llm-api/llm-proxy.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl restart llm-proxy
```

### Ollama 관련

```bash
# Ollama 상태 확인
sudo systemctl status ollama

# 설치된 모델 목록
ollama list

# 모델 다운로드
ollama pull qwen3.5:9b

# Ollama 재시작
sudo systemctl restart ollama
```

---

## 8. 트러블슈팅

| 증상 | 원인 | 해결 |
|------|------|------|
| `Connection refused` | 서비스 미실행 | `sudo systemctl start llm-proxy` |
| HTTP 401 | API 키 불일치 | `Authorization: Bearer sk_123!` 확인 |
| 빈 응답 (content 비어있음) | qwen3.5 thinking 모드 | 정상 — 사고 과정 후 답변 출력됨 |
| 응답 매우 느림 | 모델 VRAM 재로드 | 첫 요청 후 10분 내 재요청 시 빠름 (`keep_alive: 10m`) |
| Ollama 오류 500 | 모델 미설치 | `ollama pull qwen3.5:9b` 또는 `ollama pull qwen3-embedding:4b` |
| 포트 80 바인딩 실패 | root 권한 필요 | 포트 8080 사용 (현재 설정) |

---

## 9. Ollama 파라미터 (현재 적용값)

`main.py`의 `build_ollama_payload()`에서 고정 전달되는 값:

| 파라미터 | 값 | 설명 |
|----------|-----|------|
| `num_ctx` | 24,576 | 컨텍스트 윈도우 (24K) |
| `num_predict` | `max_tokens` 값 | 기본 2,048 |
| `temperature` | 요청값 | 기본 0.7 |
| `top_p` | 0.9 | 누적 확률 샘플링 |
| `top_k` | 20 | 상위 K개 토큰 |
| `repeat_penalty` | 1.1 | 반복 억제 |
| `num_gpu` | 99 | 전체 GPU 오프로드 |
| `num_thread` | 4 | CPU 보조 스레드 |
| `keep_alive` | 10m | 모델 VRAM 유지 시간 |

> 상세 전략은 [CONTEXT_STRATEGY.md](CONTEXT_STRATEGY.md) 참고
