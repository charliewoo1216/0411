"""
RAG App - Streamlit UI
- ./embedding_file/*.txt 자동 임베딩 (변경된 파일만 재임베딩)
- FAISS CPU 벡터 검색
- 스트리밍 LLM 답변
- 모든 API / 처리 과정 DEBUG 로그
"""

import json
import hashlib
import logging
import pickle
import numpy as np
import requests
import faiss
import streamlit as st
from pathlib import Path

from ai_config import BASE_URL, CHAT_MODEL, EMBEDDING_MODEL, HEADERS

# ─── 로깅 설정 ────────────────────────────────────────────────
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("rag_debug.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("rag_app")

# ─── 경로 / 상수 ─────────────────────────────────────────────
EMBED_DIR     = Path("embedding_file")
INDEX_DIR     = Path("faiss_index")
MANIFEST_FILE = INDEX_DIR / "manifest.json"

EMBED_DIM     = 2560
CHUNK_SIZE    = 500
CHUNK_OVERLAP = 50
TOP_K         = 5


# ─── 유틸 ────────────────────────────────────────────────────
def _file_md5(path: Path) -> str:
    return hashlib.md5(path.read_bytes()).hexdigest()


def _split_chunks(text: str) -> list[str]:
    result, start = [], 0
    while start < len(text):
        result.append(text[start : start + CHUNK_SIZE])
        start += CHUNK_SIZE - CHUNK_OVERLAP
    return result


# ─── API 래퍼 ────────────────────────────────────────────────
def get_embeddings(texts: list[str]) -> list[list[float]]:
    log.debug(
        "임베딩 API 요청 | url=%s/v1/embeddings | model=%s | 텍스트 수=%d",
        BASE_URL, EMBEDDING_MODEL, len(texts),
    )
    payload = {"model": EMBEDDING_MODEL, "input": texts}
    resp = requests.post(
        f"{BASE_URL}/v1/embeddings", headers=HEADERS, json=payload, timeout=60
    )
    usage = resp.json().get("usage", {}) if resp.ok else "N/A"
    log.debug("임베딩 응답 | status=%d | usage=%s", resp.status_code, usage)
    resp.raise_for_status()
    items = sorted(resp.json()["data"], key=lambda x: x["index"])
    return [item["embedding"] for item in items]


def stream_chat(messages: list[dict]):
    log.debug(
        "채팅 API 요청 | url=%s/v1/chat/completions | model=%s | messages=%d개",
        BASE_URL, CHAT_MODEL, len(messages),
    )
    payload = {
        "model": CHAT_MODEL,
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": 1024,
    }
    resp = requests.post(
        f"{BASE_URL}/v1/chat/completions",
        headers=HEADERS,
        json=payload,
        stream=True,
        timeout=120,
    )
    log.debug("채팅 응답 | status=%d", resp.status_code)
    resp.raise_for_status()
    for line in resp.iter_lines():
        if not line:
            continue
        decoded = line.decode("utf-8")
        if not decoded.startswith("data:"):
            continue
        data_str = decoded[5:].strip()
        if data_str == "[DONE]":
            log.debug("스트림 종료 [DONE]")
            break
        try:
            content = json.loads(data_str)["choices"][0]["delta"].get("content", "")
            if content:
                yield content
        except (json.JSONDecodeError, KeyError) as e:
            log.warning("스트림 파싱 오류: %s | raw=%r", e, data_str)


# ─── 인덱스 관리 ─────────────────────────────────────────────
def _load_manifest() -> dict:
    if MANIFEST_FILE.exists():
        with open(MANIFEST_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {}


def _save_manifest(m: dict):
    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    with open(MANIFEST_FILE, "w", encoding="utf-8") as f:
        json.dump(m, f, ensure_ascii=False, indent=2)
    log.debug("manifest 저장 | 파일 수=%d", len(m))


def _embed_file(fpath: Path) -> tuple[np.ndarray, list[str]]:
    """파일을 청킹하고 임베딩 벡터 반환"""
    text = fpath.read_text(encoding="utf-8")
    chunks = _split_chunks(text)
    log.info("파일 임베딩 시작 | %s | 청크=%d개", fpath.name, len(chunks))
    all_vecs: list[list[float]] = []
    for i in range(0, len(chunks), 20):
        batch = chunks[i : i + 20]
        vecs = get_embeddings(batch)
        all_vecs.extend(vecs)
        log.debug("배치 임베딩 | %s | %d/%d 완료", fpath.name, min(i + 20, len(chunks)), len(chunks))
    arr = np.array(all_vecs, dtype=np.float32)
    log.info("파일 임베딩 완료 | %s | shape=%s", fpath.name, arr.shape)
    return arr, chunks


def _build_faiss(manifest: dict) -> tuple[faiss.IndexFlatL2, list[dict]]:
    """manifest 기준으로 저장된 .npy 파일로 FAISS 인덱스 재구성"""
    index = faiss.IndexFlatL2(EMBED_DIM)
    all_chunks: list[dict] = []
    for fname in sorted(manifest.keys()):
        npy_path = INDEX_DIR / f"{fname}.npy"
        pkl_path = INDEX_DIR / f"{fname}.pkl"
        if not npy_path.exists() or not pkl_path.exists():
            log.warning("캐시 파일 없음, 건너뜀: %s", fname)
            continue
        vec_arr = np.load(str(npy_path))
        with open(pkl_path, "rb") as f:
            chunks = pickle.load(f)
        index.add(vec_arr)
        for i, chunk_text in enumerate(chunks):
            all_chunks.append({"file": fname, "chunk_idx": i, "text": chunk_text})
        log.debug("FAISS 추가 | %s | 벡터=%d", fname, len(vec_arr))
    log.info("FAISS 인덱스 구성 완료 | 총 벡터=%d | 총 청크=%d", index.ntotal, len(all_chunks))
    return index, all_chunks


def load_existing_index() -> tuple[faiss.IndexFlatL2 | None, list[dict]]:
    """앱 시작 시 저장된 인덱스 로드 (API 호출 없음)"""
    manifest = _load_manifest()
    if not manifest:
        log.debug("manifest 없음 — 빈 인덱스")
        return None, []
    index, chunks = _build_faiss(manifest)
    return (index if index.ntotal > 0 else None), chunks


def update_index() -> tuple[faiss.IndexFlatL2, list[dict], int]:
    """
    embedding_file/*.txt 스캔 → 신규/변경 파일만 임베딩 후 전체 인덱스 반환
    returns: (index, chunks, new_file_count)
    """
    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    manifest = _load_manifest()
    txt_files = sorted(EMBED_DIR.glob("*.txt"))
    log.info("인덱싱 실행 | 스캔 파일=%d개", len(txt_files))

    new_count = 0
    for fpath in txt_files:
        fname = fpath.name
        md5   = _file_md5(fpath)
        if manifest.get(fname, {}).get("hash") == md5:
            log.debug("스킵 (변경 없음): %s", fname)
            continue
        log.info("신규/변경 파일 임베딩: %s", fname)
        vec_arr, chunks = _embed_file(fpath)
        np.save(str(INDEX_DIR / f"{fname}.npy"), vec_arr)
        with open(INDEX_DIR / f"{fname}.pkl", "wb") as f:
            pickle.dump(chunks, f)
        manifest[fname] = {"hash": md5, "chunk_count": len(chunks)}
        new_count += 1

    _save_manifest(manifest)
    index, all_chunks = _build_faiss(manifest)
    return index, all_chunks, new_count


def search_index(query: str, index: faiss.IndexFlatL2, chunks: list[dict]) -> list[dict]:
    log.debug("벡터 검색 | query=%r | top_k=%d", query[:80], TOP_K)
    q_vec = np.array(get_embeddings([query]), dtype=np.float32)
    distances, ids = index.search(q_vec, TOP_K)
    log.debug("검색 결과 | distances=%s | ids=%s", distances[0].tolist(), ids[0].tolist())
    results = []
    for dist, idx in zip(distances[0], ids[0]):
        if 0 <= int(idx) < len(chunks):
            results.append({**chunks[int(idx)], "distance": float(dist)})
    return results


# ─── Streamlit UI ─────────────────────────────────────────────
st.set_page_config(page_title="RAG 챗봇", page_icon="📚", layout="wide")
st.title("📚 RAG 챗봇")

# 세션 상태 초기화
if "index" not in st.session_state:
    log.debug("앱 초기 로드 — 기존 인덱스 탐색")
    idx, cks = load_existing_index()
    st.session_state.index  = idx
    st.session_state.chunks = cks
if "messages" not in st.session_state:
    st.session_state.messages = []

# ─── 사이드바 ──────────────────────────────────────────────────
with st.sidebar:
    st.header("🗂️ 문서 인덱스")

    if st.button("🔄 인덱싱 실행", use_container_width=True):
        with st.spinner("파일 스캔 및 임베딩 중..."):
            try:
                idx, cks, new_count = update_index()
                st.session_state.index  = idx
                st.session_state.chunks = cks
                if new_count:
                    st.success(f"✅ {new_count}개 파일 신규/변경 임베딩 완료")
                else:
                    st.info("ℹ️ 변경된 파일 없음 (인덱스 로드 완료)")
            except Exception as e:
                log.exception("인덱싱 오류")
                st.error(f"오류: {e}")

    manifest = _load_manifest()
    total_chunks = sum(v.get("chunk_count", 0) for v in manifest.values())
    st.metric("임베딩된 파일", f"{len(manifest)}개")
    st.metric("총 청크 수", f"{total_chunks}개")

    if manifest:
        st.divider()
        for fname, info in manifest.items():
            st.write(f"📄 **{fname}** — {info['chunk_count']} 청크")

    st.divider()
    if st.button("🗑️ 대화 초기화", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

# ─── 상태 표시 ─────────────────────────────────────────────────
if st.session_state.index is None:
    st.info("💡 사이드바에서 **'🔄 인덱싱 실행'** 버튼을 눌러 문서를 임베딩하세요.")

# ─── 대화 기록 ─────────────────────────────────────────────────
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# ─── 입력 처리 ─────────────────────────────────────────────────
if prompt := st.chat_input("질문을 입력하세요..."):
    if st.session_state.index is None or st.session_state.index.ntotal == 0:
        st.warning("⚠️ 먼저 사이드바에서 '인덱싱 실행'을 눌러주세요.")
        st.stop()

    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # 벡터 검색
    with st.spinner("관련 문서 검색 중..."):
        search_results = search_index(
            prompt, st.session_state.index, st.session_state.chunks
        )
    log.info("검색 완료 | query=%r | 결과=%d건", prompt[:80], len(search_results))

    # 컨텍스트 구성
    context = "\n\n---\n\n".join(
        f"[출처: {r['file']}]\n{r['text']}" for r in search_results
    )
    system_msg = (
        "당신은 제공된 문서를 바탕으로 질문에 정확하게 답변하는 어시스턴트입니다.\n"
        "반드시 아래 참고 문서의 내용을 근거로 답변하고, 문서에 없는 내용은 모른다고 답하세요.\n\n"
        f"[참고 문서]\n{context}"
    )
    api_messages = [
        {"role": "system", "content": system_msg},
        *st.session_state.messages,
    ]

    # 스트리밍 응답
    with st.chat_message("assistant"):
        placeholder = st.empty()
        full_resp = ""
        try:
            for token in stream_chat(api_messages):
                full_resp += token
                placeholder.markdown(full_resp + "▌")
            placeholder.markdown(full_resp)
        except Exception as e:
            log.exception("채팅 API 오류")
            placeholder.error(f"응답 오류: {e}")

    st.session_state.messages.append({"role": "assistant", "content": full_resp})

    # 참고 문서 표시
    with st.expander(f"📎 참고 문서 ({len(search_results)}건)"):
        for i, r in enumerate(search_results, 1):
            st.write(f"**{i}. {r['file']}** — 거리: `{r['distance']:.4f}`")
            preview = r["text"]
            st.code(
                preview[:300] + ("..." if len(preview) > 300 else ""),
                language="text",
            )
