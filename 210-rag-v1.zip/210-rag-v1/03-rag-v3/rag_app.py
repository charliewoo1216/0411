"""
RAG App - Streamlit UI (Hybrid: FAISS + SQLite FTS5)
"""
import logging
import pickle
import sqlite3

import pandas as pd
import streamlit as st

from rag.config import INDEX_DIR
from rag.fts import DB_PATH
from rag.indexer import load_existing_index, update_index, search_hybrid, load_manifest
from rag.llm import stream_chat

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("rag_debug.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("rag_app")

# ─── 페이지 설정 ──────────────────────────────────────────────
st.set_page_config(page_title="RAG 챗봇", page_icon="📚", layout="wide")
st.title("📚 RAG 챗봇 (Hybrid)")

# ─── 세션 상태 초기화 ─────────────────────────────────────────
if "index" not in st.session_state:
    log.debug("앱 초기 로드 — 기존 인덱스 탐색")
    idx, cks = load_existing_index()
    st.session_state.index  = idx
    st.session_state.chunks = cks
if "messages" not in st.session_state:
    st.session_state.messages = []

# ─── 사이드바 ──────────────────────────────────────────────────
with st.sidebar:
    st.header("🗂️ 문서 인덱스")

    if st.button("🔄 인덱싱 실행", width="stretch"):
        with st.spinner("파일 스캔 및 임베딩 중..."):
            try:
                idx, cks, new_count = update_index()
                st.session_state.index  = idx
                st.session_state.chunks = cks
                if new_count:
                    st.success(f"✅ {new_count}개 파일 신규/변경 임베딩 완료")
                else:
                    st.info("ℹ️ 변경된 파일 없음 (인덱스 로드 완료)")
            except Exception as e:
                log.exception("인덱싱 오류")
                st.error(f"오류: {e}")

    manifest = load_manifest()
    total_chunks = sum(v.get("chunk_count", 0) for v in manifest.values())
    st.metric("임베딩된 파일", f"{len(manifest)}개")
    st.metric("총 청크 수", f"{total_chunks}개")

    if manifest:
        st.divider()
        for fname, info in manifest.items():
            st.write(f"📄 **{fname}** — {info['chunk_count']} 청크")

    st.divider()
    if st.button("🗑️ 대화 초기화", width="stretch"):
        st.session_state.messages = []
        st.rerun()

# ─── 메인 탭 ──────────────────────────────────────────────────
tab_chat, tab_fts, tab_pkl = st.tabs(["💬 챗봇", "🗄️ FTS DB", "📦 청크 원문"])


# ══════════════════════════════════════════════════
# TAB 1 — 챗봇
# ══════════════════════════════════════════════════
with tab_chat:
    if st.session_state.index is None:
        st.info("💡 사이드바에서 **'🔄 인덱싱 실행'** 버튼을 눌러 문서를 임베딩하세요.")

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    if prompt := st.chat_input("질문을 입력하세요..."):
        if st.session_state.index is None or st.session_state.index.ntotal == 0:
            st.warning("⚠️ 먼저 사이드바에서 '인덱싱 실행'을 눌러주세요.")
            st.stop()

        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        with st.spinner("관련 문서 검색 중..."):
            search_results = search_hybrid(
                prompt, st.session_state.index, st.session_state.chunks
            )
        log.info("검색 완료 | query=%r | 결과=%d건", prompt[:80], len(search_results))

        context = "\n\n---\n\n".join(
            f"[출처: {r['file']}]\n{r['text']}" for r in search_results
        )
        system_msg = (
            "당신은 제공된 문서를 바탕으로 질문에 정확하게 답변하는 어시스턴트입니다.\n"
            "반드시 아래 참고 문서의 내용을 근거로 답변하고, 문서에 없는 내용은 모른다고 답하세요.\n\n"
            f"[참고 문서]\n{context}"
        )
        api_messages = [
            {"role": "system", "content": system_msg},
            *st.session_state.messages,
        ]

        with st.chat_message("assistant"):
            # thinking 내용은 접힌 expander에 표시
            think_expander   = st.expander("💭 생각 과정 보기", expanded=False)
            think_placeholder = think_expander.empty()
            # 실제 답변은 여기에 스트리밍
            status_msg       = st.empty()
            status_msg.markdown("🤔 *생각 중...*")
            answer_placeholder = st.empty()

            think_buf = ""
            full_resp = ""
            got_answer = False

            try:
                for token_type, text in stream_chat(api_messages):
                    if token_type == "think":
                        think_buf += text
                        think_placeholder.markdown(think_buf)
                    else:  # "answer"
                        if not got_answer:
                            status_msg.empty()
                            got_answer = True
                        full_resp += text
                        answer_placeholder.markdown(full_resp + "▌")
                answer_placeholder.markdown(full_resp)
                if not got_answer:
                    status_msg.markdown("⚠️ 답변 토큰을 받지 못했습니다.")
                log.debug("thinking=%d자 | answer=%d자", len(think_buf), len(full_resp))
            except Exception as e:
                status_msg.empty()
                log.exception("채팅 API 오류")
                answer_placeholder.error(f"응답 오류: {e}")

        st.session_state.messages.append({"role": "assistant", "content": full_resp})

        with st.expander(f"📎 참고 문서 ({len(search_results)}건)"):
            for i, r in enumerate(search_results, 1):
                rrf  = r.get("rrf_score", 0)
                dist = r.get("distance")
                score_label = f"RRF: `{rrf:.6f}`" + (
                    f" | 거리: `{dist:.4f}`" if dist is not None else ""
                )
                st.write(f"**{i}. {r['file']}** — {score_label}")
                preview = r["text"]
                st.code(
                    preview[:300] + ("..." if len(preview) > 300 else ""),
                    language="text",
                )


# ══════════════════════════════════════════════════
# TAB 2 — SQLite FTS5 DB 탐색
# ══════════════════════════════════════════════════
with tab_fts:
    st.subheader("🗄️ SQLite FTS5 — chunks 테이블")

    if not DB_PATH.exists():
        st.info("fts.db 없음 — 사이드바에서 인덱싱을 먼저 실행하세요.")
    else:
        try:
            conn = sqlite3.connect(str(DB_PATH))
            df_full = pd.read_sql_query(
                "SELECT file AS 파일명,"
                " CAST(chunk_idx AS INTEGER) AS 청크번호,"
                " text AS 텍스트"
                " FROM chunks"
                " ORDER BY 파일명, 청크번호",
                conn,
            )
            conn.close()
        except Exception as e:
            st.error(f"DB 읽기 오류: {e}")
            df_full = pd.DataFrame()

        if df_full.empty:
            st.info("FTS DB가 비어있습니다.")
        else:
            # ── 필터 / 검색 ──────────────────────────────
            col_filter, col_search = st.columns([2, 3])
            with col_filter:
                file_options = ["전체"] + sorted(df_full["파일명"].unique().tolist())
                sel_file = st.selectbox("파일 필터", file_options)
            with col_search:
                keyword = st.text_input("텍스트 검색 (포함 문자열)")

            df_view = df_full.copy()
            if sel_file != "전체":
                df_view = df_view[df_view["파일명"] == sel_file]
            if keyword:
                df_view = df_view[df_view["텍스트"].str.contains(keyword, na=False)]

            # ── 지표 ─────────────────────────────────────
            mc1, mc2, mc3 = st.columns(3)
            mc1.metric("전체 청크", f"{len(df_full):,}개")
            mc2.metric("표시 청크", f"{len(df_view):,}개")
            mc3.metric("파일 수", f"{df_full['파일명'].nunique()}개")

            # ── 테이블 (텍스트 미리보기 100자) ───────────
            df_display = df_view.copy()
            df_display["미리보기"] = df_display["텍스트"].str[:100] + "…"
            df_display = df_display.drop(columns=["텍스트"])

            st.dataframe(
                df_display,
                width="stretch",
                hide_index=True,
                column_config={
                    "파일명":   st.column_config.TextColumn(width="medium"),
                    "청크번호": st.column_config.NumberColumn(width="small", format="%d"),
                    "미리보기": st.column_config.TextColumn(width="large"),
                },
            )

            # ── 전체 텍스트 보기 (행 선택) ───────────────
            st.divider()
            st.caption("청크 번호를 선택하면 전체 텍스트를 확인할 수 있습니다.")
            col_f2, col_n = st.columns([2, 1])
            with col_f2:
                sel_file2 = st.selectbox(
                    "파일", sorted(df_full["파일명"].unique()), key="fulltext_file"
                )
            with col_n:
                max_idx = int(df_full[df_full["파일명"] == sel_file2]["청크번호"].max())
                sel_idx = st.number_input(
                    "청크 번호", min_value=0, max_value=max_idx, value=0, step=1
                )
            row = df_full[
                (df_full["파일명"] == sel_file2) & (df_full["청크번호"] == sel_idx)
            ]
            if not row.empty:
                text_val = row.iloc[0]["텍스트"]
                st.text_area(
                    f"📄 {sel_file2}  #청크{sel_idx}  ({len(text_val)}자)",
                    value=text_val,
                    height=220,
                )


# ══════════════════════════════════════════════════
# TAB 3 — PKL 청크 원문
# ══════════════════════════════════════════════════
with tab_pkl:
    st.subheader("📦 청크 원문 (.pkl 파일)")

    pkl_files = sorted(INDEX_DIR.glob("*.pkl"))
    if not pkl_files:
        st.info("pkl 파일 없음 — 사이드바에서 인덱싱을 먼저 실행하세요.")
    else:
        fname_options = [p.name.replace(".pkl", "") for p in pkl_files]
        sel_fname = st.selectbox("파일 선택", fname_options)
        pkl_path  = INDEX_DIR / f"{sel_fname}.pkl"

        with open(pkl_path, "rb") as f:
            chunks: list[str] = pickle.load(f)

        pc1, pc2 = st.columns(2)
        pc1.metric("총 청크 수", f"{len(chunks)}개")
        pc2.metric("평균 청크 길이", f"{int(sum(len(c) for c in chunks)/len(chunks))}자")

        st.divider()
        for i, text in enumerate(chunks):
            with st.expander(f"청크 #{i:03d}  ·  {len(text)}자"):
                st.text(text)
