import logging
import re
import sqlite3

from .config import INDEX_DIR

log = logging.getLogger("rag.fts")

DB_PATH = INDEX_DIR / "fts.db"

# FTS5가 오류를 내는 특수문자 제거 (따옴표, 연산자 기호 등)
_FTS_SPECIAL = re.compile(r'["\'\*\(\)\-\+\:\^~\[\]{}\\|&;,]')


def _sanitize(query: str) -> str:
    return _FTS_SPECIAL.sub(" ", query).strip()


def _connect() -> sqlite3.Connection:
    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS chunks USING fts5(
            file,
            chunk_idx UNINDEXED,
            text,
            tokenize='unicode61'
        )
    """)
    conn.commit()
    return conn


def upsert_chunks(fname: str, chunks: list[str]):
    conn = _connect()
    conn.execute("DELETE FROM chunks WHERE file = ?", (fname,))
    conn.executemany(
        "INSERT INTO chunks (file, chunk_idx, text) VALUES (?, ?, ?)",
        [(fname, str(i), text) for i, text in enumerate(chunks)],
    )
    conn.commit()
    conn.close()
    log.debug("FTS 업데이트 | %s | 청크=%d개", fname, len(chunks))


def search_fts(query: str, top_k: int) -> list[dict]:
    safe_query = _sanitize(query)
    if not safe_query:
        log.debug("FTS 검색 생략 — 쿼리가 비어있음")
        return []
    try:
        conn = _connect()
        cur = conn.execute(
            "SELECT file, chunk_idx, text, rank"
            " FROM chunks WHERE text MATCH ? ORDER BY rank LIMIT ?",
            (safe_query, top_k),
        )
        rows = cur.fetchall()
        conn.close()
        log.debug("FTS 검색 | query=%r | 결과=%d건", query[:80], len(rows))
        return [
            {"file": r[0], "chunk_idx": int(r[1]), "text": r[2], "fts_rank": r[3]}
            for r in rows
        ]
    except sqlite3.OperationalError as e:
        log.warning("FTS 검색 오류 (결과 생략) | %s | query=%r", e, query[:80])
        return []
