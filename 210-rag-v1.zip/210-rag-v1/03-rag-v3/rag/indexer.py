import json
import logging
import pickle
import numpy as np
import faiss

from .config import EMBED_DIR, INDEX_DIR, MANIFEST_FILE, EMBED_DIM, TOP_K
from .embedder import file_md5, embed_file, get_embeddings
from .fts import upsert_chunks, search_fts
from .fusion import reciprocal_rank_fusion

log = logging.getLogger("rag.indexer")


def load_manifest() -> dict:
    if MANIFEST_FILE.exists():
        with open(MANIFEST_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_manifest(m: dict):
    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    with open(MANIFEST_FILE, "w", encoding="utf-8") as f:
        json.dump(m, f, ensure_ascii=False, indent=2)
    log.debug("manifest 저장 | 파일 수=%d", len(m))


def _build_faiss(manifest: dict) -> tuple[faiss.IndexFlatL2, list[dict]]:
    index = faiss.IndexFlatL2(EMBED_DIM)
    all_chunks: list[dict] = []
    for fname in sorted(manifest.keys()):
        npy_path = INDEX_DIR / f"{fname}.npy"
        pkl_path = INDEX_DIR / f"{fname}.pkl"
        if not npy_path.exists() or not pkl_path.exists():
            log.warning("캐시 파일 없음, 건너뜀: %s", fname)
            continue
        vec_arr = np.load(str(npy_path))
        with open(pkl_path, "rb") as f:
            chunks = pickle.load(f)
        index.add(vec_arr)
        for i, chunk_text in enumerate(chunks):
            all_chunks.append({"file": fname, "chunk_idx": i, "text": chunk_text})
        log.debug("FAISS 추가 | %s | 벡터=%d", fname, len(vec_arr))
    log.info(
        "FAISS 인덱스 구성 완료 | 총 벡터=%d | 총 청크=%d",
        index.ntotal, len(all_chunks),
    )
    return index, all_chunks


def load_existing_index() -> tuple[faiss.IndexFlatL2 | None, list[dict]]:
    manifest = load_manifest()
    if not manifest:
        log.debug("manifest 없음 — 빈 인덱스")
        return None, []
    index, chunks = _build_faiss(manifest)
    return (index if index.ntotal > 0 else None), chunks


def update_index() -> tuple[faiss.IndexFlatL2, list[dict], int]:
    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    EMBED_DIR.mkdir(parents=True, exist_ok=True)
    manifest = load_manifest()
    txt_files = sorted(EMBED_DIR.glob("*.txt"))
    log.info("인덱싱 실행 | 스캔 파일=%d개", len(txt_files))

    new_count = 0
    for fpath in txt_files:
        fname = fpath.name
        md5   = file_md5(fpath)
        if manifest.get(fname, {}).get("hash") == md5:
            log.debug("스킵 (변경 없음): %s", fname)
            continue
        log.info("신규/변경 파일 임베딩: %s", fname)
        vec_arr, chunks = embed_file(fpath)
        np.save(str(INDEX_DIR / f"{fname}.npy"), vec_arr)
        with open(INDEX_DIR / f"{fname}.pkl", "wb") as f:
            pickle.dump(chunks, f)
        upsert_chunks(fname, chunks)
        manifest[fname] = {"hash": md5, "chunk_count": len(chunks)}
        new_count += 1

    save_manifest(manifest)
    index, all_chunks = _build_faiss(manifest)
    return index, all_chunks, new_count


def search_faiss(
    query: str,
    index: faiss.IndexFlatL2,
    chunks: list[dict],
) -> list[dict]:
    log.debug("FAISS 검색 | query=%r | top_k=%d", query[:80], TOP_K)
    q_vec = np.array(get_embeddings([query]), dtype=np.float32)
    distances, ids = index.search(q_vec, TOP_K)
    log.debug(
        "FAISS 결과 | distances=%s | ids=%s",
        distances[0].tolist(), ids[0].tolist(),
    )
    results = []
    for dist, idx in zip(distances[0], ids[0]):
        if 0 <= int(idx) < len(chunks):
            results.append({**chunks[int(idx)], "distance": float(dist)})
    return results


def search_hybrid(
    query: str,
    index: faiss.IndexFlatL2,
    chunks: list[dict],
) -> list[dict]:
    faiss_results = search_faiss(query, index, chunks)
    fts_results   = search_fts(query, TOP_K)
    log.info(
        "하이브리드 검색 | FAISS=%d건 | FTS=%d건",
        len(faiss_results), len(fts_results),
    )
    return reciprocal_rank_fusion(faiss_results, fts_results)
