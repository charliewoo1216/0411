from pathlib import Path

EMBED_DIR     = Path("embedding_file")
INDEX_DIR     = Path("faiss_index")
MANIFEST_FILE = INDEX_DIR / "manifest.json"

EMBED_DIM     = 2560
CHUNK_SIZE    = 500
CHUNK_OVERLAP = 50
TOP_K         = 5
