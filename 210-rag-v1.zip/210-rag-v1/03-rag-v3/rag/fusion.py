import logging

from .config import TOP_K

log = logging.getLogger("rag.fusion")


def reciprocal_rank_fusion(
    faiss_results: list[dict],
    fts_results: list[dict],
    k: int = 60,
) -> list[dict]:
    """
    RRF score = sum(1 / (k + rank_i)) across each result list.
    k=60 is the standard constant from the original RRF paper.
    """
    scores: dict[tuple, float] = {}
    merged: dict[tuple, dict] = {}

    for rank, r in enumerate(faiss_results, 1):
        key = (r["file"], r["chunk_idx"])
        scores[key] = scores.get(key, 0.0) + 1.0 / (k + rank)
        merged[key] = r

    for rank, r in enumerate(fts_results, 1):
        key = (r["file"], r["chunk_idx"])
        scores[key] = scores.get(key, 0.0) + 1.0 / (k + rank)
        if key not in merged:
            merged[key] = r

    sorted_keys = sorted(scores, key=lambda x: scores[x], reverse=True)
    log.debug(
        "RRF 결합 | FAISS=%d + FTS=%d → 후보=%d개 → TOP_K=%d",
        len(faiss_results), len(fts_results), len(sorted_keys), TOP_K,
    )
    return [
        {**merged[key], "rrf_score": round(scores[key], 6)}
        for key in sorted_keys[:TOP_K]
    ]
