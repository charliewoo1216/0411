import hashlib
import logging
import numpy as np
import requests
from pathlib import Path

from ai_config import BASE_URL, EMBEDDING_MODEL, HEADERS
from .config import CHUNK_SIZE, CHUNK_OVERLAP

log = logging.getLogger("rag.embedder")


def file_md5(path: Path) -> str:
    return hashlib.md5(path.read_bytes()).hexdigest()


def split_chunks(text: str) -> list[str]:
    result, start = [], 0
    while start < len(text):
        result.append(text[start : start + CHUNK_SIZE])
        start += CHUNK_SIZE - CHUNK_OVERLAP
    return result


def get_embeddings(texts: list[str]) -> list[list[float]]:
    log.debug(
        "임베딩 API 요청 | url=%s/v1/embeddings | model=%s | 텍스트 수=%d",
        BASE_URL, EMBEDDING_MODEL, len(texts),
    )
    payload = {"model": EMBEDDING_MODEL, "input": texts}
    resp = requests.post(
        f"{BASE_URL}/v1/embeddings", headers=HEADERS, json=payload, timeout=60
    )
    usage = resp.json().get("usage", {}) if resp.ok else "N/A"
    log.debug("임베딩 응답 | status=%d | usage=%s", resp.status_code, usage)
    resp.raise_for_status()
    items = sorted(resp.json()["data"], key=lambda x: x["index"])
    return [item["embedding"] for item in items]


def embed_file(fpath: Path) -> tuple[np.ndarray, list[str]]:
    text = fpath.read_text(encoding="utf-8")
    chunks = split_chunks(text)
    log.info("파일 임베딩 시작 | %s | 청크=%d개", fpath.name, len(chunks))
    all_vecs: list[list[float]] = []
    for i in range(0, len(chunks), 20):
        batch = chunks[i : i + 20]
        vecs = get_embeddings(batch)
        all_vecs.extend(vecs)
        log.debug(
            "배치 임베딩 | %s | %d/%d 완료",
            fpath.name, min(i + 20, len(chunks)), len(chunks),
        )
    arr = np.array(all_vecs, dtype=np.float32)
    log.info("파일 임베딩 완료 | %s | shape=%s", fpath.name, arr.shape)
    return arr, chunks
