import json
import logging
import requests
from typing import Generator, Literal

from ai_config import BASE_URL, CHAT_MODEL, HEADERS

log = logging.getLogger("rag.llm")

TokenType = Literal["think", "answer"]

_OPEN_TAG  = "<think>"
_CLOSE_TAG = "</think>"


def stream_chat(
    messages: list[dict],
) -> Generator[tuple[TokenType, str], None, None]:
    """
    Yields (token_type, text) tuples.
      "think"  — <think>…</think> 내부 thinking 텍스트
      "answer" — 실제 답변 텍스트
    Handles tags split across token boundaries via an internal buffer.
    """
    log.debug(
        "채팅 API 요청 | url=%s/v1/chat/completions | model=%s | messages=%d개",
        BASE_URL, CHAT_MODEL, len(messages),
    )
    payload = {
        "model": CHAT_MODEL,
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": 2048,
        "stream": True,
    }
    resp = requests.post(
        f"{BASE_URL}/v1/chat/completions",
        headers=HEADERS,
        json=payload,
        stream=True,
        timeout=300,
    )
    log.debug("채팅 응답 | status=%d", resp.status_code)
    resp.raise_for_status()

    in_think = False
    buf      = ""

    for line in resp.iter_lines():
        if not line:
            continue
        decoded = line.decode("utf-8")
        if not decoded.startswith("data:"):
            continue
        data_str = decoded[5:].strip()
        if data_str == "[DONE]":
            log.debug("스트림 종료 [DONE]")
            break
        try:
            chunk = json.loads(data_str)["choices"][0]["delta"].get("content", "")
        except (json.JSONDecodeError, KeyError) as e:
            log.warning("스트림 파싱 오류: %s | raw=%r", e, data_str)
            continue

        if not chunk:
            continue

        buf += chunk

        while buf:
            if in_think:
                pos = buf.find(_CLOSE_TAG)
                if pos != -1:
                    if pos > 0:
                        yield "think", buf[:pos]
                    log.debug("thinking 블록 종료")
                    in_think = False
                    buf = buf[pos + len(_CLOSE_TAG):]
                else:
                    yield "think", buf
                    buf = ""
                    break
            else:
                pos = buf.find(_OPEN_TAG)
                if pos != -1:
                    if pos > 0:
                        yield "answer", buf[:pos]
                    log.debug("thinking 블록 시작")
                    in_think = True
                    buf = buf[pos + len(_OPEN_TAG):]
                else:
                    # <think> 태그가 토큰 경계에서 잘릴 수 있으므로 끝 6자 유지
                    safe = max(0, len(buf) - len(_OPEN_TAG) + 1)
                    if safe:
                        yield "answer", buf[:safe]
                    buf = buf[safe:]
                    break

    # 스트림 종료 후 버퍼 플러시
    if buf:
        yield ("think" if in_think else "answer"), buf
