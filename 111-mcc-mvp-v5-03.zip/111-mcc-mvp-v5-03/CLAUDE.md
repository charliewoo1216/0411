# CLAUDE.md — Motion Parser MVP **v5**
> Claude Code가 이 프로젝트를 처음 열었을 때 읽는 문서.
> `설계참고.html`(v5 · 5-STEP 핵심 로직)을 **로컬·SQLite·무벡터DB**로 단순화한 구현 명세.

---

## 1. 프로젝트 목적

제조 장비의 원시 로그에서 **모션(동작) 이벤트를 자동 추출**해 **MEA 테이블에 적재**하고,
이를 정답지(oracle)로 한 **4-모듈 파서 패키지**를 ReAct 루프로 완성하는 Agentic AI 워크플로우.

- 장비 포맷을 사전 가정하지 않는다. LLM이 샘플 로그를 보고 페어/노이즈/키를 추론한다.
- **MEA 테이블 적재 + 파서 코드 완성**이 본 프로젝트의 핵심 산출이다.
- 파서 **실행 시점에는 LLM을 호출하지 않는다(0회)**. 결정론·재현성(byte-equal)을 보장한다.
- 페어링 규칙(A/B/C/D)은 **엔지니어가 확정**한다(LLM 자율 금지).

### v4 → v5 핵심 변경
| 항목 | v4 | v5 (현재) |
|---|---|---|
| STEP 2 | 이벤트분석 md | **장비로드 프롬프트 생성**(First-Run 인터뷰 → `EQP_PROMPTS`) |
| STEP 3 | 모션 페어링 md | **AI Analysis**: regex 전수 → `MEA` → 라벨링 → 사람 검수(LOCKED) |
| STEP 5 | Volume Test | **결과 리포트**(5테이블 집계 + 대시보드 + .md/.html) |
| 페어링 | Simple/Group/Conditional/Entity (LLM 자율) | **A/B/C/D 4지선다 (엔지니어 확정)** |
| 파서 | 단일 `parser_v1.py` | **4-모듈 패키지** |
| 검증 | "실행 성공 + 1행" | **byte-equal vs MEA(oracle) + 2회 결정론** |
| 저장 | 3종 md + `motion_events` | **SQLite 9테이블** + `prompts/*.md` |

---

## 2. 기술 스택

| 항목 | 내용 |
|------|------|
| UI | `streamlit` |
| LLM API | OpenAI-compatible (`openai`) — base_url/model/key는 UI에서 변경 |
| 모델 | `qwen3.5:9b` (기본값) · Base URL `http://192.168.0.8:8080/v1` · Key `sk_123!` |
| 저장소 | **`sqlite3`** (`output/events.db`, 9테이블) + 로컬 `.md`/`.py` |
| 벡터DB | **없음.** Milvus/BGE-M3/Hybrid RAG 미사용 → **매 호출 전체 컨텍스트를 넘기는 잦은 LLM 호출**로 대체 |
| NAS/EDS | **없음.** 로그는 `mcc-log-file/` 로컬, 산출물은 `output/` |
| 코드 실행 | `subprocess` (파서 VERIFY) |
| 상태 관리 | `PARSE_JOBS.STATUS` + `st.session_state` |

---

## 3. 폴더 구조

```
project/
├── CLAUDE.md / CHECKLIST.md / 작업방향.txt / 설계참고.html
├── app.py                      ← Streamlit 진입점 (5 STEP 라우터 · PARSE_JOBS 게이팅)
├── ai_config.py                ← AI Config + 장비 컨텍스트(EQP_ID/TYPE/USER)
├── requirements.txt
│
├── utils/
│   ├── db.py                   ← ★ SQLite 9테이블 + 전 CRUD + eqp_prompt_* + 집계
│   ├── parser_templates.py     ← ★ 로그 파싱·carry-state 레퍼런스 페어러·4-모듈 코드 생성기
│   ├── llm_client.py           ← LLM 래퍼 + compose_messages(컨텍스트 조립)
│   ├── log_sampler.py          ← 로그 탐색 + 균등 샘플링
│   ├── file_manager.py         ← output/ 경로 헬퍼 (prompts/parser/reports)
│   └── debug_logger.py         ← 디버그 로그
│
├── steps/
│   ├── step1_log_selection.py
│   ├── step2_eqp_prompt.py     ← 장비로드 프롬프트 생성 (First-Run)
│   ├── step3_ai_analysis.py    ← regex→MEA→라벨링→확정
│   ├── step4_code_generation.py← 4-모듈 ReAct + byte-equal VERIFY
│   └── step5_report.py         ← 결과 리포트
│
├── mcc-log-file/               ← 원시 로그 (읽기전용 · 절대 수정 금지)
│   └── asml-eventlog.log
└── output/                     ← 산출물 (자동 생성)
    ├── events.db               ← SQLite 9테이블
    ├── _verify_sandbox.db      ← VERIFY 전용 샌드박스(본 DB 오염 방지)
    ├── prompts/{eqp_id}.md     ← 장비로드 프롬프트
    ├── parser/                 ← 최종 4-모듈 파서 (+ v{n}/ iteration)
    ├── reports/{job}_{date}.md(.html)
    └── bak/                    ← v4 백업
```

---

## 4. SQLite 스키마 (`output/events.db`, 9테이블)

Oracle 11테이블에서 벡터/NFS 전용(`XML_FILES`·`EMBED_JOBS`)을 제거. `utils/db.py:init_db()`가 생성.

1. **PARSE_JOBS** — 작업 마스터. `STATUS`(INIT→STEP1~5_DONE)·`CURRENT_STEP`·`EQP_PROMPT_ID`·`PARSER_PATH`·`REPORT_PATH`·`TOTAL_ITER`
2. **EQP_PROMPTS** — 장비로드 프롬프트(단일 마스터). `PAIRING_STRATEGY`(A/B/C/D)·`ANALYSIS_STRATEGY`(JSON: pair_matrix·instance_regex·noise_codes·pending_pairs·discovery_log)·`LOCKED`·`FIRST_RUN_FLAG`
3. **MEA** — Motion Event Analysis(중심). `DATETIME·EVENT_CODE·ORIGIN_MESSAGE·EVENT_NAME·SIGNAL·START_CODE·END_CODE·IS_MOTION_RELATED·REMARK(task/wafer/lot/field prepend)·PROCESS_TIME_MS·CODE_GEN_OK`
4. **MOTION_EVENTS** — 파서 산출. `MOTION_TYPE·START_TS·END_TS·DURATION_MS·ENTITY_KEYS(JSON)·PARSER_VERSION`
5. **REACT_LOOPS** — ReAct 이력. `ITER_N·STATUS(MISMATCH/PASS/TIMEOUT)·DIFF_JSON(모듈별)·STDERR·PARSER_PATH`
6. **CHAT_SESSIONS** / 7. **CHAT_MESSAGES** — L2 멀티턴 메모리(phase: interview/preflight_review/labeling_review)
8. **audit_log** — 엔지니어 사인/변경 이력
9. **LOG_FILES** — 선택 로그 파일 메타(단순화)

> **메모리 모델(무벡터)**: L1 = `EQP_PROMPTS.ANALYSIS_STRATEGY`(영구 draft), L2 = `CHAT_*`(DB). L3(Milvus)은 제거하고, 매 LLM 호출에 **샘플 로그 + 최근 N턴 + rolling 요약 + draft**를 통째로 전달한다(`llm_client.compose_messages`).

---

## 5. Streamlit UI · 진행 게이팅

사이드바: AI Config + 장비 컨텍스트 + 5 STEP 버튼. 게이팅은 `PARSE_JOBS.STATUS`로 판정한다.
- STEP n 활성 = `STATUS` 가 `STEP{n-1}_DONE` 이상.
- **First-Run 아니면**(EQP_PROMPTS 존재) STEP1 완료 후 STEP2를 건너뛰고 **STEP3 직진** 가능.
- 앱 부팅 시 `init_db()` + `PARSE_JOBS` 생성/복원. 미완료 작업은 복원, 완료(STEP5_DONE)면 신규 생성.

---

## 6. 각 STEP 명세 (핵심 로직)

### STEP 1 — Log Selection (`step1_log_selection.py`)
`mcc-log-file/` 재귀 탐색 → 체크박스 선택 → `LOG_FILES` 기록 → `target_lines` 균등 샘플링 →
`session_state['sampled_lines']`. **LLM 미사용.** 완료 시 `STATUS=STEP1_DONE`.

### STEP 2 — 장비로드 프롬프트 생성 (`step2_eqp_prompt.py`) · First-Run only
- ② **AI 사전분석 카드**: `parser_templates.discover_pairs_heuristic` 로 페어/노이즈 후보 산출(+선택 LLM 요약)
- ② **엔지니어 인터뷰**: `st.chat_input`. 매 턴 `CHAT_MESSAGES` 적재, `compose_messages`로 전체 컨텍스트 LLM 호출
- ④ **영구화**: `prompts/{eqp_id}.md` + `EQP_PROMPTS` INSERT(`LOCKED=N`, draft) + `audit_log`. `STATUS=STEP2_DONE`

### STEP 3 — AI Analysis · MEA (`step3_ai_analysis.py`)
- ① `eqp_prompt_load` — pair_matrix·regex·noise·strategy 로드
- ③ **REGEX 전수 추출 → MEA [HIGH RECALL]**: 모든 `LO-*` 추출, `REMARK`에 task/wafer/lot/field prepend, `MEA` bulk INSERT (**LLM 0회·결정론**)
- ④ **라벨링**: pair_matrix 기반 **결정론 규칙 라벨**(signal·start/end_code·is_motion_related) + (선택) LLM 해석/신규페어 propose. **매칭은 결정론 carry-state**(LLM 아님)
- ⑤ **Human 검수 + 확정**: pair_matrix 편집 + `pairing_strategy` 4지선다 → `eqp_prompt_confirm`(`LOCKED=Y`) + MEA 재라벨. `STATUS=STEP3_DONE`

### STEP 4 — Code Generation · 4-모듈 (`step4_code_generation.py`)
- ① **PLAN**: `EQP_PROMPTS`(LOCKED) → `build_codegen_strategy` (확정 strategy→algo, **LLM 자율 금지**)
- ② **GENERATE**: `build_parser_package` 로 `parser/v{n}/` 4-모듈 생성 (pair_matrix 인라인)
- ③ **VERIFY**: `subprocess`로 `main.py` 실행 → **byte-equal 2단** ((a) MEA START/END vs 확정 MEA, (b) MOTION_EVENTS vs 레퍼런스 페어러) + **2회 결정론**. `REACT_LOOPS` 기록
- ④ **REFLECT**: DIFF(start/end/time)로 고칠 모듈 지목 (max 10회)
- ⑤ **DONE**: `parser/` 승격 + `MOTION_EVENTS` 적재 + `MEA.PROCESS_TIME_MS/CODE_GEN_OK` 갱신. `STATUS=STEP4_DONE`

**4-모듈**: `parser_start_code.py`(start 추출) · `parser_end_code.py`(end 추출) · `calculate_process_time.py`(carry-state 페어링→process_time) · `main.py`(orchestration · `--input/--db/--job`). **외부 import: re·collections·sqlite3·argparse·datetime·json 만.**

### STEP 5 — 결과 리포트 (`step5_report.py`)
5테이블 집계(`aggregate_summary`) → 메트릭/대시보드(MEA·MOTION_EVENTS·차트·CSV) → `reports/{job}_{date}.md(.html)` → `STATUS=STEP5_DONE`.

---

## 7. 핵심 유틸 (`utils/`)

- **db.py** — `init_db`·`create_job`/`advance_status`·`eqp_prompt_load/insert/propose/confirm`·`mea_bulk_insert/update_batch/select`·`motion_events_bulk_insert`·`react_loop_insert`·`chat_*`·`audit_insert`·`aggregate_summary`·`reset_sandbox`
- **parser_templates.py** — `parse_log_line`·`build_remark/parse_remark`·`discover_pairs_heuristic`·`entity_key`(A/B/C/D)·`reference_pair`(carry-state)·`event_sort_key`·`canonical_motions/canonical_mea_events`(byte-equal)·`build_codegen_strategy`·`build_parser_package`
- **llm_client.py** — `LLMClient.chat/stream_chat`·`build_client_from_session`·`compose_messages`(무RAG 컨텍스트 조립)

### 실제 로그 정규식 (asml-eventlog.log · `DEFAULT_INSTANCE_REGEX`)
```
datetime  (\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2}\.\d{4})   # .ffff = 10^-4초
code      SYSTEM EVENT:\s*(LO-\w+)
task_id   LOMW\[(\d+)\]     wafer  wafer number (\d+)     lot  lot id (\d+)     field  field (\d+)
source    (LOMWx\w+\.\w+)   signal started→START / finished→END / 기타→MID
noise     LO-9xxx · LO-7xxx → IS_MOTION_RELATED=N
pair      대부분 +1(8011→8012), 일부 hex(8029→802A) → pair_matrix 명시 (산술추론 금지)
```

### 페어링 4지선다 (`entity_key`)
- **A** dict_composite — (code, task, wafer, lot, field)
- **B** fifo_queue — (code, wafer, lot) + FIFO
- **C** dict_lomw_validated — LOMW[task] 단독 1:1 (**본 로그 권장**)
- **D** wafer/lot 우선 + LOMW fallback

**carry-state**: `open[(start_code, entity_key)]` 스택. START push / END pop(B=FIFO, 그 외 LIFO). 잔여 start = orphan. **레퍼런스 페어러와 생성 파서가 `event_sort_key`(내용 기반 정렬)를 공유** → byte-equal 정합.

---

## 8. 절대 규칙 (필독)

1. **`mcc-log-file/` 는 절대 수정 금지** (읽기 전용).
2. **모든 산출물은 `output/` 에만** 저장.
3. **파서 패키지 실행 시 LLM 0회** — 외부 import 제약 준수.
4. **VERIFY 는 MEA(oracle) 기준 byte-equal** — MEA 미확정 시 STEP 4 진입 불가.
5. **pairing_strategy 는 엔지니어 확정** — LLM 자율 결정 금지.
6. LLM 호출은 try/except + `st.error`. 긴 응답은 스트리밍. `exec`/`subprocess`는 timeout.
7. 주석·UI는 한글, 변수/함수는 snake_case 영어, 상수 UPPER_CASE.
8. `st.session_state` 키와 `PARSE_JOBS.STATUS` 라이프사이클을 임의 변경하지 말 것.

---

## 9. 샘플 로그 (asml-eventlog.log)

```
04/27/2026 09:00:00.2190 Machine:JB64 (Rel:6.3.0.b, LOMW[13206], LOMWxKC_load_cassette.c) SYSTEM EVENT: LO-8011 DEFAULT Cassette load started. ... 25 wafers detected.
04/27/2026 09:00:09.4233 Machine:JB64 (Rel:6.3.0.b, LOMW[13206], LOMWxKC_load_cassette.c) SYSTEM EVENT: LO-8012 DEFAULT Cassette load finished. ...
04/27/2026 09:00:13.8974 Machine:JB64 (Rel:6.3.0.b, LOMW[13211], LOMWxSY_heartbeat.c) SYSTEM EVENT: LO-9001 DEFAULT System heartbeat OK.   # noise
```
- `LO-8011→LO-8012` = load_cassette (start↔end, 동일 `LOMW[13206]`)
- 모션 ~50종 / `LO-9xxx`·`LO-7xxx` 노이즈 12종 / 멀티스레드 비순차 → 시간순 정렬 후 페어링

---

## 10. requirements.txt
```
streamlit>=1.32.0
openai>=1.20.0
pandas>=2.0.0
```
> SQLite/argparse/collections 는 표준 라이브러리. cx_Oracle·Milvus 불필요.
