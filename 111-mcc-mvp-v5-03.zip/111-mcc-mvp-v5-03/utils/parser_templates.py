"""
파서 템플릿 & 레퍼런스 로직 (v5).

본 모듈은 두 가지를 제공한다.
1) STEP 3-③ regex 전수 추출 / STEP 2 AI 사전분석에 쓰는 **로그 파싱 헬퍼**
   (parse_log_line · build_remark · parse_remark · discover_pairs_heuristic)
2) STEP 4 VERIFY의 **기댓값 산출용 레퍼런스 페어러**(reference_pair) —
   생성된 파서 패키지(calculate_process_time)가 구현해야 할 carry-state 매칭과
   동일 로직. 동일 로직이므로 byte-equal 정합이 보장된다.
3) STEP 4 GENERATE 프롬프트에 인라인할 **4-모듈 템플릿 힌트**(MODULE_TEMPLATE_HINT).

페어링 4지선다(A/B/C/D)별 entity-key 추출 규칙을 한 곳에서 정의한다.
"""
from __future__ import annotations

import json
import re
from collections import defaultdict
from datetime import datetime

# ─────────────────────────────────────────────
# 정규식 시드 (asml-eventlog.log 기준 · EQP_PROMPTS.instance_regex 기본값)
# ─────────────────────────────────────────────
DEFAULT_INSTANCE_REGEX: dict[str, str] = {
    "datetime": r"(\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2}\.\d{4})",
    "machine": r"Machine:(\w+)",
    "source": r"(LOMWx\w+\.\w+)",
    "code": r"SYSTEM EVENT:\s*(LO-\w+)",
    "task_id": r"LOMW\[(\d+)\]",
    "wafer": r"wafer number (\d+)",
    "lot": r"lot id (\d+)",
    "field": r"field (\d+)",
}

# noise 코드(모션 무관) — LO-9xxx / LO-7xxx (heartbeat·env·warn)
DEFAULT_NOISE_PREFIXES = ("LO-9", "LO-7")

DATETIME_FMT = "%m/%d/%Y %H:%M:%S.%f"

_RE = {k: re.compile(v) for k, v in DEFAULT_INSTANCE_REGEX.items()}
# 소스파일에서 모션 이름 추출: LOMWxKM_measure_wafer.c → measure_wafer
_RE_MOTION = re.compile(r"LOMWx\w\w_(\w+)\.\w+")

# 페어링 전략 → algo 매핑
STRATEGY_ALGO = {
    "A": "dict_composite",          # (code, task, wafer, lot, field)
    "B": "fifo_queue",              # (code, wafer, lot) + FIFO
    "C": "dict_lomw_validated",     # LOMW[task] 단독 1:1
    "D": "dict_wafer_lot_lomw_fallback",  # wafer/lot 우선 + task fallback
}


# ─────────────────────────────────────────────
# 로그 파싱
# ─────────────────────────────────────────────
def parse_log_line(line: str) -> dict | None:
    """한 줄을 파싱해 정규화 dict 반환. 이벤트 코드가 없으면 None(빈 줄/주석 포함)."""
    if not line or not line.strip() or line.lstrip().startswith("#"):
        return None
    m_code = _RE["code"].search(line)
    if not m_code:
        return None
    m_dt = _RE["datetime"].search(line)
    m_task = _RE["task_id"].search(line)
    m_wafer = _RE["wafer"].search(line)
    m_lot = _RE["lot"].search(line)
    m_field = _RE["field"].search(line)
    m_src = _RE["source"].search(line)

    low = line.lower()
    if "started" in low:
        signal = "START"
    elif "finished" in low:
        signal = "END"
    else:
        signal = "MID"

    return {
        "datetime": m_dt.group(1) if m_dt else "",
        "code": m_code.group(1),
        "task": m_task.group(1) if m_task else "",
        "wafer": m_wafer.group(1) if m_wafer else "",
        "lot": m_lot.group(1) if m_lot else "",
        "field": m_field.group(1) if m_field else "",
        "source": m_src.group(1) if m_src else "",
        "signal": signal,
        "origin": line.rstrip("\n"),
    }


def is_noise(code: str) -> bool:
    return any(code.startswith(p) for p in DEFAULT_NOISE_PREFIXES)


def motion_name_from_source(source: str) -> str:
    m = _RE_MOTION.search(source or "")
    return m.group(1) if m else ""


def build_remark(ev: dict) -> str:
    """task/wafer/lot/field 4종을 REMARK 에 prepend(스키마 무변경 우회)."""
    parts = []
    for k in ("task", "wafer", "lot", "field"):
        v = ev.get(k)
        if v:
            parts.append(f"{k}={v}")
    return " | ".join(parts)


def parse_remark(remark: str | None) -> dict:
    """REMARK 문자열에서 task/wafer/lot/field 복원."""
    out = {"task": "", "wafer": "", "lot": "", "field": ""}
    if not remark:
        return out
    for tok in remark.split("|"):
        tok = tok.strip()
        if "=" in tok:
            k, _, v = tok.partition("=")
            k = k.strip()
            if k in out:
                out[k] = v.strip()
    return out


def parse_dt(s: str) -> datetime | None:
    try:
        return datetime.strptime(s, DATETIME_FMT)
    except Exception:
        return None


# ─────────────────────────────────────────────
# 페어 자동발견 (heuristic) — STEP 2 AI 사전분석 카드 / LLM 미가용 시 폴백
# ─────────────────────────────────────────────
def discover_pairs_heuristic(events: list[dict]) -> list[dict]:
    """
    task_id 를 공유하는 started/finished 이벤트를 묶어 (start_code, end_code) 페어 후보 생성.
    반환: [{start, end, motion, source, count}, ...]
    """
    by_task: dict[str, list[dict]] = defaultdict(list)
    for ev in events:
        if ev.get("task"):
            by_task[ev["task"]].append(ev)

    pair_counter: dict[tuple, dict] = {}
    for task, evs in by_task.items():
        evs_sorted = sorted(evs, key=lambda e: (e.get("datetime", ""),))
        open_stack: list[dict] = []
        for ev in evs_sorted:
            if is_noise(ev["code"]):
                continue
            if ev["signal"] == "START":
                open_stack.append(ev)
            elif ev["signal"] == "END" and open_stack:
                s = open_stack.pop()
                key = (s["code"], ev["code"])
                rec = pair_counter.setdefault(
                    key,
                    {
                        "start": s["code"],
                        "end": ev["code"],
                        "motion": motion_name_from_source(s.get("source")) or "motion",
                        "source": s.get("source", ""),
                        "count": 0,
                    },
                )
                rec["count"] += 1
    return sorted(pair_counter.values(), key=lambda r: -r["count"])


# ─────────────────────────────────────────────
# entity-key (페어링 전략별)
# ─────────────────────────────────────────────
def entity_key(ev: dict, strategy: str) -> tuple:
    """전략별 매칭 키. ev 는 {task,wafer,lot,field} 보유(parse_log_line/parse_remark 결과)."""
    if strategy == "A":  # dict_composite
        return (ev.get("task", ""), ev.get("wafer", ""), ev.get("lot", ""), ev.get("field", ""))
    if strategy == "B":  # fifo_queue
        return (ev.get("wafer", ""), ev.get("lot", ""))
    if strategy == "C":  # dict_lomw_validated
        return (ev.get("task", ""),)
    if strategy == "D":  # wafer/lot 우선 + task fallback
        if ev.get("wafer") or ev.get("lot"):
            return (ev.get("wafer", ""), ev.get("lot", ""))
        return (ev.get("task", ""),)
    return (ev.get("task", ""),)


def _pop_index(strategy: str) -> int:
    # B(FIFO)=가장 오래된 것, 나머지=가장 최근(LIFO · 중첩 안전)
    return 0 if strategy == "B" else -1


def event_sort_key(ev: dict) -> tuple:
    """입력 순서와 무관한 **내용 기반** 결정론 정렬 키.
    레퍼런스 페어러와 생성 파서가 동일 키를 써야 byte-equal 정합이 보장된다."""
    sig = ev.get("signal", "")
    sig_rank = 0 if sig == "START" else (1 if sig == "END" else 2)
    return (
        ev.get("datetime", ""), sig_rank, ev.get("code", ""),
        ev.get("task", ""), ev.get("wafer", ""), ev.get("lot", ""), ev.get("field", ""),
    )


# ─────────────────────────────────────────────
# 레퍼런스 페어러 (VERIFY 기댓값) — 생성 파서와 동일 carry-state
# ─────────────────────────────────────────────
def reference_pair(events: list[dict], pair_matrix: list[dict], strategy: str,
                   eqp_id: str = "", parser_version: str = "ref") -> list[dict]:
    """
    carry-state 매칭으로 MOTION_EVENTS 기댓값 산출.
    events: parse_log_line 또는 MEA 복원 결과(datetime/code/task/wafer/lot/field/signal).
    반환 row: {motion_type, start_ts, end_ts, duration_ms, entity_keys(json), eqp_id, parser_version}
    """
    start_codes = {p["start"] for p in pair_matrix}
    end_to_start = {p["end"]: p["start"] for p in pair_matrix}
    end_to_motion = {p["end"]: p.get("motion", "motion") for p in pair_matrix}
    pop_i = _pop_index(strategy)

    # 내용 기반 정렬(멀티스레드 비순차 + 입력 순서 무관 결정론)
    ordered = sorted(events, key=event_sort_key)

    open_map: dict[tuple, list[dict]] = defaultdict(list)
    motions: list[dict] = []

    for ev in ordered:
        code = ev.get("code", "")
        if code in start_codes:
            key = (code, entity_key(ev, strategy))
            open_map[key].append(ev)
        elif code in end_to_start:
            start_code = end_to_start[code]
            key = (start_code, entity_key(ev, strategy))
            if open_map[key]:
                s = open_map[key].pop(pop_i)
                s_dt, e_dt = parse_dt(s.get("datetime", "")), parse_dt(ev.get("datetime", ""))
                dur = round((e_dt - s_dt).total_seconds() * 1000.0, 3) if (s_dt and e_dt) else None
                ekeys = {k: s.get(k, "") for k in ("task", "wafer", "lot", "field")}
                motions.append({
                    "motion_type": end_to_motion.get(code, "motion"),
                    "start_ts": s.get("datetime", ""),
                    "end_ts": ev.get("datetime", ""),
                    "duration_ms": dur,
                    "entity_keys": json.dumps(ekeys, ensure_ascii=False, sort_keys=True),
                    "eqp_id": eqp_id,
                    "parser_version": parser_version,
                })
            # orphan end → skip
    return motions


def events_from_mea(mea_rows: list[dict], motion_only: bool = True) -> list[dict]:
    """MEA row → reference_pair 입력 정규화 dict. REMARK 에서 entity 복원."""
    out: list[dict] = []
    for r in mea_rows:
        if motion_only and r.get("IS_MOTION_RELATED") != "Y":
            continue
        ek = parse_remark(r.get("REMARK"))
        out.append({
            "datetime": r.get("DATETIME", ""),
            "code": r.get("EVENT_CODE", ""),
            "signal": r.get("SIGNAL", ""),
            "task": ek["task"], "wafer": ek["wafer"], "lot": ek["lot"], "field": ek["field"],
        })
    return out


# ─────────────────────────────────────────────
# byte-equal 정규화
# ─────────────────────────────────────────────
def canonical_motions(rows: list[dict]) -> str:
    """MOTION_EVENTS 행들을 결정론 정규화 문자열로(byte-equal 비교용)."""
    proj = sorted(
        (
            str(r.get("motion_type") or r.get("MOTION_TYPE") or ""),
            str(r.get("start_ts") or r.get("START_TS") or ""),
            str(r.get("end_ts") or r.get("END_TS") or ""),
            f"{float(r.get('duration_ms') or r.get('DURATION_MS') or 0):.3f}",
            str(r.get("entity_keys") or r.get("ENTITY_KEYS") or ""),
        )
        for r in rows
    )
    return "\n".join("\t".join(p) for p in proj)


def canonical_mea_events(mea_rows: list[dict]) -> str:
    """MEA의 START/END 모션 행을 결정론 정규화(byte-equal 비교용)."""
    proj = sorted(
        (str(r.get("DATETIME") or ""), str(r.get("EVENT_CODE") or ""), str(r.get("SIGNAL") or ""))
        for r in mea_rows
        if r.get("SIGNAL") in ("START", "END") and r.get("IS_MOTION_RELATED") == "Y"
    )
    return "\n".join("\t".join(p) for p in proj)


# ─────────────────────────────────────────────
# STEP 4 GENERATE 프롬프트용 4-모듈 템플릿 힌트
# ─────────────────────────────────────────────
MODULE_TEMPLATE_HINT = r'''
[parser 패키지 4-모듈 명세 · 외부 import 는 re·collections·sqlite3·argparse·datetime 만 허용]
※ 실행 시 LLM 호출 0회. 결정론(동일 입력 → byte 동일 출력). dict 순서/정렬 강제.

파일 1) parser_start_code.py
  - def extract_starts(lines, regex, start_codes) -> list[dict]
  - raw_log 라인에서 SIGNAL=START(메시지 'started') 이고 code 가 start_codes 인 행을 추출
  - 각 행: {datetime, code, task, wafer, lot, field, origin, signal:'START'}

파일 2) parser_end_code.py
  - def extract_ends(lines, regex, end_codes) -> list[dict]
  - SIGNAL=END(메시지 'finished') 이고 code 가 end_codes 인 행 추출

파일 3) calculate_process_time.py
  - def pair_and_time(starts, ends, pair_matrix, strategy) -> (motions, mea_rows)
  - carry-state 매칭: open[(start_code, entity_key)] 스택. START push / END pop.
    entity_key 는 strategy(A/B/C/D)별 규칙. B 는 FIFO(pop[0]), 그 외 LIFO(pop[-1]).
  - duration_ms = (end_dt - start_dt).total_seconds()*1000, datetime fmt "%m/%d/%Y %H:%M:%S.%f"
  - MOTION_EVENTS 행 + MEA(START/END) 행 산출. orphan(잔여 start) 은 motion 미생성.

파일 4) main.py  (단일 진입점)
  - argparse: --input <log> --db <sqlite> [--job <id>]
  - sqlite3 로 MEA / MOTION_EVENTS 테이블 보장(CREATE IF NOT EXISTS) 후
    extract_starts + extract_ends → MEA INSERT, pair_and_time → MOTION_EVENTS INSERT
  - 모든 INSERT 는 (start_ts, motion_type, entity_keys) 정렬 후 수행(결정론)
  - pair_matrix / strategy / regex 는 코드에 인라인 hardcode(아래 codegen_strategy 사용)
'''


# ─────────────────────────────────────────────
# 결정론 4-모듈 코드 생성기 (parser 템플릿 내장 · strategy→algo)
#   설계: "strategy → algo 매핑 (parser 템플릿 내장)" · pair_matrix 인라인 hardcode
# ─────────────────────────────────────────────
def build_codegen_strategy(eqp_prompt: dict) -> dict:
    """EQP_PROMPTS(LOCKED) → codegen_strategy JSON (STEP 4-① PLAN)."""
    a = eqp_prompt.get("analysis") or {}
    strategy = eqp_prompt.get("PAIRING_STRATEGY") or "C"
    return {
        "algo": STRATEGY_ALGO.get(strategy, "dict_lomw_validated"),
        "strategy": strategy,
        "pair_matrix": a.get("pair_matrix", []),
        "instance_regex": a.get("instance_regex") or DEFAULT_INSTANCE_REGEX,
        "noise_codes": a.get("noise_codes", []),
        "eqp_id": eqp_prompt.get("EQP_ID", ""),
    }


_START_MODULE = '''"""parser_start_code.py — start_code 추출 (LLM 0회)."""
import re


def extract_starts(lines, regex, start_codes):
    rc = {{k: re.compile(v) for k, v in regex.items()}}
    out = []
    for ln in lines:
        if not ln.strip() or ln.lstrip().startswith("#"):
            continue
        mc = rc["code"].search(ln)
        if not mc or mc.group(1) not in start_codes:
            continue
        if "started" not in ln.lower():
            continue
        out.append(_row(rc, ln, mc.group(1), "START"))
    return out


def _row(rc, ln, code, signal):
    def g(k):
        m = rc[k].search(ln)
        return m.group(1) if m else ""
    return {{"datetime": g("datetime"), "code": code, "task": g("task_id"),
            "wafer": g("wafer"), "lot": g("lot"), "field": g("field"),
            "origin": ln.rstrip("\\n"), "signal": signal}}
'''

_END_MODULE = '''"""parser_end_code.py — end_code 추출 (LLM 0회)."""
import re


def extract_ends(lines, regex, end_codes):
    rc = {{k: re.compile(v) for k, v in regex.items()}}
    out = []
    for ln in lines:
        if not ln.strip() or ln.lstrip().startswith("#"):
            continue
        mc = rc["code"].search(ln)
        if not mc or mc.group(1) not in end_codes:
            continue
        if "finished" not in ln.lower():
            continue
        out.append(_row(rc, ln, mc.group(1), "END"))
    return out


def _row(rc, ln, code, signal):
    def g(k):
        m = rc[k].search(ln)
        return m.group(1) if m else ""
    return {{"datetime": g("datetime"), "code": code, "task": g("task_id"),
            "wafer": g("wafer"), "lot": g("lot"), "field": g("field"),
            "origin": ln.rstrip("\\n"), "signal": signal}}
'''

_CALC_MODULE = '''"""calculate_process_time.py — carry-state 페어링 → process_time (LLM 0회)."""
import json
from collections import defaultdict
from datetime import datetime

DT_FMT = "%m/%d/%Y %H:%M:%S.%f"


def _ek(ev, strategy):
    if strategy == "A":
        return (ev.get("task", ""), ev.get("wafer", ""), ev.get("lot", ""), ev.get("field", ""))
    if strategy == "B":
        return (ev.get("wafer", ""), ev.get("lot", ""))
    if strategy == "C":
        return (ev.get("task", ""),)
    if strategy == "D":
        if ev.get("wafer") or ev.get("lot"):
            return (ev.get("wafer", ""), ev.get("lot", ""))
        return (ev.get("task", ""),)
    return (ev.get("task", ""),)


def _key(ev):
    sig = ev.get("signal", "")
    rank = 0 if sig == "START" else (1 if sig == "END" else 2)
    return (ev.get("datetime", ""), rank, ev.get("code", ""),
            ev.get("task", ""), ev.get("wafer", ""), ev.get("lot", ""), ev.get("field", ""))


def pair_and_time(starts, ends, pair_matrix, strategy):
    start_codes = {{p["start"] for p in pair_matrix}}
    end_to_start = {{p["end"]: p["start"] for p in pair_matrix}}
    end_to_motion = {{p["end"]: p.get("motion", "motion") for p in pair_matrix}}
    pop_i = 0 if strategy == "B" else -1

    events = starts + ends
    ordered = sorted(events, key=_key)
    open_map = defaultdict(list)
    motions = []
    for ev in ordered:
        code = ev["code"]
        if code in start_codes:
            open_map[(code, _ek(ev, strategy))].append(ev)
        elif code in end_to_start:
            sc = end_to_start[code]
            key = (sc, _ek(ev, strategy))
            if open_map[key]:
                s = open_map[key].pop(pop_i)
                try:
                    sd = datetime.strptime(s["datetime"], DT_FMT)
                    ed = datetime.strptime(ev["datetime"], DT_FMT)
                    dur = round((ed - sd).total_seconds() * 1000.0, 3)
                except Exception:
                    dur = None
                ek = {{k: s.get(k, "") for k in ("task", "wafer", "lot", "field")}}
                motions.append({{
                    "motion_type": end_to_motion.get(code, "motion"),
                    "start_ts": s["datetime"], "end_ts": ev["datetime"],
                    "duration_ms": dur,
                    "entity_keys": json.dumps(ek, ensure_ascii=False, sort_keys=True),
                }})
    mea_rows = [{{"datetime": e["datetime"], "code": e["code"], "signal": e["signal"]}} for e in events]
    return motions, mea_rows
'''

_MAIN_MODULE = '''"""main.py — 4-모듈 오케스트레이션 · 단일 진입점.
사용: python main.py --input <log> --db <sqlite> [--job <id>]
실행 시 LLM 호출 0회 · 결정론(byte-equal).
"""
import argparse
import json
import os
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from parser_start_code import extract_starts
from parser_end_code import extract_ends
from calculate_process_time import pair_and_time

# ── 인라인 codegen_strategy (STEP 3 확정값) ──
REGEX = {regex_json}
PAIR_MATRIX = {pairs_json}
STRATEGY = {strategy!r}
NOISE_CODES = {noise_json}
EQP_ID = {eqp_id!r}
PARSER_VERSION = "v1"
START_CODES = set(p["start"] for p in PAIR_MATRIX)
END_CODES = set(p["end"] for p in PAIR_MATRIX)

DDL = """
CREATE TABLE IF NOT EXISTS MEA (
  MEA_ID INTEGER PRIMARY KEY AUTOINCREMENT, JOB_ID VARCHAR2(36), DATETIME TIMESTAMP, EVENT_CODE VARCHAR2(50),
  ORIGIN_MESSAGE VARCHAR2(2000), EVENT_NAME VARCHAR2(200), SIGNAL VARCHAR2(10), START_CODE VARCHAR2(50), END_CODE VARCHAR2(50),
  LLM_INTERPRETATION CLOB, IS_MOTION_RELATED CHAR(1), ENGINEER_INTERPRETATION CLOB, REMARK VARCHAR2(500),
  PROCESS_TIME_MS NUMBER(12,3), CODE_GEN_OK CHAR(1), CREATED_AT TIMESTAMP, UPDATED_AT TIMESTAMP);
CREATE TABLE IF NOT EXISTS MOTION_EVENTS (
  EVENT_ID INTEGER PRIMARY KEY AUTOINCREMENT, JOB_ID VARCHAR2(36), EQP_ID VARCHAR2(50), MOTION_TYPE VARCHAR2(50),
  START_TS TIMESTAMP, END_TS TIMESTAMP, DURATION_MS NUMBER, ENTITY_KEYS CLOB, PARSER_VERSION VARCHAR2(10), TS TIMESTAMP);
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--db", required=True)
    ap.add_argument("--job", default="cli")
    args = ap.parse_args()

    with open(args.input, encoding="utf-8", errors="replace") as f:
        lines = f.read().splitlines()

    starts = extract_starts(lines, REGEX, START_CODES)
    ends = extract_ends(lines, REGEX, END_CODES)
    motions, mea_rows = pair_and_time(starts, ends, PAIR_MATRIX, STRATEGY)

    conn = sqlite3.connect(args.db)
    conn.executescript(DDL)
    # MEA (START/END 모션 행) — 결정론 정렬 후 INSERT
    mea_sorted = sorted(mea_rows, key=lambda r: (r["datetime"], r["code"], r["signal"]))
    conn.executemany(
        "INSERT INTO MEA (JOB_ID, DATETIME, EVENT_CODE, SIGNAL, IS_MOTION_RELATED) VALUES (?,?,?,?,'Y')",
        [(args.job, r["datetime"], r["code"], r["signal"]) for r in mea_sorted],
    )
    # MOTION_EVENTS — 결정론 정렬 후 INSERT
    mot_sorted = sorted(motions, key=lambda m: (m["start_ts"], m["motion_type"], m["entity_keys"]))
    conn.executemany(
        "INSERT INTO MOTION_EVENTS (JOB_ID, EQP_ID, MOTION_TYPE, START_TS, END_TS, DURATION_MS, ENTITY_KEYS, PARSER_VERSION, TS) "
        "VALUES (?,?,?,?,?,?,?,?,'')",
        [(args.job, EQP_ID, m["motion_type"], m["start_ts"], m["end_ts"], m["duration_ms"], m["entity_keys"], PARSER_VERSION) for m in mot_sorted],
    )
    conn.commit()
    conn.close()
    print(json.dumps({{"mea_rows": len(mea_sorted), "motions": len(mot_sorted)}}))


if __name__ == "__main__":
    main()
'''


def build_parser_package(codegen_strategy: dict) -> dict[str, str]:
    """codegen_strategy → 4-모듈 소스 dict {filename: source}. 결정론·standalone."""
    regex_json = json.dumps(codegen_strategy.get("instance_regex") or DEFAULT_INSTANCE_REGEX, ensure_ascii=False, indent=4)
    pairs_json = json.dumps(codegen_strategy.get("pair_matrix", []), ensure_ascii=False, indent=4)
    noise_json = json.dumps(codegen_strategy.get("noise_codes", []), ensure_ascii=False)
    main_src = _MAIN_MODULE.format(
        regex_json=regex_json, pairs_json=pairs_json,
        strategy=codegen_strategy.get("strategy", "C"),
        noise_json=noise_json, eqp_id=codegen_strategy.get("eqp_id", ""),
    )
    return {
        "parser_start_code.py": _START_MODULE.format(),
        "parser_end_code.py": _END_MODULE.format(),
        "calculate_process_time.py": _CALC_MODULE.format(),
        "main.py": main_src,
    }
