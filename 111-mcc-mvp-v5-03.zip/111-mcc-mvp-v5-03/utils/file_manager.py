"""
output/ 폴더 파일 입출력 유틸 (v5).
산출물 경로: output/{events.db, prompts/, parser/, parser/v{n}/, reports/, bak/}.
md/py/json 저장·로드 + 하위 디렉토리 경로 헬퍼.
단계 완료 판정은 PARSE_JOBS.STATUS(utils.db) 로 하므로 파일 기반 check 는 제거.
"""
from __future__ import annotations

import json
from pathlib import Path

OUTPUT_DIR = Path("output")
PROMPTS_DIR = OUTPUT_DIR / "prompts"      # 장비로드 프롬프트 .md (STEP 2)
PARSER_DIR = OUTPUT_DIR / "parser"        # 최종 4-모듈 파서 패키지 (STEP 4)
REPORTS_DIR = OUTPUT_DIR / "reports"      # 결과 리포트 .md/.html (STEP 5)


def ensure_dirs() -> None:
    for d in (OUTPUT_DIR, PROMPTS_DIR, PARSER_DIR, REPORTS_DIR):
        d.mkdir(parents=True, exist_ok=True)


def output_path(filename: str) -> Path:
    ensure_dirs()
    return OUTPUT_DIR / filename


def prompts_path(filename: str) -> Path:
    ensure_dirs()
    return PROMPTS_DIR / filename


def reports_path(filename: str) -> Path:
    ensure_dirs()
    return REPORTS_DIR / filename


def parser_version_dir(n: int) -> Path:
    """ReAct iteration 작업 폴더 output/parser/v{n}/."""
    ensure_dirs()
    d = PARSER_DIR / f"v{n}"
    d.mkdir(parents=True, exist_ok=True)
    return d


# ── 텍스트/마크다운/파이썬/JSON ──────────────
def save_text(path: str | Path, content: str) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return p


def load_text(path: str | Path) -> str | None:
    p = Path(path)
    if not p.exists():
        return None
    try:
        return p.read_text(encoding="utf-8")
    except Exception:
        return None


def save_md(filename: str, content: str) -> Path:
    return save_text(output_path(filename), content)


def load_md(filename: str) -> str | None:
    return load_text(output_path(filename))


def save_py(path: str | Path, content: str) -> Path:
    return save_text(path, content)


def load_py(path: str | Path) -> str | None:
    return load_text(path)


def save_json(path: str | Path, obj) -> Path:
    return save_text(path, json.dumps(obj, ensure_ascii=False, indent=2))


def load_json(path: str | Path):
    raw = load_text(path)
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None
