"""
로그 파일 탐색 + 행처리(논리행 재구성) + 균등 샘플링 유틸.
- scan_log_files(): .log/.txt/.csv 재귀 탐색, 인코딩 자동 감지, 물리행/논리행(이벤트) 수 카운트
- read_logical_lines(): 타임스탬프 앵커 기준으로 멀티라인 이벤트 블록을 1행으로 병합
- sample_logs(): 논리행 단위로 파일별 비례 배분 + stride 균등 샘플링
- estimate_tokens(): 글자수 / 3.5 로 토큰 추정
모두 결정론 · LLM 0회.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Callable, Iterable

# 인코딩 시도 순서 — 한국어 로그 호환
ENCODING_CANDIDATES = ["utf-8", "utf-8-sig", "cp949", "euc-kr", "latin-1"]
LOG_SUFFIXES = {".log", ".txt", ".csv"}

# 이벤트(논리행) 시작 앵커: 줄 머리의 MM/DD/YYYY HH:MM:SS.ffff
# parser_templates.DEFAULT_INSTANCE_REGEX['datetime'] 와 동일 포맷 (앵커는 ^ 고정).
TS_ANCHOR = re.compile(r"^\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2}\.\d{4}")


def _join_block(parts: list[str]) -> str:
    """이벤트 블록(타임스탬프 줄 + 연속 줄)을 공백 1칸으로 병합해 1행으로."""
    head = parts[0].rstrip()
    rest = " ".join(p.strip() for p in parts[1:] if p.strip())
    return f"{head} {rest}".strip() if rest else head


def read_logical_lines(path: Path, encoding: str) -> list[str]:
    """
    타임스탬프 앵커 기준 논리행 재구성.
    - 줄이 TS_ANCHOR 로 시작하면 새 이벤트 시작.
    - 그렇지 않은 줄(빈 줄 제외)은 직전 이벤트에 이어붙인다(멀티라인 병합).
    - 첫 타임스탬프 이전의 머리말 줄은 버린다(고아).
    """
    records: list[str] = []
    cur: list[str] = []
    try:
        with path.open("r", encoding=encoding, errors="replace") as f:
            for raw in f:
                line = raw.rstrip("\n").rstrip("\r")
                if TS_ANCHOR.match(line):
                    if cur:
                        records.append(_join_block(cur))
                    cur = [line]
                elif line.strip():
                    if cur:  # 타임스탬프 이전 고아 줄은 무시
                        cur.append(line)
    except Exception:
        return records
    if cur:
        records.append(_join_block(cur))
    return records


def _count_logical_lines(path: Path, encoding: str) -> int:
    """전체 적재 없이 논리행(이벤트) 수만 카운트 (TS_ANCHOR 매칭 수)."""
    try:
        with path.open("r", encoding=encoding, errors="replace") as f:
            return sum(1 for raw in f if TS_ANCHOR.match(raw))
    except Exception:
        return 0


def _detect_encoding(path: Path) -> str | None:
    """여러 인코딩을 시도해서 첫 N바이트를 정상 디코딩하는 인코딩을 반환."""
    try:
        raw = path.read_bytes()[:4096]
    except Exception:
        return None
    for enc in ENCODING_CANDIDATES:
        try:
            raw.decode(enc)
            return enc
        except UnicodeDecodeError:
            continue
    return None


def _count_lines(path: Path, encoding: str) -> int:
    try:
        with path.open("r", encoding=encoding, errors="replace") as f:
            return sum(1 for _ in f)
    except Exception:
        return 0


def scan_log_files(base_dir: str | Path) -> list[dict]:
    """base_dir 하위를 재귀 탐색해 로그 파일 정보 리스트를 반환."""
    base = Path(base_dir)
    if not base.exists():
        return []

    infos: list[dict] = []
    for p in base.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() not in LOG_SUFFIXES:
            continue
        enc = _detect_encoding(p)
        if enc is None:
            # 인코딩 감지 실패 시 스킵 (경고용 레코드만 남김)
            infos.append({
                "path": str(p),
                "rel": str(p.relative_to(base)),
                "size_mb": round(p.stat().st_size / (1024 * 1024), 3),
                "total_lines": 0,
                "event_lines": 0,
                "encoding": None,
                "error": "encoding_detect_failed",
            })
            continue
        lines = _count_lines(p, enc)
        infos.append({
            "path": str(p),
            "rel": str(p.relative_to(base)),
            "size_mb": round(p.stat().st_size / (1024 * 1024), 3),
            "total_lines": lines,                       # 물리행
            "event_lines": _count_logical_lines(p, enc),  # 논리행(이벤트)
            "encoding": enc,
        })
    return infos


def _allocate_targets(counts: dict[str, int], target_lines: int) -> dict[str, int]:
    """파일별 (논리행) 수 기반 비례 배분. counts={path: 논리행수}. 반환: {path: allocated}"""
    active = [(p, n) for p, n in counts.items() if n > 0]
    total = sum(n for _, n in active)
    if total <= 0:
        return {}
    alloc: dict[str, int] = {}
    remaining = target_lines
    for idx, (path, n) in enumerate(active):
        if idx == len(active) - 1:
            alloc[path] = max(1, remaining)
        else:
            share = int(target_lines * n / total)
            share = max(1, min(share, n))
            alloc[path] = share
            remaining -= share
    return alloc


def sample_logs(
    file_infos: list[dict],
    target_lines: int,
    progress_cb: Callable[[int, int, str], None] | None = None,
) -> list[str]:
    """
    행처리(논리행 재구성) → 파일별 비례 배분 → stride 균등 샘플링.
    멀티라인 이벤트 블록을 1행으로 병합한 뒤 샘플링하므로 이벤트가 쪼개지지 않는다.
    각 라인에는 파일 상대경로 프리픽스가 없다 (병합된 원본 그대로).
    progress_cb(current_idx, total, filename) 콜백 지원.
    """
    active = [i for i in file_infos if i.get("encoding")]
    if not active:
        return []

    # ① 행처리: 파일별 논리행 재구성 (LLM 0회)
    logical_by_path: dict[str, list[str]] = {}
    total_files = len(active)
    for idx, info in enumerate(active):
        if progress_cb is not None:
            progress_cb(idx, total_files, info["rel"])
        logical_by_path[info["path"]] = read_logical_lines(Path(info["path"]), info["encoding"])

    # ② 논리행 수 기반 비례 배분
    counts = {p: len(v) for p, v in logical_by_path.items()}
    alloc = _allocate_targets(counts, target_lines)

    # ③ 논리행 단위 stride 균등 샘플링
    sampled: list[str] = []
    for info in active:
        records = logical_by_path[info["path"]]
        target = alloc.get(info["path"], 0)
        if target <= 0 or not records:
            continue
        stride = max(1, len(records) // max(1, target))
        for i in range(0, len(records), stride):
            sampled.append(records[i])
            if len(sampled) >= target_lines:
                break
        if len(sampled) >= target_lines:
            break

    if progress_cb is not None:
        progress_cb(total_files, total_files, "완료")

    return sampled[:target_lines]


def estimate_tokens(lines: Iterable[str]) -> int:
    """평균 글자수 / 3.5 로 토큰 수 추정 (한글/영문 혼합 heuristic)."""
    total_chars = sum(len(l) for l in lines)
    return int(total_chars / 3.5)
