# CHECKLIST.md — Motion Parser MVP **v5** 구현 체크리스트
> `설계참고.html`(5-STEP 핵심 로직)을 로컬·SQLite·무벡터DB로 단순화한 v5 구현 체크리스트.
> 완료 항목은 `[x]`. 실제 `asml-eventlog.log`로 STEP1→5 완주 + byte-equal PASS 검증 완료.

---

## Phase 0 — 초기화 / 마이그레이션
- [x] v4 산출물(3종 md·parser_v1.py·events.db·motion_notes.json) → `output/bak/` 처리, 소스는 보존
- [x] 기존 step2/3/5 → `output/bak/old_steps/` 백업 후 신규 파일로 교체
- [x] `requirements.txt` 정리 (streamlit·openai·pandas · cx_Oracle/Milvus 불요)
- [x] `output/{prompts,parser,reports,bak}` 디렉토리 자동 생성

---

## Phase 1 — 공통 유틸
### utils/db.py (★ SQLite 9테이블)
- [x] `init_db()` — PARSE_JOBS·EQP_PROMPTS·MEA·MOTION_EVENTS·REACT_LOOPS·CHAT_SESSIONS·CHAT_MESSAGES·audit_log·LOG_FILES 생성
- [x] PARSE_JOBS: `create_job`·`get_job`·`latest_job`·`update_job`·`advance_status`(역행 방지)
- [x] EQP_PROMPTS: `eqp_prompt_load`(JSON 파싱)·`is_first_run`·`eqp_prompt_insert`(LOCKED=N)·`eqp_prompt_propose`·`eqp_prompt_confirm`(LOCKED=Y)
- [x] MEA: `mea_clear`·`mea_bulk_insert`·`mea_select(motion_only)`·`mea_update`·`mea_update_batch`
- [x] MOTION_EVENTS: `motion_events_bulk_insert`(정렬)·`motion_events_select`·`motion_events_clear`
- [x] REACT_LOOPS / CHAT_* / audit_log / LOG_FILES CRUD
- [x] `aggregate_summary`(STEP5) · `reset_sandbox`(VERIFY 전용 DB)

### utils/parser_templates.py (★ 파싱·페어러·코드생성)
- [x] `parse_log_line`·`build_remark`/`parse_remark`·`is_noise`·`motion_name_from_source`·`parse_dt`
- [x] `discover_pairs_heuristic` — task_id 기반 started/finished 페어 자동 발견(LLM 폴백)
- [x] `entity_key`(A/B/C/D) · `event_sort_key`(내용 기반 결정론 정렬)
- [x] `reference_pair` — carry-state 매칭(VERIFY 기댓값) · `events_from_mea`
- [x] `canonical_motions`/`canonical_mea_events`(byte-equal 정규화)
- [x] `build_codegen_strategy`(PLAN) · `build_parser_package`(4-모듈 결정론 생성)

### utils/llm_client.py · log_sampler.py · file_manager.py · ai_config.py
- [x] `compose_messages`(무RAG 컨텍스트 조립) 추가, `<think>` 제거/재시도 유지
- [x] log_sampler 재사용(scan/sample/estimate)
- [x] file_manager 경로 헬퍼(prompts/parser/reports/parser_version_dir)
- [x] ai_config: EQP_ID/EQP_TYPE/USER_ID 입력 추가

---

## Phase 2 — app.py
- [x] 부팅 시 `ensure_dirs()` + `init_db()`
- [x] `_get_or_create_job()` — EQP_ID 기준 미완료 복원 / STEP5_DONE면 신규
- [x] 5 STEP 사이드바 + `PARSE_JOBS.STATUS` 게이팅(`_max_enabled_step`)
- [x] First-Run 분기(STEP2 건너뛰고 STEP3 직진) 반영
- [x] 메인 라우터: step1~5 render()

---

## Phase 3 — STEP 1 Log Selection
- [x] `mcc-log-file/` 스캔 + `st.data_editor` 체크박스 선택
- [x] 선택 파일 `LOG_FILES` 기록 + `target_lines` 슬라이더 + 균등 샘플링
- [x] `session_state['sampled_lines']` + 토큰 추정 + 미리보기, `STATUS=STEP1_DONE`

## Phase 4 — STEP 2 장비로드 프롬프트 생성 (First-Run)
- [x] First-Run 게이트(아니면 STEP3 안내)
- [x] AI 사전분석 카드(heuristic 페어/노이즈 + 선택 LLM 요약)
- [x] DB-backed 인터뷰(CHAT_SESSIONS/MESSAGES) + 전체 컨텍스트 LLM 호출(실패 폴백)
- [x] 페어 편집(data_editor) → `prompts/{eqp}.md` + EQP_PROMPTS INSERT(LOCKED=N) + audit, `STATUS=STEP2_DONE`

## Phase 5 — STEP 3 AI Analysis · MEA
- [x] `eqp_prompt_load` 표시(pair_matrix/noise/LOCKED)
- [x] REGEX 전수 추출 → MEA bulk INSERT(REMARK prepend · HIGH RECALL · LLM 0회)
- [x] 결정론 규칙 라벨링(signal/start/end/is_motion) + (선택) LLM 해석/propose
- [x] pair_matrix 검수 + pairing_strategy 4지선다 → `eqp_prompt_confirm`(LOCKED=Y) + MEA 재라벨, `STATUS=STEP3_DONE`

## Phase 6 — STEP 4 Code Generation · 4-모듈
- [x] PLAN: `build_codegen_strategy`(확정 strategy→algo · LLM 자율 금지)
- [x] GENERATE: `parser/v{n}/` 4-모듈 + AST 검증
- [x] VERIFY: subprocess 실행 → byte-equal 2단(MEA + MOTION_EVENTS) + 2회 결정론, REACT_LOOPS 기록
- [x] REFLECT: 모듈별 DIFF로 고칠 모듈 지목(max 10)
- [x] DONE: `parser/` 승격 + MOTION_EVENTS 적재 + MEA PROCESS_TIME 갱신, `STATUS=STEP4_DONE`
- [x] iteration UI(Think/Act/Observe expander + 진행바)

## Phase 7 — STEP 5 결과 리포트
- [x] 5테이블 집계 메트릭
- [x] MEA/MOTION_EVENTS Data Grid + 차트(모션 분포·시간대·ReAct 수렴) + CSV
- [x] `reports/{job}_{date}.md(.html)` 저장, `STATUS=STEP5_DONE`

---

## Phase 8 — 통합 테스트 (실제 asml-eventlog.log)
- [x] `streamlit run app.py` 헤드리스 부팅 — HTTP 200
- [x] STEP1 샘플링(11,715줄) → STEP1_DONE
- [x] STEP2 페어 49 / 노이즈 12 발견 → EQP_PROMPTS(LOCKED=N) + first_run False 전환
- [x] STEP3 MEA 5,858행(모션 5,694) + 라벨링 + 확정(strategy=C, LOCKED=Y)
- [x] STEP4 VERIFY **byte-equal PASS** (mea_ok·motion_ok) → MOTION_EVENTS 2,847 적재
- [x] STEP5 집계 + 리포트 + STEP5_DONE
- [x] 독립 실행: `python output/parser/main.py --input mcc-log-file/asml-eventlog.log --db <db>` — LLM 0회 · **2회 byte-equal 결정론**
- [x] SQLite: 9테이블 생성, MEA/MOTION_EVENTS 1건 이상, PARSE_JOBS lifecycle 정상

---

## Phase 9 — 엣지케이스
- [x] orphan(미종결 start) → MOTION 미생성, PROCESS_TIME NULL
- [x] 멀티스레드 비순차 타임스탬프 → `event_sort_key` 내용 기반 정렬로 흡수
- [x] First-Run 강제 검수(LOCKED=Y 전 STEP4 진입 차단)
- [x] LLM 미연결 시 heuristic 폴백으로 파이프라인 완주 (인터뷰/라벨링 enrich는 선택)
- [x] VERIFY 타임아웃(300s)·exec 에러 → REACT_LOOPS 기록 + REFLECT
- [ ] ReAct 10회 미수렴 시 graceful degradation(현재: 마지막 패키지 보존 + 경고) — 운영 중 보강

---

## 완료 기준
- [x] `streamlit run app.py` 에러 없이 실행
- [x] STEP 1~5 순차 진행 (실제 로그로 완주)
- [x] `output/events.db` MEA + MOTION_EVENTS 적재
- [x] `output/parser/` 4-모듈 독립 실행 + byte-equal 결정론
- [x] PARSE_JOBS.STATUS 기반 진행 복원
