"""
Motion Parser MVP v5 — Streamlit 메인 진입점.

5-STEP 핵심 로직(설계참고.html)을 로컬·SQLite·무벡터DB 로 단순화해 구현.
  STEP 1 Log Selection → STEP 2 장비로드 프롬프트 생성(First-Run) →
  STEP 3 AI Analysis(MEA) → STEP 4 Code Generation(4-모듈) → STEP 5 결과 리포트
진행 상태는 PARSE_JOBS.STATUS 로 관리하고 사이드바 게이팅에 사용한다.
"""
from __future__ import annotations

import streamlit as st

import ai_config
from utils import db, file_manager
from utils.debug_logger import log_event
from steps import (
    step1_log_selection,
    step2_eqp_prompt,
    step3_ai_analysis,
    step4_code_generation,
    step5_report,
)

st.set_page_config(
    page_title="Motion Parser · MVP v5",
    layout="wide",
    initial_sidebar_state="expanded",
)

# output 폴더 + DB 9테이블 보장
file_manager.ensure_dirs()
db.init_db()

if not st.session_state.get("_boot_logged"):
    log_event("app", "세션 시작 (v5)")
    st.session_state["_boot_logged"] = True


# ─────────────────────────────────────────────
# 사이드바 — AI Config + 장비 컨텍스트
# ─────────────────────────────────────────────
ai_config.render_config_sidebar()
ctx = st.session_state["job_ctx"]


# ─────────────────────────────────────────────
# PARSE_JOBS 작업 생성/복원
# ─────────────────────────────────────────────
def _get_or_create_job() -> dict:
    """현재 EQP_ID 기준으로 진행 중 작업을 복원하거나 새 작업을 생성한다."""
    job_id = st.session_state.get("job_id")
    job = db.get_job(job_id) if job_id else None
    if job and job["EQP_ID"] == ctx["eqp_id"]:
        return job
    # EQP 변경 또는 최초 — 최근 작업 복원(미완료) 또는 신규
    latest = db.latest_job(ctx["eqp_id"])
    if latest and latest["STATUS"] != "STEP5_DONE":
        job = latest
    else:
        new_job_id = db.create_job(ctx["user_id"], ctx["eqp_id"])
        log_event("app", "신규 작업 생성", f"job={new_job_id} eqp={ctx['eqp_id']}")
        job = db.get_job(new_job_id)
    st.session_state["job_id"] = job["JOB_ID"]
    # 최초 로드시 현재 단계를 작업 단계로 동기화
    if "current_step" not in st.session_state:
        st.session_state["current_step"] = job.get("CURRENT_STEP") or 1
    return job


job = _get_or_create_job()
st.session_state.setdefault("current_step", job.get("CURRENT_STEP") or 1)

first_run = db.is_first_run(ctx["eqp_id"])


# ─────────────────────────────────────────────
# 사이드바 — Step 라우터 (STATUS 기반 게이팅)
# ─────────────────────────────────────────────
STEP_META = [
    (1, "Log Selection",       "Sampler"),
    (2, "장비로드 프롬프트 생성", "First-Run"),
    (3, "AI Analysis · MEA",    "Regex+LLM"),
    (4, "Code Generation",      "4-모듈 ReAct"),
    (5, "결과 리포트",           "Report"),
]


def _max_enabled_step(status: str, first_run: bool) -> int:
    idx = db.STATUS_ORDER.index(status) if status in db.STATUS_ORDER else 0
    if idx == 0:            # INIT
        return 1
    if idx == 1:            # STEP1_DONE
        return 2 if first_run else 3   # First-Run 이 아니면 STEP 2 건너뛰고 STEP 3
    return min(5, idx + 1)  # STEP{n}_DONE → STEP{n+1}


def _render_sidebar_steps(status: str) -> None:
    st.sidebar.markdown("**WORKFLOW**")
    max_step = _max_enabled_step(status, first_run)
    cur_idx = db.STATUS_ORDER.index(status) if status in db.STATUS_ORDER else 0
    for num, name, badge in STEP_META:
        done = cur_idx >= num  # STEP{num}_DONE 도달 여부
        enabled = num <= max_step
        active = st.session_state["current_step"] == num
        prefix = "✅" if done else ("▸" if active else "○")
        label = f"{prefix} {num}. {name} · {badge}"
        if st.sidebar.button(label, key=f"nav_step_{num}", disabled=not enabled, width="stretch"):
            st.session_state["current_step"] = num
            log_event("nav", "Step 전환", f"→ step{num}")
            st.rerun()


_render_sidebar_steps(job["STATUS"])

st.sidebar.markdown("**INFO**")
st.sidebar.caption(
    f"job: `{job['JOB_ID'][:8]}`  ·  status: **{job['STATUS']}**  \n"
    f"first_run: {first_run}  ·  samples: {len(st.session_state.get('sampled_lines', []))}"
)
if first_run:
    st.sidebar.info("First-Run: STEP 2(장비로드 프롬프트)에서 사람 검수가 강제됩니다.")
else:
    st.sidebar.success("기존 EQP_PROMPTS 존재 — STEP 3 직진 가능.")


# ─────────────────────────────────────────────
# 메인 라우터
# ─────────────────────────────────────────────
STEP_RENDERERS = {
    1: step1_log_selection.render,
    2: step2_eqp_prompt.render,
    3: step3_ai_analysis.render,
    4: step4_code_generation.render,
    5: step5_report.render,
}

current = st.session_state["current_step"]
STEP_RENDERERS.get(current, step1_log_selection.render)()
