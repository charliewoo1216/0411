"""
AI 설정 + 작업 컨텍스트 사이드바.
- LLM Base URL / Model / API Key → session_state['ai_config']
- 장비/사용자 컨텍스트(EQP_ID / EQP_TYPE / USER_ID) → session_state['job_ctx']
  (PARSE_JOBS 생성·EQP_PROMPTS 조회의 키)
"""
from __future__ import annotations

import streamlit as st

DEFAULT_CONFIG: dict[str, str] = {
    "base_url": "http://192.168.0.8:8080/v1",
    "model": "qwen3.5:9b",
    "api_key": "sk_123!",
}

DEFAULT_JOB_CTX: dict[str, str] = {
    "eqp_id": "JB64",
    "eqp_type": "photo",   # photo/etch/cvd
    "user_id": "charl",
}


def render_config_sidebar() -> dict:
    """사이드바 상단에 AI Config + 작업 컨텍스트를 렌더링하고 현재 설정 dict 반환."""
    if "ai_config" not in st.session_state:
        st.session_state["ai_config"] = DEFAULT_CONFIG.copy()
    if "job_ctx" not in st.session_state:
        st.session_state["job_ctx"] = DEFAULT_JOB_CTX.copy()

    cfg = st.session_state["ai_config"]
    ctx = st.session_state["job_ctx"]

    with st.sidebar:
        st.markdown("**⚙ AI CONFIG**")
        cfg["base_url"] = st.text_input("Base URL", value=cfg.get("base_url", DEFAULT_CONFIG["base_url"]), key="cfg_base_url")
        cfg["model"] = st.text_input("Model", value=cfg.get("model", DEFAULT_CONFIG["model"]), key="cfg_model")
        cfg["api_key"] = st.text_input("API Key", value=cfg.get("api_key", DEFAULT_CONFIG["api_key"]), type="password", key="cfg_api_key")

        st.markdown("**🏭 EQUIPMENT**")
        ctx["eqp_id"] = st.text_input("EQP ID", value=ctx.get("eqp_id", DEFAULT_JOB_CTX["eqp_id"]), key="ctx_eqp_id")
        ctx["eqp_type"] = st.selectbox(
            "EQP Type", options=["photo", "etch", "cvd", "etc"],
            index=["photo", "etch", "cvd", "etc"].index(ctx.get("eqp_type", "photo")) if ctx.get("eqp_type") in ["photo", "etch", "cvd", "etc"] else 0,
            key="ctx_eqp_type",
        )
        ctx["user_id"] = st.text_input("User ID", value=ctx.get("user_id", DEFAULT_JOB_CTX["user_id"]), key="ctx_user_id")

    st.session_state["ai_config"] = cfg
    st.session_state["job_ctx"] = ctx
    return cfg
