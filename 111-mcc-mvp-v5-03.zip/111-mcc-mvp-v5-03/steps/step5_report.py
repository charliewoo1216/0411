"""
STEP 5 — 결과 리포트 (3 sub · 페이지 종결).

① 집계      — 5테이블(PARSE_JOBS·REACT_LOOPS·MEA·MOTION_EVENTS·EQP_PROMPTS) → summary
② 대시보드  — MEA + MOTION_EVENTS Data Grid + 차트(모션 분포·ReAct 수렴·시간대) + CSV
③ 리포트    — output/reports/{job}_{date}.md(+.html) 저장 + STATUS=STEP5_DONE
(Volume Test 는 설계에서 제거됨.)
"""
from __future__ import annotations

import datetime as _dt
import json

import pandas as pd
import streamlit as st

from utils import db, file_manager
from utils.debug_logger import log_event

# 결과 리포트에 출력할 MEA 원본 컬럼 (regex 전수 추출 시점 적재분)
MEA_REPORT_COLS = ["JOB_ID", "DATETIME", "EVENT_CODE", "ORIGIN_MESSAGE", "REMARK", "CREATED_AT", "UPDATED_AT"]


def render() -> None:
    st.header("5 · 결과 리포트")
    st.caption("5테이블 집계 + MEA/MOTION_EVENTS 대시보드 + .md/.html 리포트로 작업을 영구 종결한다.")
    st.divider()

    job_id = st.session_state["job_id"]
    job = db.get_job(job_id) or {}
    if db.STATUS_ORDER.index(job.get("STATUS", "INIT")) < db.STATUS_ORDER.index("STEP4_DONE"):
        st.warning("STEP 4(코드 생성 + 검증)를 먼저 완료하세요.")
        return

    summary = db.aggregate_summary(job_id)

    # ── ① 집계 메트릭 ──
    st.subheader("▸ ① 집계 결과")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("MEA 총 이벤트", f"{summary['total_events']:,}")
    c2.metric("모션 관련(Y)", f"{summary['motion_events_mea']:,}")
    c3.metric("페어 완성 모션", f"{summary['paired_motions']:,}")
    c4.metric("평균 process_time(ms)", f"{summary['avg_process_time_ms']:,.1f}")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("pairing_strategy", summary.get("pairing_strategy") or "-")
    c2.metric("ReAct iter", f"{summary['react_iters']}")
    c3.metric("LLM 호출", f"{summary['llm_calls']}")
    c4.metric("STATUS", job.get("STATUS"))

    # ── ② 대시보드 ──
    st.divider()
    st.subheader("▸ ② 대시보드")

    motions = db.motion_events_select(job_id)
    mea_rows = db.mea_select(job_id, motion_only=True)
    mea_all = db.mea_select(job_id)  # 전체(노이즈 포함) — 원본 추출 컬럼 출력용

    if summary["motion_type_dist"]:
        st.markdown("**모션 유형 분포**")
        dist = pd.DataFrame(
            {"motion_type": list(summary["motion_type_dist"].keys()),
             "count": list(summary["motion_type_dist"].values())}
        ).set_index("motion_type")
        st.bar_chart(dist)

    if motions:
        mdf = pd.DataFrame(motions)
        # 시간대별 이벤트(시:분 단위 시작 카운트)
        try:
            mdf["_hour"] = pd.to_datetime(mdf["START_TS"], format="%m/%d/%Y %H:%M:%S.%f", errors="coerce").dt.hour
            hourly = mdf.groupby("_hour").size().rename("count")
            st.markdown("**시간대별 모션 발생**")
            st.bar_chart(hourly)
        except Exception:
            pass

        st.markdown("**MOTION_EVENTS (앞 200행)**")
        st.dataframe(mdf.drop(columns=["_hour"], errors="ignore").head(200), hide_index=True, width="stretch")
        st.download_button(
            "⬇ MOTION_EVENTS CSV",
            mdf.drop(columns=["_hour"], errors="ignore").to_csv(index=False).encode("utf-8-sig"),
            file_name=f"motion_events_{job_id[:8]}.csv", mime="text/csv",
        )

    react = db.react_loops_select(job_id)
    if react:
        st.markdown("**ReAct 수렴 (iter별 소요/상태)**")
        st.dataframe(
            pd.DataFrame(react)[["ITER_N", "STATUS", "DURATION_S"]], hide_index=True, width="stretch"
        )

    # ── MEA (oracle) 원본 추출 테이블 ──
    if mea_all:
        st.markdown(f"**MEA (regex 전수 추출 · 총 {len(mea_all):,}행)**")
        mea_df = pd.DataFrame(mea_all)
        cols = [c for c in MEA_REPORT_COLS if c in mea_df.columns]
        st.dataframe(mea_df[cols].head(500), hide_index=True, width="stretch")
        if len(mea_all) > 500:
            st.caption(f"화면에는 앞 500행만 표시 — 전체 {len(mea_all):,}행은 아래 CSV로 받으세요.")
        st.download_button(
            "⬇ MEA 전체 CSV",
            mea_df[cols].to_csv(index=False).encode("utf-8-sig"),
            file_name=f"mea_{job_id[:8]}.csv", mime="text/csv",
        )

    if mea_rows:
        with st.expander(f"MEA 모션 행(라벨링 결과) 미리보기 (앞 200 / 총 {len(mea_rows):,})"):
            st.dataframe(
                pd.DataFrame(mea_rows[:200])[
                    ["DATETIME", "EVENT_CODE", "SIGNAL", "EVENT_NAME", "PROCESS_TIME_MS", "CODE_GEN_OK", "REMARK"]
                ],
                hide_index=True, width="stretch",
            )

    # ── ③ 리포트 + 종결 ──
    st.divider()
    st.subheader("▸ ③ 리포트 생성 + 종결 (STEP5_DONE)")
    if st.button("📄 리포트 생성 (.md / .html)", type="primary"):
        date = _dt.date.today().strftime("%Y%m%d")
        md = _build_report_md(job, summary, motions[:30], mea_all[:30])
        md_path = file_manager.reports_path(f"{job_id[:8]}_{date}.md")
        html_path = file_manager.reports_path(f"{job_id[:8]}_{date}.html")
        file_manager.save_text(md_path, md)
        file_manager.save_text(html_path, _md_to_html(md))
        db.update_job(job_id, REPORT_PATH=str(md_path))
        db.advance_status(job_id, "STEP5_DONE", current_step=5)
        log_event("step5", "리포트 생성", str(md_path))
        st.success(f"✓ 리포트 저장 완료 — {md_path}. 작업이 STEP5_DONE 으로 종결되었습니다.")
        with open(md_path, "rb") as f:
            st.download_button("⬇ 리포트 .md", f.read(), file_name=md_path.name, mime="text/markdown")
        st.rerun()

    if job.get("REPORT_PATH"):
        st.info(f"리포트 경로: `{job['REPORT_PATH']}`")


def _build_report_md(job: dict, s: dict, sample_motions: list[dict], sample_mea: list[dict] | None = None) -> str:
    lines = [
        f"# Motion Parser 결과 리포트 — {s['eqp_id']}",
        "",
        f"- JOB_ID: `{s['job_id']}`",
        f"- STATUS: {job.get('STATUS')}  ·  pairing_strategy: {s.get('pairing_strategy')}",
        f"- 생성일: {_dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "## 통계 요약",
        "",
        f"| 항목 | 값 |",
        f"|---|---|",
        f"| MEA 총 이벤트 | {s['total_events']:,} |",
        f"| 모션 관련(Y) | {s['motion_events_mea']:,} |",
        f"| 페어 완성 모션 | {s['paired_motions']:,} |",
        f"| 평균 process_time(ms) | {s['avg_process_time_ms']:,.1f} |",
        f"| ReAct iter | {s['react_iters']} |",
        f"| LLM 호출 | {s['llm_calls']} |",
        "",
        "## 모션 유형 분포",
        "",
        "| motion_type | count |",
        "|---|---|",
    ]
    for k, v in s["motion_type_dist"].items():
        lines.append(f"| {k} | {v} |")
    lines += ["", "## MOTION_EVENTS 샘플 (30건)", "", "| motion_type | start_ts | end_ts | duration_ms |", "|---|---|---|---|"]
    for m in sample_motions:
        lines.append(f"| {m.get('MOTION_TYPE')} | {m.get('START_TS')} | {m.get('END_TS')} | {m.get('DURATION_MS')} |")

    if sample_mea:
        lines += ["", "## MEA 샘플 (regex 전수 추출 · 30건)", "",
                  "| job_id | datetime | event_code | origin_message | remark | created_at | updated_at |",
                  "|---|---|---|---|---|---|---|"]
        for r in sample_mea:
            msg = (r.get("ORIGIN_MESSAGE") or "").replace("|", "\\|").replace("\n", " ")
            rem = (r.get("REMARK") or "").replace("|", "\\|")
            lines.append(
                f"| {r.get('JOB_ID')} | {r.get('DATETIME')} | {r.get('EVENT_CODE')} | {msg} | {rem} | "
                f"{r.get('CREATED_AT')} | {r.get('UPDATED_AT')} |"
            )
    return "\n".join(lines)


def _md_to_html(md: str) -> str:
    """의존성 없이 최소 HTML 래핑(코드/표는 <pre>)."""
    import html
    body = html.escape(md)
    return (
        "<!doctype html><html><head><meta charset='utf-8'>"
        "<title>Motion Parser Report</title>"
        "<style>body{font-family:system-ui,sans-serif;max-width:900px;margin:2rem auto;padding:0 1rem}"
        "pre{white-space:pre-wrap;background:#f6f8fa;padding:1rem;border-radius:8px}</style></head>"
        f"<body><pre>{body}</pre></body></html>"
    )
