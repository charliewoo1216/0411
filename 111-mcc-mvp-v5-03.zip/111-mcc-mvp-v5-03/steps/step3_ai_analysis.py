"""
STEP 3 — AI Analysis (5 sub) · MEA 중심.

① eqp_prompt_load — 장비로드 프롬프트(pair_matrix·regex·noise·strategy) 로드
② preflight 검토 — draft overlay 자연어 수정(LOCKED 변경 X)
③ REGEX 전수 추출 → MEA [HIGH RECALL] (모든 LO-* · 결정론 · LLM 0회)
④ LLM 라벨링 — 규칙 기반 결정론 라벨(signal·start/end_code·is_motion) + (선택) LLM 해석/신규페어 propose
⑤ Human 검수 — pair_matrix 편집 + pairing_strategy 4지선다 확정 → LOCKED=Y, MEA 재라벨
완료 시 PARSE_JOBS.STATUS=STEP3_DONE.

매칭은 결정론(carry-state)으로 STEP 4 파서와 동일 — byte-equal 정합 보장.
"""
from __future__ import annotations

import json

import pandas as pd
import streamlit as st

from utils import db, parser_templates as pt
from utils.debug_logger import log_event
from utils.llm_client import build_client_from_session, compose_messages

STRATEGY_DESC = {
    "A": "A · dict_composite — (code, task, wafer, lot, field) 복합키",
    "B": "B · fifo_queue — (code, wafer, lot) + FIFO 큐 (가장 단순)",
    "C": "C · dict_lomw_validated — LOMW[task] 단독 1:1 (본 로그 권장)",
    "D": "D · wafer/lot 우선 + LOMW fallback (혼재 firmware)",
}


def _label_mea(job_id: str, pair_matrix: list[dict], noise_codes: list[str]) -> dict:
    """규칙 기반 결정론 라벨링. MEA 전 행 batch UPDATE. 반환: 통계."""
    start_codes = {p["start"] for p in pair_matrix}
    end_to_start = {p["end"]: p["start"] for p in pair_matrix}
    code_to_motion = {}
    for p in pair_matrix:
        code_to_motion[p["start"]] = p.get("motion", "motion")
        code_to_motion[p["end"]] = p.get("motion", "motion")
    noise = set(noise_codes)

    rows = db.mea_select(job_id)
    updates = []
    stat = {"start": 0, "end": 0, "mid": 0, "noise": 0, "motion": 0}
    for r in rows:
        code = r["EVENT_CODE"]
        ek = pt.parse_remark(r.get("REMARK"))
        low = (r.get("ORIGIN_MESSAGE") or "").lower()
        if code in start_codes:
            sig, sc, ec = "START", code, next((p["end"] for p in pair_matrix if p["start"] == code), "")
            motion, is_m = code_to_motion.get(code, "motion"), "Y"
            stat["start"] += 1; stat["motion"] += 1
        elif code in end_to_start:
            sig, sc, ec = "END", end_to_start[code], code
            motion, is_m = code_to_motion.get(code, "motion"), "Y"
            stat["end"] += 1; stat["motion"] += 1
        elif code in noise or pt.is_noise(code):
            sig = "START" if "started" in low else ("END" if "finished" in low else "MID")
            sc = ec = ""; motion, is_m = "", "N"; stat["noise"] += 1
        else:
            sig = "START" if "started" in low else ("END" if "finished" in low else "MID")
            sc = ec = ""; motion, is_m = "", "N"; stat["mid"] += 1
        updates.append({"mea_id": r["MEA_ID"], "fields": {
            "SIGNAL": sig, "START_CODE": sc, "END_CODE": ec,
            "IS_MOTION_RELATED": is_m, "EVENT_NAME": (f"{motion}_{sig}" if motion else ""),
        }})
    db.mea_update_batch(updates)
    return stat


def render() -> None:
    st.header("3 · AI Analysis · MEA")
    st.caption("regex 전수추출 → MEA → 결정론 라벨링 → 사람 검수 + 페어링 전략 확정(LOCKED).")
    st.divider()

    ctx = st.session_state["job_ctx"]
    job_id = st.session_state["job_id"]
    eqp_id = ctx["eqp_id"]

    if not st.session_state.get("sampled_lines"):
        st.warning("STEP 1에서 먼저 샘플링을 완료하세요.")
        return

    # ── ① eqp_prompt_load ──
    eqp = db.eqp_prompt_load(eqp_id)
    if eqp is None:
        st.warning(f"`{eqp_id}` 의 EQP_PROMPTS 가 없습니다. STEP 2(장비로드 프롬프트)를 먼저 완료하세요.")
        return
    analysis = eqp["analysis"]
    pair_matrix = analysis.get("pair_matrix", [])
    noise_codes = analysis.get("noise_codes", [])

    st.subheader("▸ ① 장비로드 프롬프트 로드")
    c1, c2, c3 = st.columns(3)
    c1.metric("pair_matrix", f"{len(pair_matrix)}")
    c2.metric("noise codes", f"{len(noise_codes)}")
    c3.metric("LOCKED", eqp.get("LOCKED"))
    locked = eqp.get("LOCKED") == "Y"

    # ── ③ REGEX 전수 추출 → MEA ──
    st.divider()
    st.subheader("▸ ③ REGEX 전수 추출 → MEA [HIGH RECALL]")
    existing = db.mea_select(job_id)
    st.caption(f"현재 MEA 적재 행: {len(existing):,}")
    if st.button("📥 MEA 생성 (regex 전수 · 기존 교체)", disabled=locked):
        db.mea_clear(job_id)
        rows = []
        for ln in st.session_state["sampled_lines"]:
            ev = pt.parse_log_line(ln)
            if not ev:
                continue
            rows.append({
                "datetime": ev["datetime"], "event_code": ev["code"],
                "origin_message": ev["origin"], "remark": pt.build_remark(ev),
            })
        n = db.mea_bulk_insert(job_id, rows)
        log_event("step3", "MEA INSERT", f"rows={n}")
        st.success(f"✓ MEA {n:,}행 적재 완료.")
        st.rerun()

    # ── ④ 라벨링 ──
    st.divider()
    st.subheader("▸ ④ 라벨링 (결정론 규칙 + 선택 LLM)")
    if existing:
        if st.button("🏷️ 결정론 라벨링 실행 (signal·start/end·is_motion)", disabled=locked):
            stat = _label_mea(job_id, pair_matrix, noise_codes)
            log_event("step3", "MEA 라벨링", json.dumps(stat))
            st.success(f"✓ 라벨링 완료 — START {stat['start']} · END {stat['end']} · MID {stat['mid']} · noise {stat['noise']}")
            st.rerun()
        if st.button("🤖 LLM 해석/신규페어 propose (선택 · 첫 청크)"):
            _llm_enrich(job_id, eqp_id, pair_matrix)
            st.rerun()

        labeled = db.mea_select(job_id, motion_only=True)
        st.caption(f"모션 관련(is_motion=Y) 행: {len(labeled):,}")
        if labeled:
            st.dataframe(
                pd.DataFrame(labeled[:200])[["DATETIME", "EVENT_CODE", "SIGNAL", "START_CODE", "END_CODE", "EVENT_NAME", "REMARK"]],
                hide_index=True, width="stretch",
            )

    # ── ⑤ Human 검수 + 확정 ──
    st.divider()
    st.subheader("▸ ⑤ Human 검수 · 페어링 전략 확정 (LOCKED=Y)")

    st.markdown("**pair_matrix 검수 (편집 가능)**")
    pdf = pd.DataFrame(pair_matrix) if pair_matrix else pd.DataFrame(columns=["start", "end", "motion", "source"])
    edited_pairs = st.data_editor(pdf, hide_index=True, width="stretch", num_rows="dynamic", key="step3_pairs", disabled=locked)

    pending = analysis.get("pending_pairs", [])
    if pending:
        st.markdown("**pending_pairs (LLM 제안 — confirm 시 pair_matrix 로 합류)**")
        st.dataframe(pd.DataFrame(pending), hide_index=True, width="stretch")

    strategy = st.radio(
        "★ 페어링 규칙 4지선다 (엔지니어 확정 · LLM 자율 금지)",
        options=["A", "B", "C", "D"],
        format_func=lambda k: STRATEGY_DESC[k],
        index=2,  # C 권장
        disabled=locked,
    )

    if locked:
        st.success(f"✓ 이미 확정됨 (strategy={eqp.get('PAIRING_STRATEGY')}, LOCKED=Y). STEP 4로 이동하세요.")
    else:
        if st.button("✅ 확정 저장 (eqp_prompt_confirm · LOCKED=Y)", type="primary"):
            confirmed = [
                {"start": r["start"], "end": r["end"], "motion": r.get("motion") or "motion",
                 "source": r.get("source", ""), "conf": "confirmed"}
                for r in edited_pairs.to_dict("records") if r.get("start") and r.get("end")
            ]
            # pending 병합
            seen = {(p["start"], p["end"]) for p in confirmed}
            for p in pending:
                if (p.get("start"), p.get("end")) not in seen and p.get("start") and p.get("end"):
                    confirmed.append({**p, "conf": "confirmed"})
            db.eqp_prompt_confirm(eqp_id, strategy, ctx["user_id"], confirmed_pairs=confirmed, job_id=job_id)
            # 확정 matrix 로 MEA 재라벨(정합성)
            stat = _label_mea(job_id, confirmed, noise_codes)
            db.advance_status(job_id, "STEP3_DONE", current_step=3)
            log_event("step3", "확정", f"strategy={strategy} pairs={len(confirmed)} motion={stat['motion']}")
            st.success(f"✓ 확정 완료 — strategy={strategy}, pairs={len(confirmed)}. STEP 4로 이동하세요.")
            st.rerun()


def _llm_enrich(job_id: str, eqp_id: str, pair_matrix: list[dict]) -> None:
    """선택적 LLM 해석/신규페어 발견(첫 청크). 실패해도 파이프라인에 영향 없음."""
    try:
        client = build_client_from_session()
        rows = db.mea_select(job_id)[:80]
        known = {(p["start"], p["end"]) for p in pair_matrix}
        msgs = compose_messages(
            "당신은 로그 라벨링 보조자입니다. 주어진 이벤트들에서 pair_matrix 에 없는 신규 start↔end 페어 후보만 "
            'JSON 배열 [{"start","end","motion"}] 로 제안하세요. 없으면 [] 만 출력.',
            context_blocks=[
                ("기존 pair_matrix", json.dumps(pair_matrix, ensure_ascii=False)),
                ("MEA 이벤트(앞 80행)", json.dumps([{"dt": r["DATETIME"], "code": r["EVENT_CODE"], "msg": r["ORIGIN_MESSAGE"][:120]} for r in rows], ensure_ascii=False)),
            ],
            user="신규 페어 후보 JSON 배열만 출력하세요.",
        )
        resp = client.chat(msgs, step="step3", purpose="enrich")
        start = resp.find("["); end = resp.rfind("]")
        proposed = json.loads(resp[start:end + 1]) if start != -1 and end != -1 else []
        new = [p for p in proposed if (p.get("start"), p.get("end")) not in known]
        if new:
            db.eqp_prompt_propose(eqp_id, new, who="llm", what="step3 enrich")
            st.info(f"LLM 신규 페어 {len(new)}건 제안 → pending_pairs")
        else:
            st.info("LLM 신규 페어 제안 없음.")
    except Exception as e:
        st.warning(f"LLM 보강 건너뜀: {e}")
