"""
STEP 4 — Code Generation (5 sub · 4-모듈 패키지 · ReAct Loop).

① PLAN     — EQP_PROMPTS(LOCKED) 재로드 → 확정 pairing_strategy 채택 → codegen_strategy (LLM 자율 금지)
② GENERATE — parser/v{n}/ 4-모듈 생성 (parser 템플릿 내장 · pair_matrix 인라인)
③ VERIFY   — main.py 실행 → byte-equal 2단 (MEA + MOTION_EVENTS) + 2회 결정론
④ REFLECT  — 모듈별 DIFF(start/end/time)로 고칠 모듈 지목 (max 10회)
⑤ DONE     — parser/ 승격 + MOTION_EVENTS 적재 + MEA.PROCESS_TIME 갱신 + STATUS=STEP4_DONE

VERIFY 의 oracle = STEP 3 확정 MEA. 파서 매칭 = 레퍼런스 페어러와 동일 carry-state → byte-equal.
"""
from __future__ import annotations

import ast
import json
import shutil
import sqlite3
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

import streamlit as st

from utils import db, file_manager, parser_templates as pt
from utils.debug_logger import log_event

MAX_ITER = 10
VERIFY_TIMEOUT = 300
VERIFY_INPUT = file_manager.OUTPUT_DIR / "_verify_input.log"


def render() -> None:
    st.header("4 · Code Generation · 4-모듈 ReAct")
    st.caption("확정 pairing_strategy 로 4-모듈 파서를 생성하고, MEA를 정답지(oracle)로 byte-equal 검증한다.")
    st.divider()

    ctx = st.session_state["job_ctx"]
    job_id = st.session_state["job_id"]
    eqp_id = ctx["eqp_id"]

    eqp = db.eqp_prompt_load(eqp_id)
    if eqp is None or eqp.get("LOCKED") != "Y":
        st.warning("STEP 3에서 페어링 전략을 확정(LOCKED=Y)해야 코드 생성이 가능합니다.")
        return

    oracle_mea = db.mea_select(job_id)
    if not oracle_mea:
        st.warning("MEA가 비어 있습니다. STEP 3에서 MEA 생성/라벨링/확정을 완료하세요.")
        return

    # ── ① PLAN ──
    codegen = pt.build_codegen_strategy(eqp)
    st.subheader("▸ ① PLAN (엔지니어 확정 규칙 채택)")
    c1, c2, c3 = st.columns(3)
    c1.metric("strategy", codegen["strategy"])
    c2.metric("algo", codegen["algo"])
    c3.metric("pair_matrix", f"{len(codegen['pair_matrix'])}")
    with st.expander("codegen_strategy JSON"):
        st.code(json.dumps({k: v for k, v in codegen.items() if k != "pair_matrix"}, ensure_ascii=False, indent=2), language="json")

    motion_mea_cnt = sum(1 for r in oracle_mea if r.get("IS_MOTION_RELATED") == "Y" and r.get("SIGNAL") in ("START", "END"))
    st.caption(f"oracle MEA: 전체 {len(oracle_mea):,} · 모션 START/END {motion_mea_cnt:,}")

    # ── ②③④ ReAct ──
    st.divider()
    st.subheader("▸ ②③④ ReAct Loop (GENERATE → VERIFY → REFLECT · max 10)")
    if st.button("▶ 코드 생성 + 검증 시작", type="primary"):
        _run_react_loop(job_id, eqp_id, codegen, oracle_mea)

    iters = st.session_state.get("step4_iterations", [])
    if iters:
        _render_iterations(iters)

    if st.session_state.get("step4_done_flag"):
        st.success("✅ VERIFY PASS — parser/ 승격 + MOTION_EVENTS 적재 완료. STEP 5로 이동하세요.")


# ─────────────────────────────────────────────
# ReAct Loop
# ─────────────────────────────────────────────
def _run_react_loop(job_id: str, eqp_id: str, codegen: dict, oracle_mea: list[dict]) -> None:
    st.session_state["step4_iterations"] = []
    st.session_state["step4_done_flag"] = False

    # 정답지(oracle) 정규화
    oracle_mea_canon = pt.canonical_mea_events(oracle_mea)
    ref_motions = pt.reference_pair(pt.events_from_mea(oracle_mea, motion_only=True),
                                    codegen["pair_matrix"], codegen["strategy"], eqp_id=eqp_id)
    ref_motion_canon = pt.canonical_motions(ref_motions)

    # VERIFY 입력: 샘플 로그 그대로
    VERIFY_INPUT.write_text("\n".join(st.session_state.get("sampled_lines", [])), encoding="utf-8")

    progress = st.progress(0.0, text="ReAct 시작...")
    pkg = pt.build_parser_package(codegen)  # 템플릿 기반 결정론 생성
    passed_n = None

    for n in range(1, MAX_ITER + 1):
        progress.progress(n / MAX_ITER, text=f"Iteration {n} 실행 중...")
        t0 = time.time()
        vdir = file_manager.parser_version_dir(n)
        think = (f"strategy={codegen['strategy']} / algo={codegen['algo']} 채택. "
                 f"pair_matrix {len(codegen['pair_matrix'])}건 인라인. 4-모듈 생성 후 byte-equal 검증.")
        if n > 1:
            think += " 이전 mismatch 진단 모듈 재생성."

        # ── GENERATE ──
        for fn, src in pkg.items():
            try:
                ast.parse(src)
            except SyntaxError as e:
                log_event("step4", "AST 실패", f"{fn}: {e}")
            file_manager.save_text(vdir / fn, src)

        # ── VERIFY (2회 결정론) ──
        observe = _verify(vdir, oracle_mea_canon, ref_motion_canon)
        dur = round(time.time() - t0, 2)

        diff = observe.get("diff", {})
        status = "PASS" if observe["ok"] else ("TIMEOUT" if observe.get("timeout") else "MISMATCH")
        db.react_loop_insert(job_id, n, status, diff, stderr=observe.get("stderr", ""),
                             parser_path=str(vdir), duration_s=dur)

        st.session_state["step4_iterations"].append({
            "n": n, "status": "done" if observe["ok"] else "fail",
            "think": think, "code": pkg["main.py"], "observe": observe, "duration": dur,
        })
        log_event("step4", f"iter{n}", f"status={status} diff={json.dumps(diff)}")

        if observe["ok"]:
            passed_n = n
            break

        # ── REFLECT (모듈 지목) — 템플릿 기반이라 구조만 유지(LLM 교체 지점) ──
        st.session_state["step4_iterations"][-1]["reflect"] = _reflect_target(diff)

    progress.progress(1.0, text="완료")

    if passed_n is not None:
        _finalize_done(job_id, eqp_id, passed_n, codegen, ref_motions, oracle_mea)
        st.session_state["step4_done_flag"] = True
    else:
        st.error(f"⚠ {MAX_ITER}회 내 수렴 실패 — 마지막 패키지는 parser/v{MAX_ITER}/ 에 보존됨. 수동 점검 필요.")
    st.rerun()


def _verify(vdir: Path, oracle_mea_canon: str, ref_motion_canon: str) -> dict:
    """main.py 2회 실행 → byte-equal 2단 + 결정론. 반환 observe dict."""
    main_py = vdir / "main.py"
    runs = []
    for _ in range(2):
        sandbox = db.reset_sandbox()
        try:
            r = subprocess.run(
                [sys.executable, str(main_py), "--input", str(VERIFY_INPUT), "--db", str(sandbox), "--job", "verify"],
                capture_output=True, text=True, timeout=VERIFY_TIMEOUT,
            )
        except subprocess.TimeoutExpired:
            return {"ok": False, "timeout": True, "stderr": "timeout", "stdout": "", "diff": {"timeout": 1}}
        if r.returncode != 0:
            return {"ok": False, "stderr": r.stderr[-2000:], "stdout": r.stdout, "diff": {"exec_error": 1}}
        conn = sqlite3.connect(str(sandbox)); conn.row_factory = sqlite3.Row
        mea = [dict(x) for x in conn.execute("SELECT * FROM MEA")]
        motions = [dict(x) for x in conn.execute("SELECT * FROM MOTION_EVENTS")]
        conn.close()
        runs.append((mea, motions, r.stdout))

    det_ok = pt.canonical_motions(runs[0][1]) == pt.canonical_motions(runs[1][1])
    sb_mea, sb_motions, stdout = runs[0]
    sb_mea_canon = pt.canonical_mea_events(sb_mea)
    sb_motion_canon = pt.canonical_motions(sb_motions)

    mea_ok = (sb_mea_canon == oracle_mea_canon)
    motion_ok = (sb_motion_canon == ref_motion_canon)
    ok = mea_ok and motion_ok and det_ok

    diff = {
        "mea_diff": _line_diff(oracle_mea_canon, sb_mea_canon),
        "motion_diff": _line_diff(ref_motion_canon, sb_motion_canon),
        "determinism": "ok" if det_ok else "FAIL",
        "mea_ok": mea_ok, "motion_ok": motion_ok,
    }
    return {
        "ok": ok, "stderr": "", "stdout": stdout, "diff": diff,
        "counts": {"parser_motion": len(sb_motions), "parser_mea": len(sb_mea)},
    }


def _line_diff(expected: str, actual: str) -> dict:
    e = set(expected.splitlines()) if expected else set()
    a = set(actual.splitlines()) if actual else set()
    return {"missing": len(e - a), "extra": len(a - e)}


def _reflect_target(diff: dict) -> str:
    mea = diff.get("mea_diff", {})
    mot = diff.get("motion_diff", {})
    if mea.get("missing"):
        return "parser_start_code.py (start 누락)"
    if mea.get("extra"):
        return "parser_end_code.py (end 오탐)"
    if mot.get("missing") or mot.get("extra"):
        return "calculate_process_time.py (페어링/시간 어긋남)"
    if diff.get("determinism") == "FAIL":
        return "calculate_process_time.py (비결정론 — 정렬 강제)"
    return "(원인 미상 — 전체 점검)"


def _finalize_done(job_id: str, eqp_id: str, passed_n: int, codegen: dict,
                   ref_motions: list[dict], oracle_mea: list[dict]) -> None:
    """⑤ DONE — parser/ 승격 + MOTION_EVENTS 적재 + MEA PROCESS_TIME 갱신 + STATUS."""
    src_dir = file_manager.PARSER_DIR / f"v{passed_n}"
    for fn in ["parser_start_code.py", "parser_end_code.py", "calculate_process_time.py", "main.py"]:
        shutil.copy2(src_dir / fn, file_manager.PARSER_DIR / fn)

    db.motion_events_clear(job_id)
    n_mot = db.motion_events_bulk_insert(job_id, eqp_id, ref_motions, parser_version="v1")
    _assign_process_time(job_id, codegen["pair_matrix"], codegen["strategy"], oracle_mea)

    db.update_job(job_id, PARSER_PATH=str(file_manager.PARSER_DIR), TOTAL_ITER=passed_n)
    db.advance_status(job_id, "STEP4_DONE", current_step=4)
    log_event("step4", "DONE", f"iter={passed_n} motions={n_mot}")


def _assign_process_time(job_id: str, pair_matrix: list[dict], strategy: str, oracle_mea: list[dict]) -> None:
    """확정 MEA 모션 행을 carry-state 로 페어링해 PROCESS_TIME_MS + CODE_GEN_OK 갱신."""
    start_codes = {p["start"] for p in pair_matrix}
    end_to_start = {p["end"]: p["start"] for p in pair_matrix}
    pop_i = 0 if strategy == "B" else -1

    evs = []
    for r in oracle_mea:
        if r.get("IS_MOTION_RELATED") != "Y" or r.get("SIGNAL") not in ("START", "END"):
            continue
        ek = pt.parse_remark(r.get("REMARK"))
        evs.append({"mea_id": r["MEA_ID"], "datetime": r["DATETIME"], "code": r["EVENT_CODE"],
                    "signal": r["SIGNAL"], **ek})
    evs.sort(key=pt.event_sort_key)

    open_map: dict[tuple, list[dict]] = defaultdict(list)
    updates = []
    for ev in evs:
        code = ev["code"]
        if code in start_codes:
            open_map[(code, pt.entity_key(ev, strategy))].append(ev)
        elif code in end_to_start:
            key = (end_to_start[code], pt.entity_key(ev, strategy))
            if open_map[key]:
                s = open_map[key].pop(pop_i)
                sd, ed = pt.parse_dt(s["datetime"]), pt.parse_dt(ev["datetime"])
                dur = round((ed - sd).total_seconds() * 1000.0, 3) if (sd and ed) else None
                for mid in (s["mea_id"], ev["mea_id"]):
                    updates.append({"mea_id": mid, "fields": {"PROCESS_TIME_MS": dur, "CODE_GEN_OK": "Y"}})
    db.mea_update_batch(updates)


# ─────────────────────────────────────────────
# UI
# ─────────────────────────────────────────────
def _render_iterations(iters: list[dict]) -> None:
    st.divider()
    for it in iters:
        icon = "✅" if it["status"] == "done" else "❌"
        with st.expander(f"{icon} Iteration {it['n']} — {it['status']} ({it.get('duration', 0)}s)",
                         expanded=(it["status"] == "done")):
            t1, t2, t3 = st.tabs(["Think", "Act (main.py)", "Observe"])
            with t1:
                st.write(it["think"])
                if it.get("reflect"):
                    st.warning(f"REFLECT → {it['reflect']}")
            with t2:
                st.code(it["code"], language="python")
            with t3:
                obs = it["observe"]
                if obs["ok"]:
                    st.success("byte-equal PASS (MEA + MOTION_EVENTS + 2회 결정론)")
                    st.json(obs.get("counts", {}))
                else:
                    st.error("VERIFY FAIL")
                    if obs.get("stderr"):
                        st.code(obs["stderr"], language="text")
                st.json(obs.get("diff", {}))
